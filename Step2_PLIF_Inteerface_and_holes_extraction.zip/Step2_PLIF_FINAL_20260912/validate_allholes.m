function validate_allholes()
% Test the label functions extracted from the actual packaged source.
codeDir = fileparts(mfilename('fullpath'));
source = fileread(fullfile(codeDir, 'Step2_PLIF_interface_2_0_chunk.m'));
first = strfind(source, 'function E = extractLabelsV2(');
last = strfind(source, 'function R = diagToResultRecord(');
assert(isscalar(first) && isscalar(last) && first < last);
core = source(first:last-1);
core = strrep(core, 'function E = extractLabelsV2(', 'function E = step2_validation_core(');
testDir = tempname;
mkdir(testDir);
cleanup = onCleanup(@() cleanupTest(testDir)); %#ok<NASGU>
fid = fopen(fullfile(testDir, 'step2_validation_core.m'), 'w');
assert(fid > 0);
fprintf(fid, '%s', core);
fclose(fid);
addpath(testDir);
phi = zeros(40,40); phi(3:35,3:30) = 1;
phi(8,8) = 0; phi(12,8:9) = 0; phi(16,8:10) = 0; phi(20,8:11) = 0;
E = step2_validation_core(phi,0.5,40,40,100,1,1,15,2,0,200);
assert(E.isValidFrame && E.nHoles == 4);
assert(isequal(sort(double(E.holeArea_px(:))), [1;2;3;4]));
assert(E.nSmallHolesFiltered == 0);
assert(all(cellfun(@(x) ~isempty(x), E.holeBoundaryRC)));
assert(all(ismember(vertcat(E.holePixelIdx{:}), E.wakePixelIdx)));
assert(isequal(double(E.backgroundPixelIdx), ...
    sub2ind([40 40], double(E.backgroundRC(:,1)), double(E.backgroundRC(:,2)))));
% Non-finite pixels are excluded; a frame without background is invalid.
phi(9,9) = NaN;
E = step2_validation_core(phi,0.5,40,40,100,1,1,15,2,0,200);
assert(E.nInvalidPixels == 1 && ~ismember(uint32(sub2ind([40 40],9,9)), E.wakePixelIdx));
E = step2_validation_core(ones(40),0.5,40,40,100,1,1,15,2,0,200);
assert(~E.isValidFrame && strcmp(E.status, 'invalid_no_background') && E.nHoles == 0);
% The wake1 area inequality is strict.
phi = zeros(40); phi(3:12,5:24) = 1;
E = step2_validation_core(phi,0.5,40,40,100,1,1,15,2,0,200);
assert(E.nWake1 == 0);
phi(13,5) = 1;
E = step2_validation_core(phi,0.5,40,40,100,1,1,15,2,0,200);
assert(E.nWake1 == 1 && E.wake1Area_px == 201);
T = readtable(fullfile(codeDir, 'cases_28.csv'), 'TextType', 'string');
assert(height(T) == 28 && isequal(T.Index, (1:28).'));
assert(sum(T.Distance == "5D") == 7 && all(T.PhiThEven(T.Distance == "5D") == 0.5));
fprintf('VALIDATION PASS: all hole sizes, pixel coordinates, invalid pixels, wake area and 5D thresholds.\n');
end

function cleanupTest(testDir)
    clear step2_validation_core;
    if contains(path, testDir), rmpath(testDir); end
    if exist(testDir, 'dir'), rmdir(testDir, 's'); end
end
