function Step2_PLIF_interface_2_0_merge(caseIndex, runId, outputTag, workers)

% Merge checked chunks in good-frame order and publish the final case outputs.

clc; close all force;

if nargin < 4 || isempty(workers), workers = 8; end
validateattributes(workers, {'numeric'}, {'scalar','integer','>=',1,'<=',10});

framesPerChunk = 50;
nominalEvenFrameCount = 2501;
nCases = 28;
nChunksPerCase = ceil(nominalEvenFrameCount / framesPerChunk);

if nargin < 1 || isempty(caseIndex)
    caseIndex = str2double(getenv('PBS_ARRAY_INDEX'));
end
if nargin < 2 || isempty(runId)
    runId = getenv('STEP2_RUN_ID');
end
if nargin < 3 || isempty(outputTag)
    outputTag = '0905';
end

if ~(isnumeric(caseIndex) && isscalar(caseIndex) && isfinite(caseIndex) && ...
        caseIndex == round(caseIndex) && caseIndex >= 1 && ...
        caseIndex <= nCases)
    error('caseIndex must be an integer from 1 to %d.', nCases);
end
if isempty(runId) || isempty(regexp(runId, '^[A-Za-z0-9_-]+$', 'once'))
    error('runId must contain only letters, numbers, underscore or hyphen.');
end
if isempty(outputTag) || isempty(regexp(outputTag, '^[A-Za-z0-9_-]+$', 'once'))
    error('outputTag must contain only letters, numbers, underscore or hyphen.');
end

caseIndex = double(caseIndex);
versionTag = 'Step2_PLIF_interface_2.0';

thisFile = mfilename('fullpath');
codeDir = fileparts(thisFile);
masterDir = fileparts(fileparts(codeDir));
caseTablePath = fullfile(codeDir, 'cases_28.csv');

Cases = readtable(caseTablePath, 'TextType', 'string');
requiredColumns = {'Index','Distance','CaseName','PhiThEven'};
if height(Cases) ~= nCases || ...
        ~all(ismember(requiredColumns, Cases.Properties.VariableNames)) || ...
        any(Cases.Index(:) ~= (1:nCases).')
    error('Invalid cases_28.csv manifest.');
end

thisCase = Cases(caseIndex,:);
distanceName = char(thisCase.Distance);
caseName = char(thisCase.CaseName);
phi_th_even = double(thisCase.PhiThEven);
phiTag = sprintf('phi%04d', round(phi_th_even * 1000));
caseLabel = sprintf('%s / %s', distanceName, caseName);

nRows = 1600;
nCols = 2560;

plifDir = fullfile(masterDir, '02_INPUTS', 'PLIF', distanceName, caseName);
caseOutputRoot = fullfile(masterDir, '05_OUTPUTS', distanceName, caseName);
blackStripeFile = fullfile(caseOutputRoot, ...
    'PLIF_black_stripe_check_widthGT10_PLIF', ...
    'PLIF_black_stripe_check_widthGT10_results_PLIF.mat');
backgroundProfileFile = fullfile(caseOutputRoot, ...
    'PLIF_background_profile_col1980_2020', ...
    'PLIF_background_profile_col1980_2020_even_goodFrames.mat');
normalisationProfileFile = fullfile(caseOutputRoot, ...
    'PLIF_normalisation_profile_even_final', ...
    'PLIF_normalisation_profile_rawMean_bgCol1980_2020_even_goodFrames.mat');

outDir = fullfile(caseOutputRoot, ...
    sprintf('Y_interface_detection_method1_even_%s_final_%s', phiTag, outputTag));
diagnosticDir = fullfile(outDir, sprintf('Diagnostic_4panel_%s', outputTag));
highResolutionDir = fullfile(outDir, sprintf('High_resolution_panel_%s', outputTag));

manifestRunRoot = fullfile(masterDir, '06_MANIFESTS', ...
    'Step2_PLIF_interface_2.0', runId);
caseChunkDir = fullfile(manifestRunRoot, sprintf('case_%02d', caseIndex));

doneMarkerFile = fullfile(outDir, sprintf('Step2_PLIF_interface_2.0_DONE_%s.txt', outputTag));
if exist(doneMarkerFile, 'file'), delete(doneMarkerFile); end

fprintf('============================================================\n');
fprintf('Step2 v2.0 merge | case %d / %d\n', caseIndex, nCases);
fprintf('Version: %s\n', versionTag);
fprintf('Run ID: %s\n', runId);
fprintf('Case: %s\n', caseLabel);
fprintf('Threshold: %.6f (%s)\n', phi_th_even, phiTag);
fprintf('============================================================\n\n');

requiredFiles = {blackStripeFile, backgroundProfileFile, ...
    normalisationProfileFile};
for iReq = 1:numel(requiredFiles)
    if ~exist(requiredFiles{iReq}, 'file')
        error('Required Step-1 input is missing:\n%s', requiredFiles{iReq});
    end
end

Sblack = load(blackStripeFile);
requiredBlackFields = {'frameNoEvenUse','pivFrameNoEvenUse', ...
    'badEvenFrameNos','badEvenFileNames','excludedPIVFrameNos'};
for iField = 1:numel(requiredBlackFields)
    if ~isfield(Sblack, requiredBlackFields{iField})
        error('Missing %s in:\n%s', requiredBlackFields{iField}, ...
            blackStripeFile);
    end
end

frameNoEven_toProcess = double(Sblack.frameNoEvenUse(:));
pivFrameNoEvenUse = double(Sblack.pivFrameNoEvenUse(:));
badEvenFrameNos = double(Sblack.badEvenFrameNos(:));
badEvenFileNames = Sblack.badEvenFileNames;
excludedPIVFrameNos = double(Sblack.excludedPIVFrameNos(:));

if isempty(frameNoEven_toProcess) || ...
        any(mod(frameNoEven_toProcess,2) ~= 0) || ...
        any(diff(frameNoEven_toProcess) <= 0) || ...
        numel(unique(frameNoEven_toProcess)) ~= ...
        numel(frameNoEven_toProcess)
    error('Invalid Step-1 frameNoEvenUse population.');
end
if numel(pivFrameNoEvenUse) ~= numel(frameNoEven_toProcess) || ...
        any(pivFrameNoEvenUse ~= (frameNoEven_toProcess - 98)./2)
    error('pivFrameNoEvenUse is inconsistent with frameNoEvenUse.');
end

Sbg = load(backgroundProfileFile);
if ~isfield(Sbg, 'B_profile_even')
    error('Missing B_profile_even in:\n%s', backgroundProfileFile);
end
B_profile_even = double(Sbg.B_profile_even(:));
if any(~isfinite(B_profile_even))
    error('B_profile_even contains non-finite values:\n%s', backgroundProfileFile);
end
if isfield(Sbg,'frameNoEvenUse') && ...
        ~isequal(double(Sbg.frameNoEvenUse(:)), frameNoEven_toProcess)
    error('Background MAT frameNoEvenUse disagrees with black-stripe MAT.');
end
if isfield(Sbg,'pivFrameNoEvenUse') && ...
        ~isequal(double(Sbg.pivFrameNoEvenUse(:)), pivFrameNoEvenUse)
    error('Background MAT pivFrameNoEvenUse disagrees with black-stripe MAT.');
end

Snorm = load(normalisationProfileFile);
if ~isfield(Snorm, 'Phi_ref_even_forNorm')
    error('Missing Phi_ref_even_forNorm in:\n%s', ...
        normalisationProfileFile);
end
Phi_ref_even_forNorm = double(Snorm.Phi_ref_even_forNorm(:));
if isfield(Snorm,'yCL_col')
    yCL_col = double(Snorm.yCL_col);
else
    yCL_col = 514.45;
end
if isfield(Snorm,'frameNoEvenUse') && ...
        ~isequal(double(Snorm.frameNoEvenUse(:)), frameNoEven_toProcess)
    error('Normalisation MAT frameNoEvenUse disagrees with black-stripe MAT.');
end
if isfield(Snorm,'pivFrameNoEvenUse') && ...
        ~isequal(double(Snorm.pivFrameNoEvenUse(:)), pivFrameNoEvenUse)
    error('Normalisation MAT pivFrameNoEvenUse disagrees with black-stripe MAT.');
end
if any(~isfinite(Phi_ref_even_forNorm)) || any(Phi_ref_even_forNorm <= 0)
    error('Phi_ref_even_forNorm contains invalid values.');
end

nProcess = numel(frameNoEven_toProcess);
frameStartEven = min(frameNoEven_toProcess);
frameEndEven = max(frameNoEven_toProcess);
diagnosticEveryNFrames = 20;
highResolutionEveryNFrames = 100;
diagnosticFrameNoPlanned = frameNoEven_toProcess( ...
    1:diagnosticEveryNFrames:nProcess);
highResolutionFrameNoPlanned = frameNoEven_toProcess( ...
    1:highResolutionEveryNFrames:nProcess);

ResultEven = repmat(makeEmptyResultV2(), nProcess, 1);
seenGlobalIndices = false(nProcess,1);
chunkStartTimes = nan(nChunksPerCase,1);
chunkFinishTimes = nan(nChunksPerCase,1);
chunkElapsedMin = nan(nChunksPerCase,1);

for chunkIndex = 1:nChunksPerCase
    chunkMat = fullfile(caseChunkDir, sprintf('chunk_%03d.mat', chunkIndex));
    chunkDone = fullfile(caseChunkDir, ...
        sprintf('chunk_%03d_DONE.txt', chunkIndex));

    if ~exist(chunkMat, 'file') || ~exist(chunkDone, 'file')
        error('Missing chunk checkpoint or marker for case %d chunk %d.', ...
            caseIndex, chunkIndex);
    end

    C = load(chunkMat, 'ResultChunk', 'ChunkMeta');
    if ~isfield(C,'ResultChunk') || ~isfield(C,'ChunkMeta')
        error('Invalid chunk MAT:\n%s', chunkMat);
    end

    M = C.ChunkMeta;
    expectedStart = (chunkIndex - 1) * framesPerChunk + 1;
    expectedEnd = min(chunkIndex * framesPerChunk, nProcess);
    if expectedStart <= nProcess
        expectedIndices = (expectedStart:expectedEnd).';
    else
        expectedIndices = zeros(0,1);
    end

    if ~strcmp(M.runId, runId) || M.caseIndex ~= caseIndex || ...
            M.chunkIndex ~= chunkIndex || ...
            ~strcmp(M.distance, distanceName) || ...
            ~strcmp(M.caseName, caseName) || ...
            abs(M.phi_th_even - phi_th_even) > 1e-12 || ...
            ~isequal(double(M.globalIndices(:)), expectedIndices) || ...
            numel(C.ResultChunk) ~= numel(expectedIndices)
        error('Chunk metadata mismatch:\n%s', chunkMat);
    end

    if ~isempty(expectedIndices)
        expectedFrames = frameNoEven_toProcess(expectedIndices);
        actualFrames = double([C.ResultChunk.frameNo]).';
        if ~isequal(actualFrames, expectedFrames)
            error('Chunk frame-number mismatch:\n%s', chunkMat);
        end
        ResultEven(expectedIndices) = C.ResultChunk(:);
        seenGlobalIndices(expectedIndices) = true;
    end

    chunkStartTimes(chunkIndex) = M.chunkStartDatenum;
    chunkFinishTimes(chunkIndex) = M.chunkFinishDatenum;
    chunkElapsedMin(chunkIndex) = M.chunkElapsedMin;

    fprintf('Merged chunk %3d / %3d | frames = %d\n', ...
        chunkIndex, nChunksPerCase, numel(expectedIndices));
end

if ~all(seenGlobalIndices)
    error('Merged chunks do not cover every GOOD EVEN frame exactly once.');
end

statusList = string({ResultEven.status});
if any(~ismember(statusList, ["ok","invalid_no_background"]))
    error(['Unexpected status value found while merging case %d. Only ' ...
        '''ok'' and ''invalid_no_background'' are valid v2.0 statuses.'], ...
        caseIndex);
end
nStatusOK = nnz(statusList == "ok");
nStatusInvalidNoBackground = nnz(statusList == "invalid_no_background");

verifyExpectedPngOutputsV2(frameNoEven_toProcess, phiTag, ...
    diagnosticDir, highResolutionDir, ...
    diagnosticEveryNFrames, highResolutionEveryNFrames);

outFrameCheckTxt = fullfile(outDir, sprintf( ...
    'interface_check_%s_%s_%s_%s.txt', distanceName, caseName, phiTag, outputTag));
temporaryFrameCheckTxt = [tempname(outDir) '.txt'];
writeFrameCheckTextV2(ResultEven, temporaryFrameCheckTxt, ...
    frameStartEven, frameEndEven);
replaceFileAtomically(temporaryFrameCheckTxt, outFrameCheckTxt);

validStartTimes = chunkStartTimes(isfinite(chunkStartTimes));
validFinishTimes = chunkFinishTimes(isfinite(chunkFinishTimes));
if isempty(validStartTimes) || isempty(validFinishTimes)
    elapsedMin = NaN;
else
    elapsedMin = (max(validFinishTimes) - min(validStartTimes)) * 24 * 60;
end

Meta = struct();
Meta.version = versionTag;
Meta.caseIndex = caseIndex;
Meta.distance = distanceName;
Meta.caseName = caseName;
Meta.caseLabel = caseLabel;
Meta.coordinateConvention = [ ...
    'row = image row index (1..nRows, vertical); ' ...
    'col = image column index (1..nCols, horizontal); ' ...
    'every *RC field is Nx2 [row col]; every *boundary field ' ...
    '(holeBoundaryRC, unknownBoundaryRC) and interfaceRC is a cell array of ' ...
    'Nx4 [rowA colA rowB colB] matrices, one cell per hole ID / unknown-' ...
    'block ID / wake1.0 block ID respectively -- each row one 4-connected ' ...
    'pixel pair (a "crack"), unordered within its cell; two different ' ...
    'holes/unknown-blocks/wake1.0 blocks are never mixed into the same ' ...
    'cell, even where they touch at a single pixel-grid corner.'];
Meta.connectivity = '0-side 4-connectivity; 1-side 8-connectivity';
Meta.algorithmVersion = 'Step2 connected components with all selected holes retained';
Meta.phi_th_even = phi_th_even;
Meta.phiTag = phiTag;
Meta.frameNoEvenUse = frameNoEven_toProcess;
Meta.pivFrameNoEvenUse = pivFrameNoEvenUse;
Meta.badEvenFrameNos = badEvenFrameNos;
Meta.badEvenFileNames = badEvenFileNames;
Meta.excludedPIVFrameNos = excludedPIVFrameNos;
Meta.nNominalEvenFrames = nominalEvenFrameCount;
Meta.nGoodEvenFramesProcessed = nProcess;
Meta.nBadEvenFramesExcluded = numel(badEvenFrameNos);
Meta.firstGoodEvenFrame = frameStartEven;
Meta.lastGoodEvenFrame = frameEndEven;
Meta.nStatusOK = nStatusOK;
Meta.nStatusInvalidNoBackground = nStatusInvalidNoBackground;
Meta.nRows = nRows;
Meta.nCols = nCols;
Meta.yCL_col = yCL_col;
Meta.centreBandHalfWidth = 25;
Meta.minHoleAreaPx = 0; % Hole area filtering disabled.
Meta.minWakeOneAreaPx = 200;
Meta.cornerRadiusPx = 0.15;
Meta.plifDir = plifDir;
Meta.caseOutputRoot = caseOutputRoot;
Meta.blackStripeFile = blackStripeFile;
Meta.backgroundProfileFile = backgroundProfileFile;
Meta.normalisationProfileFile = normalisationProfileFile;
Meta.outputDir = outDir;
Meta.diagnosticDir = diagnosticDir;
Meta.highResolutionDir = highResolutionDir;
Meta.diagnosticEveryNFrames = diagnosticEveryNFrames;
Meta.highResolutionEveryNFrames = highResolutionEveryNFrames;
Meta.diagnosticFrameNoPlanned = diagnosticFrameNoPlanned;
Meta.highResolutionFrameNoPlanned = highResolutionFrameNoPlanned;
Meta.B_profile_even = B_profile_even;
Meta.Phi_ref_even_forNorm = Phi_ref_even_forNorm;
Meta.diagnosticResolutionDPI = 1200;
Meta.highResolutionPanelDPI = 1200;
Meta.interfaceCol = [1.00 0.90 0.00];
Meta.holeBoundaryCol = [0.85 0.05 0.05];
Meta.unknownBoundaryCol = [0.65 0.65 0.65];
Meta.reflectionRemoval = false;
Meta.instantaneousSpatialSmoothing = false;
Meta.areaBasedCleanup = false;
Meta.areaBasedCleanupNote = 'Hole area cleanup disabled: all selected holes retain hole labels, statistics, and boundaries, including areas 1-3 pixels. The wake1.0 area threshold remains unchanged.';
Meta.holeMeanPhiStarRecheck = false;
Meta.frameCheckTxt = outFrameCheckTxt;
Meta.requestedWorkers = workers;
Meta.runId = runId;
Meta.outputTag = outputTag;
Meta.elapsedMin = elapsedMin;
Meta.framesPerChunk = framesPerChunk;
Meta.nChunksPerCase = nChunksPerCase;
Meta.sumChunkElapsedMin = sum(chunkElapsedMin, 'omitnan');
Meta.chunkManifestDirectory = caseChunkDir;
Meta.executionArchitecture = sprintf( ...
    'Independent PBS case jobs; %d process workers; 51 chunks; merge in the case job', workers);
Meta.description = [ ...
    'Step1 good even frames are background-subtracted, clipped at zero and normalised. ' ...
    'Finite pixels are thresholded; zero components use 4-connectivity and one components 8-connectivity. ' ...
    'Background touches the last column; other edge-touching zero components are unknown. ' ...
    'Wake1 intersects the centreline band and has area greater than 200 pixels. ' ...
    'An interior zero component is a hole when edge-adjacent to any wake1 pixel. All hole areas are retained. ' ...
    'Wake2 has at least one adjacent hole pixel and no adjacent non-hole zero pixel. ' ...
    'The final wake is wake1, wake2 and holes. Interface pairs are background to wake1 only. ' ...
    'Hole and unknown boundaries are paired against any one-side pixel. ' ...
    'Cracks are stored as unordered pixel pairs and drawn as true edges with 0.15-pixel corner rounding. ' ...
    'Diagnostic PNGs are sampled every 20 good frames and high-resolution PNGs every 100, starting at the first frame.'];

outMat = fullfile(outDir, sprintf( ...
    'interface_holes_%s_%s_%s_%s.mat', distanceName, caseName, phiTag, outputTag));
temporaryMat = [tempname(outDir) '.mat'];
save(temporaryMat, 'ResultEven', 'Meta', '-v7.3');
replaceFileAtomically(temporaryMat, outMat);
verifyFinalMatFile(outMat);

temporaryDone = [tempname(outDir) '.txt'];
fidDone = fopen(temporaryDone, 'w');
if fidDone < 0
    error('Cannot write completion marker:\n%s', temporaryDone);
end
fprintf(fidDone, 'Step2_PLIF_interface_2.0 COMPLETE\n');
fprintf(fidDone, 'CaseIndex: %d\n', caseIndex);
fprintf(fidDone, 'Distance: %s\n', distanceName);
fprintf(fidDone, 'CaseName: %s\n', caseName);
fprintf(fidDone, 'Threshold: %.6f\n', phi_th_even);
fprintf(fidDone, 'ThresholdTag: %s\n', phiTag);
fprintf(fidDone, 'GoodEvenProcessed: %d\n', nProcess);
fprintf(fidDone, 'BadEvenExcluded: %d\n', numel(badEvenFrameNos));
fprintf(fidDone, 'StatusOK: %d\n', nStatusOK);
fprintf(fidDone, 'StatusInvalidNoBackground: %d\n', nStatusInvalidNoBackground);
fprintf(fidDone, 'ResultMAT: %s\n', outMat);
fprintf(fidDone, 'Finished: %s\n', datestr(now,31));
fclose(fidDone);
replaceFileAtomically(temporaryDone, doneMarkerFile);

cleanupMergedChunkMatFiles(caseChunkDir);

fprintf('\n============================================================\n');
fprintf('CASE MERGE COMPLETE\n');
fprintf('Case: %s\n', caseLabel);
fprintf('GOOD EVEN frames: %d (ok = %d, invalid_no_background = %d)\n', ...
    nProcess, nStatusOK, nStatusInvalidNoBackground);
fprintf('Final MAT: %s\n', outMat);
fprintf('Completion marker: %s\n', doneMarkerFile);
fprintf('All required PNG files were verified before completion.\n');
fprintf('============================================================\n');

end

function R = makeEmptyResultV2()

    R = struct();
    R.frameNo = NaN;
    R.frameName = '';
    R.status = 'not_processed';
    R.isValidFrame = false;

    R.backgroundPixelIdx = zeros(0,1,'uint32');
    R.backgroundRC = zeros(0,2,'uint32');
    R.nBackgroundPixels = 0;

    R.wakePixelIdx = zeros(0,1,'uint32');
    R.wakeRC = zeros(0,2,'uint32');
    R.nWakePixels = 0;
    R.nWakeDyePixels = 0;

    R.nWake1 = 0;
    R.wake1ID = zeros(0,1);
    R.wake1PixelIdx = {};
    R.wake1RC = {};
    R.wake1Area_px = zeros(0,1);

    R.nWake2 = 0;
    R.wake2ID = zeros(0,1);
    R.wake2PixelIdx = {};
    R.wake2RC = {};
    R.wake2Area_px = zeros(0,1);

    R.nHoles = 0;
    R.holeID = zeros(0,1);
    R.holePixelIdx = {};
    R.holeRC = {};
    R.holeArea_px = zeros(0,1);
    R.holeBoundaryRC = {};
    R.nSmallHolesFiltered = 0;

    R.nUnknown = 0;
    R.unknownID = zeros(0,1);
    R.unknownPixelIdx = {};
    R.unknownRC = {};
    R.unknownArea_px = zeros(0,1);
    R.unknownBoundaryRC = {};

    R.interfaceRC = {};
    R.nInterfaceSegments = 0;

    R.invalidPixelIdx = zeros(0,1,'uint32');
    R.invalidRC = zeros(0,2,'uint32');
    R.nInvalidPixels = 0;
end

function verifyExpectedPngOutputsV2(frameNos, phiTag, diagnosticDir, ...
        highResolutionDir, diagnosticEveryNFrames, highResolutionEveryNFrames)

    fprintf('\nVerifying diagnostic/high-resolution PNG files (every %dth / %dth frame)...\n', ...
        diagnosticEveryNFrames, highResolutionEveryNFrames);

    nDiagChecked = 0;
    nHighResChecked = 0;

    for k = 1:numel(frameNos)
        frameTag = sprintf('%04d', frameNos(k));

        if mod(k - 1, diagnosticEveryNFrames) == 0
            diagnosticFile = fullfile(diagnosticDir, sprintf( ...
                'PLIF_method1_diagnostic_%s_even_%s_FINAL.png', ...
                frameTag, phiTag));
            validatePngHeader(diagnosticFile);
            nDiagChecked = nDiagChecked + 1;
        end

        if mod(k - 1, highResolutionEveryNFrames) == 0
            highResolutionFile = fullfile(highResolutionDir, sprintf( ...
                'PLIF_method1_panel_%s_even_%s_FINAL.png', ...
                frameTag, phiTag));
            validatePngHeader(highResolutionFile);
            nHighResChecked = nHighResChecked + 1;
        end
    end

    fprintf('Diagnostic PNGs verified: %d\n', nDiagChecked);
    fprintf('High-resolution PNGs verified: %d\n', nHighResChecked);
end

function validatePngHeader(filePath)

    if ~exist(filePath, 'file')
        error('Required PNG is missing:\n%s', filePath);
    end
    D = dir(filePath);
    if isempty(D) || D.bytes <= 0
        error('Required PNG is empty:\n%s', filePath);
    end
    try
        info = imfinfo(filePath);
    catch ME
        error('Required PNG is unreadable:\n%s\n%s', filePath, ME.message);
    end
    if isempty(info) || info(1).Width <= 0 || info(1).Height <= 0
        error('Required PNG has invalid dimensions:\n%s', filePath);
    end
end

function writeFrameCheckTextV2(ResultEven, outTxt, frameStartEven, frameEndEven)

    fid = fopen(outTxt, 'w');
    if fid < 0
        error('Cannot open frame check TXT:\n%s', outTxt);
    end

    fprintf(fid, 'Step2 v2.0 per-frame check (connected-component label-based)\n');
    fprintf(fid, '======================================\n\n');
    fprintf(fid, 'GOOD EVEN frames processed from %04d to %04d\n\n', ...
        frameStartEven, frameEndEven);
    fprintf(fid, ['A frame is INVALID when no 0-side connected component ' ...
        'touches the last image column (no background found). An invalid ' ...
        'frame carries no wake/hole/interface output and does not enter ' ...
        'any statistic below.\n\n']);

    statusList = string({ResultEven.status});
    invalidIdx = find(statusList == "invalid_no_background");

    fprintf(fid, 'Invalid frames (no background found): %d / %d\n', ...
        numel(invalidIdx), numel(ResultEven));
    fprintf(fid, '--------------------------------------\n');
    if isempty(invalidIdx)
        fprintf(fid, '(none)\n');
    else
        for k = invalidIdx(:).'
            R = ResultEven(k);
            fprintf(fid, 'Frame %04d | File: %s\n', R.frameNo, R.frameName);
        end
    end

    validIdx = find(statusList == "ok");
    totalHoles = 0;
    totalUnknown = 0;
    totalInterfaceSegments = 0;
    totalInvalidPixels = 0;
    totalHoleAreaPx = 0;
    totalUnknownAreaPx = 0;
    totalSmallHolesFiltered = 0;
    for k = validIdx(:).'
        R = ResultEven(k);
        totalHoles = totalHoles + R.nHoles;
        totalUnknown = totalUnknown + R.nUnknown;
        totalInterfaceSegments = totalInterfaceSegments + R.nInterfaceSegments;
        totalHoleAreaPx = totalHoleAreaPx + sum(R.holeArea_px);
        totalUnknownAreaPx = totalUnknownAreaPx + sum(R.unknownArea_px);
        totalSmallHolesFiltered = totalSmallHolesFiltered + R.nSmallHolesFiltered;
    end
    for k = 1:numel(ResultEven)
        totalInvalidPixels = totalInvalidPixels + ResultEven(k).nInvalidPixels;
    end

    fprintf(fid, '\nWhole-case summary (valid frames only, except invalid-pixel count)\n');
    fprintf(fid, '--------------------------------------\n');
    fprintf(fid, 'Valid frames: %d\n', numel(validIdx));
    fprintf(fid, 'Total formal holes across all valid frames: %d (total %d px)\n', ...
        totalHoles, totalHoleAreaPx);
    fprintf(fid, 'Total small holes filtered out (area < minHoleAreaPx) across all valid frames: %d\n', ...
        totalSmallHolesFiltered);
    fprintf(fid, 'Total unknown (FoV-excluded) regions across all valid frames: %d (total %d px)\n', ...
        totalUnknown, totalUnknownAreaPx);
    fprintf(fid, 'Total interface pixel-pair segments across all valid frames: %d\n', ...
        totalInterfaceSegments);
    fprintf(fid, 'Total invalid (non-finite phiStar) pixels across all %d frames: %d\n', ...
        numel(ResultEven), totalInvalidPixels);

    fclose(fid);
end

function replaceFileAtomically(sourceFile, destinationFile)

    if ~exist(sourceFile, 'file')
        error('Cannot publish missing source file:\n%s', sourceFile);
    end

    [okMove,msgMove] = movefile(sourceFile, destinationFile, 'f');
    if ~okMove
        error('Failed to replace destination:\n%s', msgMove);
    end
end

function verifyFinalMatFile(filePath)

    if ~exist(filePath, 'file')
        error('Final MAT is missing after publication:\n%s', filePath);
    end

    D = dir(filePath);
    if isempty(D) || D.bytes <= 0
        error('Final MAT is empty:\n%s', filePath);
    end

    try
        variables = whos('-file', filePath);
    catch ME
        error('Final MAT cannot be inspected:\n%s\n%s', ...
            filePath, ME.message);
    end

    variableNames = string({variables.name});
    if ~all(ismember(["ResultEven","Meta"], variableNames))
        error('Final MAT does not contain ResultEven and Meta:\n%s', ...
            filePath);
    end
end

function cleanupMergedChunkMatFiles(caseChunkDir)

    chunkFiles = dir(fullfile(caseChunkDir, 'chunk_*.mat'));

    for k = 1:numel(chunkFiles)
        thisFile = fullfile(chunkFiles(k).folder, chunkFiles(k).name);
        try
            delete(thisFile);
        catch ME
            warning('Could not remove merged chunk MAT %s: %s', ...
                thisFile, ME.message);
        end
    end
end
