function s2case_driver(caseIndex, runId, workers, outputTag)

% Run or resume one independent case using a process pool, then merge.

clc; close all force;

nCases = 28;
nChunksPerCase = 51;

if nargin < 1 || isempty(caseIndex)
    caseIndex = str2double(getenv('PBS_ARRAY_INDEX'));
end
if nargin < 2 || isempty(runId)
    runId = getenv('STEP2_RUN_ID');
end
if nargin < 3 || isempty(workers)
    workers = 8;
end
if nargin < 4 || isempty(outputTag)
    outputTag = '0905';
end

if ~(isnumeric(caseIndex) && isscalar(caseIndex) && isfinite(caseIndex) && ...
        caseIndex == round(caseIndex) && caseIndex >= 1 && ...
        caseIndex <= nCases)
    error('caseIndex must be an integer from 1 to %d.', nCases);
end
if isempty(runId) || isempty(regexp(runId, '^[A-Za-z0-9_-]+$', 'once'))
    error('runId must contain only letters, numbers, underscore or hyphen.');
end
if ~(isnumeric(workers) && isscalar(workers) && isfinite(workers) && ...
        workers == round(workers) && workers >= 1 && workers <= 10)
    error('workers must be an integer from 1 to 10.');
end
if isempty(outputTag) || isempty(regexp(outputTag, '^[A-Za-z0-9_-]+$', 'once'))
    error('outputTag must contain only letters, numbers, underscore or hyphen.');
end

caseIndex = double(caseIndex);
workers = double(workers);

thisFile = mfilename('fullpath');
codeDir = fileparts(thisFile);
masterDir = fileparts(fileparts(codeDir));
manifestRunRoot = fullfile(masterDir, '06_MANIFESTS', ...
    'Step2_PLIF_interface_2.0', runId);
caseChunkDir = fullfile(manifestRunRoot, sprintf('case_%02d', caseIndex));
if ~exist(caseChunkDir, 'dir'), mkdir(caseChunkDir); end

% Bind resumable checkpoints to the exact source, case table and output tag.
sourceNames = {'s2case_driver.m','Step2_PLIF_interface_2_0_chunk.m', ...
    'Step2_PLIF_interface_2_0_merge.m','cases_28.csv'};
configuration = struct('outputTag', outputTag, 'sourceText', {{}});
for k = 1:numel(sourceNames)
    configuration.sourceText{k} = fileread(fullfile(codeDir, sourceNames{k}));
end
configurationFile = fullfile(caseChunkDir, 'run_configuration.mat');
if exist(configurationFile, 'file')
    prior = load(configurationFile, 'configuration');
    if ~isfield(prior, 'configuration') || ~isequal(prior.configuration, configuration)
        error('Source or output tag changed. Use a new run ID.');
    end
else
    if ~isempty(dir(fullfile(caseChunkDir, 'chunk_*')))
        error('Unbound checkpoints exist. Use a new run ID for this package.');
    end
    save(configurationFile, 'configuration');
end

T = readtable(fullfile(codeDir, 'cases_28.csv'), 'TextType', 'string');
distanceName = char(T.Distance(caseIndex));
caseName = char(T.CaseName(caseIndex));
phiTag = sprintf('phi%04d', round(T.PhiThEven(caseIndex)*1000));
outDir = fullfile(masterDir, '05_OUTPUTS', distanceName, caseName, ...
    sprintf('Y_interface_detection_method1_even_%s_final_%s', phiTag, outputTag));
doneFile = fullfile(outDir, sprintf('Step2_PLIF_interface_2.0_DONE_%s.txt', outputTag));
finalMat = fullfile(outDir, sprintf('interface_holes_%s_%s_%s_%s.mat', ...
    distanceName, caseName, phiTag, outputTag));
if exist(doneFile, 'file') && exist(finalMat, 'file')
    F = load(finalMat, 'Meta');
    if isfield(F, 'Meta') && isfield(F.Meta, 'runId') && strcmp(F.Meta.runId, runId)
        V = whos('-file', finalMat, 'ResultEven');
        if isempty(V) || prod(V.size) ~= F.Meta.nGoodEvenFramesProcessed
            error('Completed MAT has an inconsistent result count. Use a new run ID to rebuild.');
        end
        verifyCompletedImages(F.Meta);
        writeDriverStage(caseChunkDir, 'complete');
        fprintf('CASE ALREADY COMPLETE: %d / %d\n', caseIndex, nCases);
        return;
    end
end
% A new computation must not leave an old completion marker visible.
if exist(doneFile, 'file'), delete(doneFile); end

writeDriverStage(caseChunkDir, 'driver_entered');

fprintf('============================================================\n');
fprintf('s2case_driver | case %d / %d\n', caseIndex, nCases);
fprintf('Run ID: %s\n', runId);
fprintf('Output tag: %s\n', outputTag);
fprintf('Requested process workers: %d\n', workers);
fprintf('============================================================\n\n');

chunkIndicesToRun = zeros(0,1);
for chunkIndex = 1:nChunksPerCase
    chunkMat = fullfile(caseChunkDir, sprintf('chunk_%03d.mat', chunkIndex));
    chunkDone = fullfile(caseChunkDir, sprintf('chunk_%03d_DONE.txt', chunkIndex));
    if exist(chunkMat, 'file') && exist(chunkDone, 'file')
        fprintf('Existing checkpoint retained: case %02d chunk %03d\n', caseIndex, chunkIndex);
    else
        chunkIndicesToRun(end+1,1) = chunkIndex; %#ok<AGROW>
    end
end
writeDriverStage(caseChunkDir, 'chunk_scan_done');
fprintf('case %d: %d of %d chunks need to run\n', caseIndex, numel(chunkIndicesToRun), nChunksPerCase);

if ~isempty(chunkIndicesToRun)
    tmpRoot = getenv('TMPDIR');
    if isempty(tmpRoot)
        error('TMPDIR is empty. Run this function through the supplied PBS job.');
    end
    poolStorage = fullfile(tmpRoot, sprintf('parallel_case_%02d', caseIndex));
    if ~exist(poolStorage, 'dir'), mkdir(poolStorage); end

    oldPool = gcp('nocreate');
    if ~isempty(oldPool), delete(oldPool); end

    processCluster = parcluster('Processes');
    processCluster.JobStorageLocation = poolStorage;

    writeDriverStage(caseChunkDir, 'pool_starting');
    pool = parpool(processCluster, workers);
    writeDriverStage(caseChunkDir, 'pool_started');

    try
        parfor iChunk = 1:numel(chunkIndicesToRun)
            chunkIndex = chunkIndicesToRun(iChunk); %#ok<PFBNS>
            taskIndex = (caseIndex - 1) * nChunksPerCase + chunkIndex;
            fprintf('--- case %02d : chunk %03d / %d (task %d) ---\n', ...
                caseIndex, chunkIndex, nChunksPerCase, taskIndex);
            Step2_PLIF_interface_2_0_chunk(taskIndex, runId, outputTag);
        end
        writeDriverStage(caseChunkDir, 'parfor_completed');
    catch ME
        writeDriverStage(caseChunkDir, sprintf('FAILED: %s', ME.identifier));
        delete(pool);
        rethrow(ME);
    end

    delete(pool);
end

missingChunks = zeros(0,1);
for chunkIndex = 1:nChunksPerCase
    chunkMat = fullfile(caseChunkDir, sprintf('chunk_%03d.mat', chunkIndex));
    chunkDone = fullfile(caseChunkDir, sprintf('chunk_%03d_DONE.txt', chunkIndex));
    if ~exist(chunkMat, 'file') || ~exist(chunkDone, 'file')
        missingChunks(end+1,1) = chunkIndex; %#ok<AGROW>
    end
end
if ~isempty(missingChunks)
    writeDriverStage(caseChunkDir, sprintf('FAILED: missing chunks %s', mat2str(missingChunks.')));
    error('Case %d is missing chunk checkpoint(s): %s', caseIndex, mat2str(missingChunks.'));
end

writeDriverStage(caseChunkDir, 'about_to_merge');
Step2_PLIF_interface_2_0_merge(caseIndex, runId, outputTag, workers);
writeDriverStage(caseChunkDir, 'complete');

fprintf('\nCASE COMPLETE: %d / %d\n', caseIndex, nCases);

end

function writeDriverStage(caseChunkDir, tag)
    try
        fid = fopen(fullfile(caseChunkDir, 'STAGE_case.txt'), 'w');
        if fid > 0
            fprintf(fid, '%s | %s | host=%s | pid=%d\n', ...
                datestr(now, 'yyyy-mm-dd HH:MM:SS'), tag, ...
                getenv('HOSTNAME'), feature('getpid'));
            fclose(fid);
        end
    catch
    end
end

function verifyCompletedImages(M)
% Verify scheduled images before skipping a case whose chunks were released.
    plans = {M.diagnosticFrameNoPlanned, M.highResolutionFrameNoPlanned};
    folders = {M.diagnosticDir, M.highResolutionDir};
    stems = {'diagnostic','panel'};
    for k = 1:2
        for frame = double(plans{k}(:)).'
            imageFile = fullfile(folders{k}, sprintf( ...
                'PLIF_method1_%s_%04d_even_%s_FINAL.png', stems{k}, frame, M.phiTag));
            info = imfinfo(imageFile);
            if isempty(info) || info(1).Width < 1 || info(1).Height < 1
                error('Invalid completed PNG: %s', imageFile);
            end
        end
    end
end
