function Step2_PLIF_interface_2_0_chunk(taskIndex, runId, outputTag)

% Process 50 good even frames and publish checked images and a MAT checkpoint.
% Algorithm and execution instructions are in Step2_Readme.docx.

clc; close all force;

framesPerChunk = 50;
nominalEvenFrameCount = 2501;
nCases = 28;
nChunksPerCase = ceil(nominalEvenFrameCount / framesPerChunk);
nTotalChunkTasks = nCases * nChunksPerCase;

if nargin < 1 || isempty(taskIndex)
    taskIndex = str2double(getenv('PBS_ARRAY_INDEX'));
end
if nargin < 2 || isempty(runId)
    runId = getenv('STEP2_RUN_ID');
end
if nargin < 3 || isempty(outputTag)
    outputTag = '0905';
end

if ~(isnumeric(taskIndex) && isscalar(taskIndex) && isfinite(taskIndex) && ...
        taskIndex == round(taskIndex) && taskIndex >= 1 && ...
        taskIndex <= nTotalChunkTasks)
    error('taskIndex must be an integer from 1 to %d.', nTotalChunkTasks);
end
if isempty(runId) || isempty(regexp(runId, '^[A-Za-z0-9_-]+$', 'once'))
    error('runId must contain only letters, numbers, underscore or hyphen.');
end
if isempty(outputTag) || isempty(regexp(outputTag, '^[A-Za-z0-9_-]+$', 'once'))
    error('outputTag must contain only letters, numbers, underscore or hyphen.');
end

taskIndex = double(taskIndex);
caseIndex = floor((taskIndex - 1) / nChunksPerCase) + 1;
chunkIndex = mod(taskIndex - 1, nChunksPerCase) + 1;
globalIndexStart = (chunkIndex - 1) * framesPerChunk + 1;
globalIndexEndNominal = min(chunkIndex * framesPerChunk, nominalEvenFrameCount);

thisFile = mfilename('fullpath');
codeDir = fileparts(thisFile);
masterDir = fileparts(fileparts(codeDir));
caseTablePath = fullfile(codeDir, 'cases_28.csv');

if ~exist(caseTablePath, 'file')
    error('Cannot find 28-case manifest:\n%s', caseTablePath);
end

Cases = readtable(caseTablePath, 'TextType', 'string');
requiredColumns = {'Index','Distance','CaseName','PhiThEven'};
if ~all(ismember(requiredColumns, Cases.Properties.VariableNames))
    error('cases_28.csv must contain Index, Distance, CaseName, PhiThEven.');
end
if height(Cases) ~= nCases
    error('cases_28.csv must contain exactly %d cases. Found %d.', ...
        nCases, height(Cases));
end
if any(Cases.Index(:) ~= (1:nCases).')
    error('cases_28.csv Index column must be exactly 1:%d in order.', nCases);
end

thisCase = Cases(caseIndex,:);
distanceName = char(thisCase.Distance);
caseName = char(thisCase.CaseName);
phi_th_even = double(thisCase.PhiThEven);

if ~(isscalar(phi_th_even) && isfinite(phi_th_even) && phi_th_even > 0)
    error('Invalid PhiThEven for case %d.', caseIndex);
end

phiTag = sprintf('phi%04d', round(phi_th_even * 1000));
caseLabel = sprintf('%s / %s', distanceName, caseName);
versionTag = 'Step2_PLIF_interface_2.0';

plifDir = fullfile(masterDir, '02_INPUTS', 'PLIF', distanceName, caseName);
caseOutputRoot = fullfile(masterDir, '05_OUTPUTS', distanceName, caseName);

blackStripeFile = fullfile(caseOutputRoot, ...
    'PLIF_black_stripe_check_widthGT10_PLIF', ...
    'PLIF_black_stripe_check_widthGT10_results_PLIF.mat');
backgroundProfileFile = fullfile(caseOutputRoot, ...
    'PLIF_background_profile_col1980_2020', ...
    'PLIF_background_profile_col1980_2020_even_goodFrames.mat');
normalisationProfileFile = fullfile(caseOutputRoot, ...
    'PLIF_normalisation_profile_even_final', ...
    'PLIF_normalisation_profile_rawMean_bgCol1980_2020_even_goodFrames.mat');

outDir = fullfile(caseOutputRoot, ...
    sprintf('Y_interface_detection_method1_even_%s_final_%s', phiTag, outputTag));
diagnosticDir = fullfile(outDir, sprintf('Diagnostic_4panel_%s', outputTag));
highResolutionDir = fullfile(outDir, sprintf('High_resolution_panel_%s', outputTag));

manifestRunRoot = fullfile(masterDir, '06_MANIFESTS', ...
    'Step2_PLIF_interface_2.0', runId);
caseChunkDir = fullfile(manifestRunRoot, sprintf('case_%02d', caseIndex));
chunkMat = fullfile(caseChunkDir, sprintf('chunk_%03d.mat', chunkIndex));
chunkDone = fullfile(caseChunkDir, sprintf('chunk_%03d_DONE.txt', chunkIndex));

if ~exist(outDir, 'dir'), mkdir(outDir); end
if ~exist(diagnosticDir, 'dir'), mkdir(diagnosticDir); end
if ~exist(highResolutionDir, 'dir'), mkdir(highResolutionDir); end
if ~exist(caseChunkDir, 'dir'), mkdir(caseChunkDir); end

writeStageChunk(caseChunkDir, chunkIndex, 'chunk_entered');

tmpDir = getenv('TMPDIR');
if isempty(tmpDir)
    error(['TMPDIR environment variable is empty. ' ...
           'Run inside the supplied PBS chunk job.']);
end
localTaskDir = fullfile(tmpDir, sprintf('step2v2_case%02d_chunk%03d', ...
    caseIndex, chunkIndex));
if ~exist(localTaskDir, 'dir'), mkdir(localTaskDir); end
localTaskCleanup = onCleanup( ...
    @() cleanupLocalTaskDirectory(localTaskDir)); %#ok<NASGU>

writeStageChunk(caseChunkDir, chunkIndex, 'localtaskdir_ready');

fprintf('============================================================\n');
fprintf('Step2 PLIF interface + holes v2.0 | case-parallel chunk execution\n');
fprintf('Version: %s\n', versionTag);
fprintf('Run ID: %s\n', runId);
fprintf('PBS task: %d / %d\n', taskIndex, nTotalChunkTasks);
fprintf('Case: %d / %d | %s\n', caseIndex, nCases, caseLabel);
fprintf('Chunk: %d / %d | nominal good-list positions %d:%d\n', ...
    chunkIndex, nChunksPerCase, globalIndexStart, globalIndexEndNominal);
fprintf('Threshold: %.6f (%s)\n', phi_th_even, phiTag);
fprintf('Algorithm: connected-component label-based (v2.0)\n');
fprintf('Error policy: any safety-check failure stops this case immediately\n');
fprintf('============================================================\n\n');

epsDen = 1e-12;
diagnosticEveryNFrames = 20;
highResolutionEveryNFrames = 100;
figureVisibleMode = 'off';
diagnosticResolutionDPI = 1200;
highResolutionDPI = 1200;
phiDisplayCLim = [0 1.5];
cornerRadiusPx = 0.15;

set(groot, 'defaultFigureColor', 'w');
set(groot, 'defaultAxesFontName', 'Times New Roman');
set(groot, 'defaultTextFontName', 'Times New Roman');
set(groot, 'defaultAxesFontSize', 11);
set(groot, 'defaultTextFontSize', 11);
set(groot, 'defaultAxesLineWidth', 1.0);
set(groot, 'defaultLineLineWidth', 1.0);
set(groot, 'defaultAxesTickDir', 'out');
set(groot, 'defaultAxesBox', 'off');

interfaceCol       = [1.00 0.90 0.00];  % fluorescent yellow
holeBoundaryCol    = [0.85 0.05 0.05];  % red
unknownBoundaryCol = [0.65 0.65 0.65];  % bright grey
invalidMarkCol     = [0.65 0.65 0.65];  % same bright grey, used in panel (c)
blackCol           = [0 0 0];

requiredFiles = {blackStripeFile, backgroundProfileFile, ...
    normalisationProfileFile};
for iReq = 1:numel(requiredFiles)
    if ~exist(requiredFiles{iReq}, 'file')
        error('Required Step-1 input is missing:\n%s', requiredFiles{iReq});
    end
end
if ~exist(plifDir, 'dir')
    error('Cannot find PLIF input folder:\n%s', plifDir);
end

Sblack = load(blackStripeFile);
requiredBlackFields = {'frameNoEvenUse','pivFrameNoEvenUse', ...
    'badEvenFrameNos','badEvenFileNames','excludedPIVFrameNos'};
for iField = 1:numel(requiredBlackFields)
    if ~isfield(Sblack, requiredBlackFields{iField})
        error('Missing %s in:\n%s', requiredBlackFields{iField}, ...
            blackStripeFile);
    end
end

frameNoEven_toProcess = double(Sblack.frameNoEvenUse(:));
pivFrameNoEvenUse = double(Sblack.pivFrameNoEvenUse(:));

if isempty(frameNoEven_toProcess)
    error('Step-1 good-even list is empty for %s.', caseLabel);
end
if any(mod(frameNoEven_toProcess,2) ~= 0) || ...
        any(frameNoEven_toProcess < 100) || ...
        any(frameNoEven_toProcess > 5100) || ...
        numel(unique(frameNoEven_toProcess)) ~= numel(frameNoEven_toProcess)
    error('Invalid frameNoEvenUse in Step-1 black-stripe MAT.');
end
if any(diff(frameNoEven_toProcess) <= 0)
    error('frameNoEvenUse must be strictly increasing.');
end
if numel(pivFrameNoEvenUse) ~= numel(frameNoEven_toProcess) || ...
        any(pivFrameNoEvenUse ~= (frameNoEven_toProcess - 98)./2)
    error('pivFrameNoEvenUse is inconsistent with frameNoEvenUse.');
end

nProcess = numel(frameNoEven_toProcess);
globalIndexEnd = min(chunkIndex * framesPerChunk, nProcess);
if globalIndexStart <= nProcess
    globalIndices = (globalIndexStart:globalIndexEnd).';
else
    globalIndices = zeros(0,1);
end
frameNoChunk = frameNoEven_toProcess(globalIndices);

Sbg = load(backgroundProfileFile);
if ~isfield(Sbg, 'B_profile_even')
    error('Missing B_profile_even in:\n%s', backgroundProfileFile);
end
B_profile_even = double(Sbg.B_profile_even(:));
if any(~isfinite(B_profile_even))
    error('B_profile_even contains non-finite values:\n%s', backgroundProfileFile);
end
if isfield(Sbg,'frameNoEvenUse') && ...
        ~isequal(double(Sbg.frameNoEvenUse(:)), frameNoEven_toProcess)
    error('Background MAT frameNoEvenUse disagrees with black-stripe MAT.');
end
if isfield(Sbg,'pivFrameNoEvenUse') && ...
        ~isequal(double(Sbg.pivFrameNoEvenUse(:)), pivFrameNoEvenUse)
    error('Background MAT pivFrameNoEvenUse disagrees with black-stripe MAT.');
end

Snorm = load(normalisationProfileFile);
if ~isfield(Snorm, 'Phi_ref_even_forNorm')
    error('Missing Phi_ref_even_forNorm in:\n%s', normalisationProfileFile);
end
Phi_ref_even_forNorm = double(Snorm.Phi_ref_even_forNorm(:));
if isfield(Snorm,'yCL_col')
    yCL_col = double(Snorm.yCL_col);
else
    yCL_col = 514.45;
end
if isfield(Snorm,'frameNoEvenUse') && ...
        ~isequal(double(Snorm.frameNoEvenUse(:)), frameNoEven_toProcess)
    error('Normalisation MAT frameNoEvenUse disagrees with black-stripe MAT.');
end
if isfield(Snorm,'pivFrameNoEvenUse') && ...
        ~isequal(double(Snorm.pivFrameNoEvenUse(:)), pivFrameNoEvenUse)
    error('Normalisation MAT pivFrameNoEvenUse disagrees with black-stripe MAT.');
end
if any(~isfinite(Phi_ref_even_forNorm)) || ...
        any(Phi_ref_even_forNorm <= 0)
    error('Phi_ref_even_forNorm contains invalid values.');
end

[files, frameNo] = findTifFilesWithFrameNo(plifDir);
if numel(files) ~= 5002 || ~isequal(frameNo(:), (100:5101).')
    error(['PLIF input sequence is not exactly 5002 numeric frames ' ...
           '0100:5101. Found %d files.'], numel(files));
end
frameIndexByFrameNo = buildFrameIndexLookup(frameNo);

firstFrameNo = frameNoEven_toProcess(1);
idxFirst = frameIndexByFrameNo(firstFrameNo + 1);
I_test_raw = imread(fullfile(plifDir, files(idxFirst).name));
if ndims(I_test_raw) == 3, I_test_raw = rgb2gray(I_test_raw); end
[nRows,nCols] = size(I_test_raw);
intensityDisplayMax = getOriginalDisplayMax(I_test_raw);
intensityDisplayCLim = [0 intensityDisplayMax];
clear I_test_raw

if nRows ~= 1600 || nCols ~= 2560
    error('Expected image size 1600 x 2560, found %d x %d.', nRows, nCols);
end
if numel(B_profile_even) ~= nRows
    error('B_profile_even length does not match image rows.');
end
if numel(Phi_ref_even_forNorm) ~= nRows
    error('Phi_ref_even_forNorm length does not match image rows.');
end

P = struct();
P.plifDir = plifDir;
P.nRows = nRows;
P.nCols = nCols;
P.epsDen = epsDen;
P.intensityDisplayCLim = intensityDisplayCLim;
P.phiDisplayCLim = phiDisplayCLim;
P.yCL_col = yCL_col;
P.centreBandHalfWidth = 25;
P.minHoleAreaPx = 0; % Hole area filtering disabled; retain every selected hole.
P.minWakeOneAreaPx = 200;
P.cornerRadiusPx = cornerRadiusPx;
P.interfaceCol = interfaceCol;
P.holeBoundaryCol = holeBoundaryCol;
P.unknownBoundaryCol = unknownBoundaryCol;
P.invalidMarkCol = invalidMarkCol;
P.blackCol = blackCol;
P.figureVisibleMode = figureVisibleMode;
P.diagnosticResolutionDPI = diagnosticResolutionDPI;
P.highResolutionDPI = highResolutionDPI;

nChunkFrames = numel(globalIndices);
ResultChunk = repmat(makeEmptyResultV2(), nChunkFrames, 1);
chunkStartDatenum = now;
tic;

writeStageChunk(caseChunkDir, chunkIndex, ...
    sprintf('about_to_start_frame_loop_n%d', nChunkFrames));

for localK = 1:nChunkFrames
    globalK = globalIndices(localK);
    thisFrameNo = frameNoChunk(localK);
    thisFrameTag = sprintf('%04d', thisFrameNo);

    if mod(localK - 1, 10) == 0
        writeStageChunk(caseChunkDir, chunkIndex, ...
            sprintf('processing_frame_%d_of_%d_frameNo%s', ...
            localK, nChunkFrames, thisFrameTag));
    end

    fprintf('[chunk %03d | %2d/%2d | global %4d/%4d] Frame %s\n', ...
        chunkIndex, localK, nChunkFrames, globalK, nProcess, thisFrameTag);

    idxThis = frameIndexByFrameNo(thisFrameNo + 1);
    if isnan(idxThis)
        error('Cannot find frame %04d.', thisFrameNo);
    end
    thisFile = files(idxThis);

    Diag = processOneFrameV2(thisFile, thisFrameNo, phi_th_even, ...
        B_profile_even, Phi_ref_even_forNorm, P, caseIndex, chunkIndex);

    thisResult = diagToResultRecord(Diag);

    localDiagnostic = '';
    localHighRes = '';

    if mod(globalK - 1, diagnosticEveryNFrames) == 0
        diagnosticName = sprintf( ...
            'PLIF_method1_diagnostic_%s_even_%s_FINAL.png', ...
            thisFrameTag, phiTag);
        localDiagnostic = fullfile(localTaskDir, diagnosticName);
        finalDiagnostic = fullfile(diagnosticDir, diagnosticName);
        plotFourPanelDiagnostic(Diag, localDiagnostic, P);
        validatePngFile(localDiagnostic);
        publishFileAtomically(localDiagnostic, finalDiagnostic);
    end

    if mod(globalK - 1, highResolutionEveryNFrames) == 0
        highResName = sprintf( ...
            'PLIF_method1_panel_%s_even_%s_FINAL.png', ...
            thisFrameTag, phiTag);
        localHighRes = fullfile(localTaskDir, highResName);
        finalHighRes = fullfile(highResolutionDir, highResName);
        plotHighResolutionPanel(Diag, localHighRes, P);
        validatePngFile(localHighRes);
        publishFileAtomically(localHighRes, finalHighRes);
    end

    fprintf(['    status = %-22s | background = %6d px | wake(dye) = %7d px | ' ...
             'holes = %3d (%6d px) | unknown = %3d (%6d px) | invalid = %5d px\n'], ...
        thisResult.status, thisResult.nBackgroundPixels, ...
        thisResult.nWakeDyePixels, thisResult.nHoles, ...
        sum(thisResult.holeArea_px), thisResult.nUnknown, ...
        sum(thisResult.unknownArea_px), thisResult.nInvalidPixels);

    cleanupLocalFileIfPresent(localDiagnostic);
    cleanupLocalFileIfPresent(localHighRes);

    ResultChunk(localK) = thisResult;
    close all force;
end

chunkElapsedMin = toc / 60;
chunkFinishDatenum = now;

ChunkMeta = struct();
ChunkMeta.version = versionTag;
ChunkMeta.runId = runId;
ChunkMeta.taskIndex = taskIndex;
ChunkMeta.caseIndex = caseIndex;
ChunkMeta.distance = distanceName;
ChunkMeta.caseName = caseName;
ChunkMeta.phi_th_even = phi_th_even;
ChunkMeta.phiTag = phiTag;
ChunkMeta.framesPerChunk = framesPerChunk;
ChunkMeta.nChunksPerCase = nChunksPerCase;
ChunkMeta.chunkIndex = chunkIndex;
ChunkMeta.globalIndices = globalIndices;
ChunkMeta.frameNoChunk = frameNoChunk;
ChunkMeta.nChunkFrames = nChunkFrames;
ChunkMeta.nGoodEvenFramesCase = nProcess;
ChunkMeta.chunkStartDatenum = chunkStartDatenum;
ChunkMeta.chunkFinishDatenum = chunkFinishDatenum;
ChunkMeta.chunkElapsedMin = chunkElapsedMin;
ChunkMeta.host = getenv('HOSTNAME');
ChunkMeta.pbsJobId = getenv('PBS_JOBID');
ChunkMeta.pbsArrayIndex = getenv('PBS_ARRAY_INDEX');

writeStageChunk(caseChunkDir, chunkIndex, 'about_to_save_chunk_mat');
localChunkMat = fullfile(localTaskDir, sprintf('chunk_%03d.mat', chunkIndex));
save(localChunkMat, 'ResultChunk', 'ChunkMeta', '-v7.3');
publishFileAtomically(localChunkMat, chunkMat);
writeStageChunk(caseChunkDir, chunkIndex, 'chunk_mat_saved');

writeChunkDoneText(chunkDone, ChunkMeta, ResultChunk, chunkMat);
writeStageChunk(caseChunkDir, chunkIndex, 'chunk_complete');

fprintf('============================================================\n');
fprintf('CHUNK COMPLETE\n');
fprintf('Case: %s\n', caseLabel);
fprintf('Chunk: %d / %d\n', chunkIndex, nChunksPerCase);
fprintf('Frames processed: %d\n', nChunkFrames);
fprintf('Elapsed: %.2f min\n', chunkElapsedMin);
fprintf('Chunk MAT: %s\n', chunkMat);
fprintf('============================================================\n');

end

function writeStageChunk(caseChunkDir, chunkIndex, tag)
    try
        fname = fullfile(caseChunkDir, sprintf('STAGE_chunk_%03d.txt', chunkIndex));
        fid = fopen(fname, 'w');
        if fid > 0
            fprintf(fid, '%s | %s | host=%s | pid=%d\n', ...
                datestr(now, 'yyyy-mm-dd HH:MM:SS'), tag, ...
                getenv('HOSTNAME'), feature('getpid'));
            fclose(fid);
        end
    catch
    end
end

function R = makeEmptyResultV2()

    R = struct();
    R.frameNo = NaN;
    R.frameName = '';
    R.status = 'not_processed';
    R.isValidFrame = false;

    R.backgroundPixelIdx = zeros(0,1,'uint32');
    R.backgroundRC = zeros(0,2,'uint32');
    R.nBackgroundPixels = 0;

    R.wakePixelIdx = zeros(0,1,'uint32');
    R.wakeRC = zeros(0,2,'uint32');
    R.nWakePixels = 0;
    R.nWakeDyePixels = 0;

    R.nWake1 = 0;
    R.wake1ID = zeros(0,1);
    R.wake1PixelIdx = {};
    R.wake1RC = {};
    R.wake1Area_px = zeros(0,1);

    R.nWake2 = 0;
    R.wake2ID = zeros(0,1);
    R.wake2PixelIdx = {};
    R.wake2RC = {};
    R.wake2Area_px = zeros(0,1);

    R.nHoles = 0;
    R.holeID = zeros(0,1);
    R.holePixelIdx = {};
    R.holeRC = {};
    R.holeArea_px = zeros(0,1);
    R.holeBoundaryRC = {};
    R.nSmallHolesFiltered = 0;

    R.nUnknown = 0;
    R.unknownID = zeros(0,1);
    R.unknownPixelIdx = {};
    R.unknownRC = {};
    R.unknownArea_px = zeros(0,1);
    R.unknownBoundaryRC = {};

    R.interfaceRC = {};
    R.nInterfaceSegments = 0;

    R.invalidPixelIdx = zeros(0,1,'uint32');
    R.invalidRC = zeros(0,2,'uint32');
    R.nInvalidPixels = 0;
end

function [files, frameNo] = findTifFilesWithFrameNo(folderPath)

    files = [ ...
        dir(fullfile(folderPath, '*.tif')); ...
        dir(fullfile(folderPath, '*.TIF')); ...
        dir(fullfile(folderPath, '*.tiff')); ...
        dir(fullfile(folderPath, '*.TIFF'))];

    if isempty(files)
        frameNo = [];
        return;
    end

    fullPaths = fullfile({files.folder}', {files.name}');
    [~, uniqueIdx] = unique(lower(fullPaths), 'stable');
    files = files(uniqueIdx);

    frameNo = nan(numel(files), 1);
    for k = 1:numel(files)
        token = regexp(files(k).name, '(\d+)(?=\.[^.]+$)', 'tokens', 'once');
        if ~isempty(token)
            frameNo(k) = str2double(token{1});
        end
    end

    valid = ~isnan(frameNo);
    files = files(valid);
    frameNo = frameNo(valid);

    [frameNo, idx] = sort(frameNo);
    files = files(idx);
end

function lookup = buildFrameIndexLookup(frameNo)

    maxFrameNo = max(frameNo);
    lookup = nan(maxFrameNo + 1, 1);
    for k = 1:numel(frameNo)
        f = frameNo(k);
        if f >= 0
            lookup(f + 1) = k;
        end
    end
end

function displayMax = getOriginalDisplayMax(I)

    switch class(I)
        case 'uint8'
            displayMax = double(intmax('uint8'));
        case 'uint16'
            displayMax = double(intmax('uint16'));
        case 'uint32'
            displayMax = double(intmax('uint32'));
        case {'single', 'double'}
            maxVal = max(I(:));
            if maxVal <= 1
                displayMax = 1;
            else
                displayMax = maxVal;
            end
        otherwise
            displayMax = max(double(I(:)));
    end

    if ~isfinite(displayMax) || displayMax <= 0
        error('Invalid image display maximum.');
    end
end

function Diag = processOneFrameV2(fileStruct, frameNo, phi_th, ...
    B_profile, Phi_ref_forNorm, P, caseIndex, chunkIndex)

    inFile = fullfile(P.plifDir, fileStruct.name);
    I_raw_original = imread(inFile);
    if ndims(I_raw_original) == 3
        I_raw_original = rgb2gray(I_raw_original);
    end
    I_raw = double(I_raw_original);

    if ~isequal(size(I_raw), [P.nRows P.nCols])
        error('Image size mismatch:\n%s', inFile);
    end

    I_clean = bsxfun(@minus, I_raw, B_profile(:));
    I_clean(I_clean < 0) = 0;
    phiStar = bsxfun(@rdivide, I_clean, max(Phi_ref_forNorm(:), P.epsDen));

    E = extractLabelsV2(phiStar, phi_th, P.nRows, P.nCols, frameNo, ...
        caseIndex, chunkIndex, P.yCL_col, P.centreBandHalfWidth, ...
        P.minHoleAreaPx, P.minWakeOneAreaPx);

    Diag = struct();
    Diag.frameNo = frameNo;
    Diag.frameName = fileStruct.name;
    Diag.phi_th = phi_th;
    Diag.I_raw = I_raw;
    Diag.phiStar = phiStar;
    Diag.E = E;
end

function E = extractLabelsV2(phiStar, phi_th, nRows, nCols, frameNo, ...
    caseIndex, chunkIndex, yCL_col, centreBandHalfWidth, minHoleAreaPx, ...
    minWakeOneAreaPx)

    ctxTag = sprintf('case %d chunk %d frame %04d', ...
        caseIndex, chunkIndex, frameNo);

    % Exclude non-finite pixels before thresholding.
    invalidMask = ~isfinite(phiStar);
    validMask = ~invalidMask;
    zeroMask = validMask & (phiStar < phi_th);
    oneMask = validMask & (phiStar >= phi_th);

    if nnz(zeroMask) + nnz(oneMask) + nnz(invalidMask) ~= nRows*nCols
        error(['Step2 v2.0 SAFETY CHECK FAILED [%s]: zero/one/invalid ' ...
            'masks do not partition the image (%d + %d + %d ~= %d). ' ...
            'This indicates a coding bug in the binarisation step, not ' ...
            'a data problem. Case stopped.'], ctxTag, nnz(zeroMask), ...
            nnz(oneMask), nnz(invalidMask), nRows*nCols);
    end

    invalidPixelIdx = uint32(find(invalidMask));
    if isempty(invalidPixelIdx)
        invalidRC = zeros(0,2,'uint32');
    else
        [ir, ic] = ind2sub([nRows nCols], double(invalidPixelIdx));
        invalidRC = uint32([ir ic]);
    end

    E = emptyLabelFieldsV2();
    E.invalidPixelIdx = invalidPixelIdx;
    E.invalidRC = invalidRC;
    E.nInvalidPixels = numel(invalidPixelIdx);

    % Label the zero side by shared edges.
    CC = bwconncomp(zeroMask, 4);
    nComp = CC.NumObjects;

    if nComp == 0
        E.isValidFrame = false;
        E.status = 'invalid_no_background';
        E.nWakeDyePixels = nnz(oneMask);
        return;
    end

    zeroLabel = labelmatrix(CC);

    % Background components touch the last image column.
    isBackgroundComp = false(nComp,1);
    for i = 1:nComp
        idx = CC.PixelIdxList{i};
        [~, c] = ind2sub([nRows nCols], idx);
        isBackgroundComp(i) = any(c == nCols);
    end

    backgroundCompLabels = find(isBackgroundComp);

    if isempty(backgroundCompLabels)
        E.isValidFrame = false;
        E.status = 'invalid_no_background';
        E.nWakeDyePixels = nnz(oneMask);
        return;
    end

    backgroundPixelIdx = sort(vertcat(CC.PixelIdxList{backgroundCompLabels}));
    backgroundMask = false(nRows,nCols);
    backgroundMask(backgroundPixelIdx) = true;

    [rB, cB] = ind2sub([nRows nCols], backgroundPixelIdx);
    if ~any(cB == nCols)
        error(['Step2 v2.0 SAFETY CHECK FAILED [%s]: background was ' ...
            'selected but does not actually touch the right edge. ' ...
            'Case stopped.'], ctxTag);
    end

    % Other zero components touching the first column or either row edge are unknown.
    nonBackgroundCompLabels = find(~isBackgroundComp);
    isUnknownComp = false(nComp,1);
    for kk = 1:numel(nonBackgroundCompLabels)
        i = nonBackgroundCompLabels(kk);
        idx = CC.PixelIdxList{i};
        [r, c] = ind2sub([nRows nCols], idx);
        isUnknownComp(i) = any(c == 1) | any(r == 1) | any(r == nRows);
    end
    isCandidateComp = ~isBackgroundComp & ~isUnknownComp;

    candidateCompLabels = find(isCandidateComp);
    unknownCompLabels = find(isUnknownComp);

    nUnknown = numel(unknownCompLabels);
    [unknownID, unknownPixelIdx, unknownRC, unknownArea_px, unknownMaskCombined] = ...
        buildComponentLists(CC, unknownCompLabels, nRows, nCols);

    candidateMask = false(nRows, nCols);
    for kk = 1:numel(candidateCompLabels)
        candidateMask(CC.PixelIdxList{candidateCompLabels(kk)}) = true;
    end

    % Label the one side using edges and corners.
    CC1 = bwconncomp(oneMask, 8);
    nComp1 = CC1.NumObjects;
    crossesCentrelineComp = false(nComp1,1);
    for i = 1:nComp1
        idx = CC1.PixelIdxList{i};
        [~, c] = ind2sub([nRows nCols], idx);
        crossesCentrelineComp(i) = any(c >= yCL_col - centreBandHalfWidth & ...
            c <= yCL_col + centreBandHalfWidth);
    end

    % Wake1 requires centreline-band intersection and area strictly above 200 pixels.
    areaComp1 = cellfun(@numel, CC1.PixelIdxList)';
    isWakeOneComp = crossesCentrelineComp & (areaComp1 > minWakeOneAreaPx);
    wakeOneCompLabels = find(isWakeOneComp);
    wakeOneMask = false(nRows, nCols);
    for kk = 1:numel(wakeOneCompLabels)
        wakeOneMask(CC1.PixelIdxList{wakeOneCompLabels(kk)}) = true;
    end
    nonWakeOneMask = oneMask & ~wakeOneMask;

    nWake1 = numel(wakeOneCompLabels);
    wake1CompLabels = wakeOneCompLabels;
    [wake1ID, wake1PixelIdx, wake1RC, wake1Area_px, wake1MaskCheck] = ...
        buildComponentLists(CC1, wake1CompLabels, nRows, nCols);
    if ~isequal(wake1MaskCheck, wakeOneMask)
        error(['Step2 v2.0 SAFETY CHECK FAILED [%s]: wake1.0 per-block ' ...
            'numbering does not reconstruct the same pixel set as ' ...
            'wakeOneMask. Case stopped.'], ctxTag);
    end
    wake1Label = labelmatrix(CC1);

    % A candidate hole needs at least one edge-adjacent wake1 pixel.
    touchesWakePairs = findCracks(candidateMask, wakeOneMask, nRows, nCols);
    touchesWakeComp = false(nComp,1);
    if ~isempty(touchesWakePairs)
        idxSide1 = sub2ind([nRows nCols], double(touchesWakePairs(:,1)), double(touchesWakePairs(:,2)));
        touchesWakeComp(unique(double(zeroLabel(idxSide1)))) = true;
    end

    isHoleComp = isCandidateComp & touchesWakeComp;
    holeCompLabels = find(isHoleComp);

    [holeIDAll, holePixelIdxAll, holeRCAll, holeArea_pxAll, holeMaskCombinedAll] = ...
        buildComponentLists(CC, holeCompLabels, nRows, nCols);
    nHolesAll = numel(holeCompLabels);

    for k = 1:nHolesAll
        rc = holeRCAll{k};
        if any(rc(:,2) == 1) || any(rc(:,1) == 1) || any(rc(:,1) == nRows)
            error(['Step2 v2.0 SAFETY CHECK FAILED [%s]: hole %d ' ...
                'touches an excluded edge but was not reclassified as ' ...
                'unknown. Case stopped.'], ctxTag, k);
        end
    end

    % Retain every selected hole, including areas of 1, 2 and 3 pixels.
    keptHoleCompLabels = holeCompLabels;
    nHoles = numel(keptHoleCompLabels);
    nSmallHolesFiltered = 0;

    [holeID, holePixelIdx, holeRC, holeArea_px, holeMaskCombinedFormal] = ...
        buildComponentLists(CC, keptHoleCompLabels, nRows, nCols);

    % Wake2 touches holes and has no edge-adjacent non-hole zero pixel.
    nonHoleZeroMask = zeroMask & ~holeMaskCombinedAll;
    touchesHolePairs1 = findCracks(nonWakeOneMask, holeMaskCombinedAll, nRows, nCols);
    touchesNonHolePairs1 = findCracks(nonWakeOneMask, nonHoleZeroMask, nRows, nCols);

    touchesHoleComp1 = false(nComp1,1);
    if ~isempty(touchesHolePairs1)
        idxA = sub2ind([nRows nCols], double(touchesHolePairs1(:,1)), double(touchesHolePairs1(:,2)));
        touchesHoleComp1(unique(double(wake1Label(idxA)))) = true;
    end
    touchesNonHoleComp1 = false(nComp1,1);
    if ~isempty(touchesNonHolePairs1)
        idxA = sub2ind([nRows nCols], double(touchesNonHolePairs1(:,1)), double(touchesNonHolePairs1(:,2)));
        touchesNonHoleComp1(unique(double(wake1Label(idxA)))) = true;
    end

    isWake2Comp = ~isWakeOneComp & touchesHoleComp1 & ~touchesNonHoleComp1;
    wake2CompLabels = find(isWake2Comp);
    nWake2 = numel(wake2CompLabels);
    [wake2ID, wake2PixelIdx, wake2RC, wake2Area_px, wake2Mask] = ...
        buildComponentLists(CC1, wake2CompLabels, nRows, nCols);

    % Final wake is the union of wake1, wake2 and all hole pixels.
    wakeMask = wakeOneMask | wake2Mask | holeMaskCombinedAll;
    wakePixelIdx = uint32(find(wakeMask));
    [rW, cW] = ind2sub([nRows nCols], double(wakePixelIdx));
    wakeRC = uint32([rW cW]);
    nWakeDyePixels = nnz(wakeOneMask | wake2Mask);

    if nnz(backgroundMask & holeMaskCombinedAll) ~= 0 || ...
            nnz(backgroundMask & unknownMaskCombined) ~= 0 || ...
            nnz(holeMaskCombinedAll & unknownMaskCombined) ~= 0 || ...
            nnz(wakeOneMask & wake2Mask) ~= 0
        error(['Step2 v2.0 SAFETY CHECK FAILED [%s]: background/hole/' ...
            'unknown/wake1.0/wake2.0 pixel sets overlap. Case stopped.'], ...
            ctxTag);
    end

    % Interface pairs run from background to wake1 and are grouped by wake1 ID.
    interfaceRC = attributeCracksBySideB(backgroundMask, wakeOneMask, ...
        wake1Label, wake1CompLabels, nWake1, nRows, nCols);

    % Hole boundaries pair each hole pixel with any edge-adjacent one-side pixel.
    holeBoundaryRC = attributeCracks(holeMaskCombinedFormal, oneMask, ...
        zeroLabel, keptHoleCompLabels, nHoles, nRows, nCols);

    unknownBoundaryRC = attributeCracks(unknownMaskCombined, oneMask, ...
        zeroLabel, unknownCompLabels, nUnknown, nRows, nCols);

    nBackgroundPixels = numel(backgroundPixelIdx);

    E.isValidFrame = true;
    E.status = 'ok';
    E.backgroundPixelIdx = uint32(sort(backgroundPixelIdx));
    E.backgroundRC = uint32([rB cB]);
    E.nBackgroundPixels = nBackgroundPixels;
    E.wakePixelIdx = wakePixelIdx;
    E.wakeRC = wakeRC;
    E.nWakePixels = numel(wakePixelIdx);
    E.nWakeDyePixels = nWakeDyePixels;
    E.nWake1 = nWake1;
    E.wake1ID = wake1ID;
    E.wake1PixelIdx = wake1PixelIdx;
    E.wake1RC = wake1RC;
    E.wake1Area_px = wake1Area_px;
    E.nWake2 = nWake2;
    E.wake2ID = wake2ID;
    E.wake2PixelIdx = wake2PixelIdx;
    E.wake2RC = wake2RC;
    E.wake2Area_px = wake2Area_px;
    E.nHoles = nHoles;
    E.holeID = holeID;
    E.holePixelIdx = holePixelIdx;
    E.holeRC = holeRC;
    E.holeArea_px = holeArea_px;
    E.holeBoundaryRC = holeBoundaryRC;
    E.nSmallHolesFiltered = nSmallHolesFiltered;
    E.nUnknown = nUnknown;
    E.unknownID = unknownID;
    E.unknownPixelIdx = unknownPixelIdx;
    E.unknownRC = unknownRC;
    E.unknownArea_px = unknownArea_px;
    E.unknownBoundaryRC = unknownBoundaryRC;
    E.interfaceRC = interfaceRC;
    E.nInterfaceSegments = sum(cellfun(@(c) size(c,1), interfaceRC));
end

function E = emptyLabelFieldsV2()

    E = struct();
    E.isValidFrame = false;
    E.status = 'invalid_no_background';

    E.backgroundPixelIdx = zeros(0,1,'uint32');
    E.backgroundRC = zeros(0,2,'uint32');
    E.nBackgroundPixels = 0;

    E.wakePixelIdx = zeros(0,1,'uint32');
    E.wakeRC = zeros(0,2,'uint32');
    E.nWakePixels = 0;
    E.nWakeDyePixels = 0;

    E.nWake1 = 0;
    E.wake1ID = zeros(0,1);
    E.wake1PixelIdx = {};
    E.wake1RC = {};
    E.wake1Area_px = zeros(0,1);

    E.nWake2 = 0;
    E.wake2ID = zeros(0,1);
    E.wake2PixelIdx = {};
    E.wake2RC = {};
    E.wake2Area_px = zeros(0,1);

    E.nHoles = 0;
    E.holeID = zeros(0,1);
    E.holePixelIdx = {};
    E.holeRC = {};
    E.holeArea_px = zeros(0,1);
    E.holeBoundaryRC = {};
    E.nSmallHolesFiltered = 0;

    E.nUnknown = 0;
    E.unknownID = zeros(0,1);
    E.unknownPixelIdx = {};
    E.unknownRC = {};
    E.unknownArea_px = zeros(0,1);
    E.unknownBoundaryRC = {};

    E.interfaceRC = {};
    E.nInterfaceSegments = 0;

    E.invalidPixelIdx = zeros(0,1,'uint32');
    E.invalidRC = zeros(0,2,'uint32');
    E.nInvalidPixels = 0;
end

function [compID, pixelIdxCell, rcCell, area_px, combinedMask] = ...
    buildComponentLists(CC, compLabels, nRows, nCols)

    n = numel(compLabels);
    compID = (1:n)';
    pixelIdxCell = cell(n,1);
    rcCell = cell(n,1);
    area_px = zeros(n,1);
    combinedMask = false(nRows,nCols);

    for k = 1:n
        idx = CC.PixelIdxList{compLabels(k)};
        pixelIdxCell{k} = uint32(idx);
        [r, c] = ind2sub([nRows nCols], idx);
        rcCell{k} = uint32([r c]);
        area_px(k) = numel(idx);
        combinedMask(idx) = true;
    end
end

function boundaryCell = attributeCracks(sideAMaskCombined, sideBMask, ...
    zeroLabel, compLabels, nComp, nRows, nCols)

    boundaryCell = cell(nComp,1);
    for k = 1:nComp
        boundaryCell{k} = zeros(0,4,'uint32');
    end
    if nComp == 0
        return;
    end

    pairsRC = findCracks(sideAMaskCombined, sideBMask, nRows, nCols);
    if isempty(pairsRC)
        return;
    end

    idxSide1 = sub2ind([nRows nCols], double(pairsRC(:,1)), double(pairsRC(:,2)));
    compOfSide1 = double(zeroLabel(idxSide1));

    idLookup = zeros(max(compLabels),1);
    idLookup(compLabels) = (1:nComp)';

    assignedID = zeros(size(compOfSide1));
    validLookup = compOfSide1 >= 1 & compOfSide1 <= numel(idLookup);
    assignedID(validLookup) = idLookup(compOfSide1(validLookup));

    for k = 1:nComp
        boundaryCell{k} = pairsRC(assignedID == k, :);
    end
end

function boundaryCell = attributeCracksBySideB(sideAMask, sideBMaskCombined, ...
    sideBLabel, compLabels, nComp, nRows, nCols)

    boundaryCell = cell(nComp,1);
    for k = 1:nComp
        boundaryCell{k} = zeros(0,4,'uint32');
    end
    if nComp == 0
        return;
    end

    pairsRC = findCracks(sideAMask, sideBMaskCombined, nRows, nCols);
    if isempty(pairsRC)
        return;
    end

    idxSideB = sub2ind([nRows nCols], double(pairsRC(:,3)), double(pairsRC(:,4)));
    compOfSideB = double(sideBLabel(idxSideB));

    idLookup = zeros(max(compLabels),1);
    idLookup(compLabels) = (1:nComp)';

    assignedID = zeros(size(compOfSideB));
    validLookup = compOfSideB >= 1 & compOfSideB <= numel(idLookup);
    assignedID(validLookup) = idLookup(compOfSideB(validLookup));

    for k = 1:nComp
        boundaryCell{k} = pairsRC(assignedID == k, :);
    end
end

function pairsRC = findCracks(maskA, maskB, nRows, nCols)

    pairsRC = zeros(0,4);

    hit = maskA(:,1:nCols-1) & maskB(:,2:nCols);
    [r, c] = find(hit);
    if ~isempty(r)
        pairsRC = [pairsRC; [r c r c+1]]; %#ok<AGROW>
    end

    hit = maskA(:,2:nCols) & maskB(:,1:nCols-1);
    [r, c] = find(hit);
    if ~isempty(r)
        pairsRC = [pairsRC; [r c+1 r c]]; %#ok<AGROW>
    end

    hit = maskA(1:nRows-1,:) & maskB(2:nRows,:);
    [r, c] = find(hit);
    if ~isempty(r)
        pairsRC = [pairsRC; [r c r+1 c]]; %#ok<AGROW>
    end

    hit = maskA(2:nRows,:) & maskB(1:nRows-1,:);
    [r, c] = find(hit);
    if ~isempty(r)
        pairsRC = [pairsRC; [r+1 c r c]]; %#ok<AGROW>
    end

    pairsRC = uint32(pairsRC);
end

function R = diagToResultRecord(Diag)

    E = Diag.E;
    R = makeEmptyResultV2();
    R.frameNo = Diag.frameNo;
    R.frameName = Diag.frameName;
    R.status = E.status;
    R.isValidFrame = E.isValidFrame;

    R.backgroundPixelIdx = E.backgroundPixelIdx;
    R.backgroundRC = E.backgroundRC;
    R.nBackgroundPixels = E.nBackgroundPixels;

    R.wakePixelIdx = E.wakePixelIdx;
    R.wakeRC = E.wakeRC;
    R.nWakePixels = E.nWakePixels;
    R.nWakeDyePixels = E.nWakeDyePixels;

    R.nWake1 = E.nWake1;
    R.wake1ID = E.wake1ID;
    R.wake1PixelIdx = E.wake1PixelIdx;
    R.wake1RC = E.wake1RC;
    R.wake1Area_px = E.wake1Area_px;

    R.nWake2 = E.nWake2;
    R.wake2ID = E.wake2ID;
    R.wake2PixelIdx = E.wake2PixelIdx;
    R.wake2RC = E.wake2RC;
    R.wake2Area_px = E.wake2Area_px;

    R.nHoles = E.nHoles;
    R.holeID = E.holeID;
    R.holePixelIdx = E.holePixelIdx;
    R.holeRC = E.holeRC;
    R.holeArea_px = E.holeArea_px;
    R.holeBoundaryRC = E.holeBoundaryRC;
    R.nSmallHolesFiltered = E.nSmallHolesFiltered;

    R.nUnknown = E.nUnknown;
    R.unknownID = E.unknownID;
    R.unknownPixelIdx = E.unknownPixelIdx;
    R.unknownRC = E.unknownRC;
    R.unknownArea_px = E.unknownArea_px;
    R.unknownBoundaryRC = E.unknownBoundaryRC;

    R.interfaceRC = E.interfaceRC;
    R.nInterfaceSegments = E.nInterfaceSegments;

    R.invalidPixelIdx = E.invalidPixelIdx;
    R.invalidRC = E.invalidRC;
    R.nInvalidPixels = E.nInvalidPixels;
end

function plotFourPanelDiagnostic(Diag, outFig, P)

    applyWorkerGraphicsDefaults();

    fig = figure('Color', 'w', 'Visible', P.figureVisibleMode, ...
        'Units', 'centimeters', 'Position', [1.5 1.5 26 20], ...
        'Name', 'Method 1 v2.0 interface + holes', 'NumberTitle', 'off');
    figureCleanup = onCleanup(@() closeFigureIfValid(fig)); %#ok<NASGU>

    marginLeft = 0.075; marginRight = 0.015;
    marginBottom = 0.06; marginTop = 0.015;
    gapX = 0.12;
    gapY = 0.020;
    tileW = (1 - marginLeft - marginRight - gapX) / 2;
    tileH = (1 - marginBottom - marginTop - gapY) / 2;
    posTL = [marginLeft,            marginBottom+tileH+gapY, tileW, tileH];
    posTR = [marginLeft+tileW+gapX, marginBottom+tileH+gapY, tileW, tileH];
    posBL = [marginLeft,            marginBottom,            tileW, tileH];
    posBR = [marginLeft+tileW+gapX, marginBottom,            tileW, tileH];

    axA = axes(fig, 'Units', 'normalized', 'Position', posTL);
    imagesc(axA, Diag.I_raw);
    axis(axA, 'image');
    set(axA, 'YDir', 'reverse');
    colormap(axA, gray);
    caxis(axA, P.intensityDisplayCLim);
    cbA = colorbar(axA);
    cbA.Label.String = 'raw intensity';
    cbA.TickDirection = 'out';
    hold(axA, 'on');
    line(axA, [P.yCL_col P.yCL_col], [1 P.nRows], 'Color', 'r', ...
        'LineStyle', '--', 'LineWidth', 0.8);
    hold(axA, 'off');
    xlabel(axA, 'y (pixel)');
    ylabel(axA, 'x (pixel)');
    title(axA, '(a) raw PLIF', 'FontWeight', 'normal');

    axB = axes(fig, 'Units', 'normalized', 'Position', posTR);
    imagesc(axB, Diag.phiStar);
    axis(axB, 'image');
    set(axB, 'YDir', 'reverse');
    colormap(axB, blueWhiteColormap());
    caxis(axB, P.phiDisplayCLim);
    cbB = colorbar(axB);
    cbB.Label.String = '\phi^*';
    cbB.TickDirection = 'out';
    xlabel(axB, 'y (pixel)');
    ylabel(axB, 'x (pixel)');
    title(axB, '(b) \phi^*', 'FontWeight', 'normal');

    axC = axes(fig, 'Units', 'normalized', 'Position', posBL);
    maskDisplay = uint8(Diag.phiStar >= Diag.phi_th) + 1;   % 1=zero,2=one
    maskDisplay(~isfinite(Diag.phiStar)) = 3;                % 3=invalid
    image(axC, maskDisplay);
    axis(axC, 'image');
    set(axC, 'YDir', 'reverse');
    colormap(axC, [0 0 0; 1 1 1; P.invalidMarkCol]);
    xlabel(axC, 'y (pixel)');
    ylabel(axC, 'x (pixel)');
    title(axC, sprintf('(c) binary mask (%.3f)', Diag.phi_th), 'FontWeight', 'normal');

    axD = axes(fig, 'Units', 'normalized', 'Position', posBR);
    if Diag.E.isValidFrame
        imagesc(axD, Diag.phiStar);
        axis(axD, 'image');
        set(axD, 'YDir', 'reverse');
        colormap(axD, blueWhiteColormap());
        caxis(axD, P.phiDisplayCLim);
        hold(axD, 'on');

        plotPixelPairSegmentsTrueEdge(axD, Diag.E.interfaceRC, 'B', ...
            P.interfaceCol, 0.35, P.cornerRadiusPx);
        plotPixelPairSegmentsTrueEdge(axD, Diag.E.holeBoundaryRC, 'A', ...
            P.holeBoundaryCol, 0.35, P.cornerRadiusPx);
        plotPixelPairSegmentsTrueEdge(axD, Diag.E.unknownBoundaryRC, 'A', ...
            P.unknownBoundaryCol, 0.3, P.cornerRadiusPx);

        hold(axD, 'off');
        cbD = colorbar(axD);
        cbD.Label.String = '\phi^*';
        cbD.TickDirection = 'out';
    else
        axis(axD, [1 P.nCols 1 P.nRows]);
        set(axD, 'YDir', 'reverse', 'Color', 'w');
        text(axD, 0.5*P.nCols, 0.5*P.nRows, ...
            'INVALID FRAME: no background found', ...
            'HorizontalAlignment', 'center', 'Color', P.blackCol, ...
            'FontWeight', 'bold', 'FontSize', 12);
    end
    xlabel(axD, 'y (pixel)');
    ylabel(axD, 'x (pixel)');
    title(axD, '(d) boundaries', 'FontWeight', 'normal');

    allAxes = [axA axB axC axD];
    for ia = 1:numel(allAxes)
        ax = allAxes(ia);
        xlim(ax, [1 P.nCols]);
        ylim(ax, [1 P.nRows]);
        xticks(ax, 0:500:2500);
        yticks(ax, 0:500:1500);
        applyAxesStyle(ax, P.blackCol);
    end

    exportgraphics(fig, outFig, 'Resolution', P.diagnosticResolutionDPI);
end

function plotHighResolutionPanel(Diag, outFig, P)

    applyWorkerGraphicsDefaults();

    fig = figure('Color', 'w', 'Visible', P.figureVisibleMode, ...
        'Units', 'centimeters', 'Position', [1.5 1.5 22 14], ...
        'Name', 'Method 1 v2.0 high-resolution panel', 'NumberTitle', 'off');
    figureCleanup = onCleanup(@() closeFigureIfValid(fig)); %#ok<NASGU>

    ax = axes(fig);
    imagesc(ax, Diag.I_raw);
    axis(ax, 'image');
    set(ax, 'YDir', 'reverse');
    colormap(ax, gray);
    caxis(ax, P.intensityDisplayCLim);
    hold(ax, 'on');

    if Diag.E.isValidFrame
        plotPixelPairSegmentsTrueEdge(ax, Diag.E.interfaceRC, 'B', ...
            P.interfaceCol, 0.5, P.cornerRadiusPx);
        plotPixelPairSegmentsTrueEdge(ax, Diag.E.holeBoundaryRC, 'A', ...
            P.holeBoundaryCol, 0.5, P.cornerRadiusPx);
        plotPixelPairSegmentsTrueEdge(ax, Diag.E.unknownBoundaryRC, 'A', ...
            P.unknownBoundaryCol, 0.4, P.cornerRadiusPx);
    else
        text(ax, 0.5*P.nCols, 0.08*P.nRows, ...
            'INVALID FRAME: no background found', ...
            'HorizontalAlignment', 'center', 'Color', P.blackCol, ...
            'FontWeight', 'bold', 'FontSize', 12);
    end

    hold(ax, 'off');
    cb = colorbar(ax);
    cb.Label.String = 'raw intensity';
    cb.TickDirection = 'out';
    xlabel(ax, 'y (pixel)');
    ylabel(ax, 'x (pixel)');

    xlim(ax, [1 P.nCols]);
    ylim(ax, [1 P.nRows]);
    xticks(ax, 0:500:2500);
    yticks(ax, 0:500:1500);
    applyAxesStyle(ax, P.blackCol);

    exportgraphics(fig, outFig, 'Resolution', P.highResolutionDPI);
end

function plotPixelPairSegmentsTrueEdge(ax, pairsRC, ownerSide, lineColor, ...
    lineWidth, cornerRadiusPx)

    if ~iscell(pairsRC)
        pairsRC = {pairsRC};
    end

    xData = []; yData = [];
    for g = 1:numel(pairsRC)
        groupRC = double(pairsRC{g});
        if isempty(groupRC), continue; end
        [gx, gy] = traceCracksTrueEdges(groupRC, ownerSide, cornerRadiusPx);
        xData = [xData; gx]; %#ok<AGROW>
        yData = [yData; gy]; %#ok<AGROW>
    end

    if ~isempty(xData)
        plot(ax, xData, yData, '-', 'Color', lineColor, 'LineWidth', lineWidth);
    end
end

function [xData, yData] = traceCracksTrueEdges(groupRC, ownerSide, cornerRadiusPx)

    n = size(groupRC,1);
    if n == 0
        xData = []; yData = [];
        return;
    end

    rA = groupRC(:,1); cA = groupRC(:,2);
    rB = groupRC(:,3); cB = groupRC(:,4);

    isColAdjacent = (rA == rB);   % same row -> crack is vertical
    isRowAdjacent = (cA == cB);   % same column -> crack is horizontal

    r1 = nan(n,1); c1 = nan(n,1);
    r2 = nan(n,1); c2 = nan(n,1);

    colMid = (cA + cB) / 2;
    r1(isColAdjacent) = rA(isColAdjacent) - 0.5;
    c1(isColAdjacent) = colMid(isColAdjacent);
    r2(isColAdjacent) = rA(isColAdjacent) + 0.5;
    c2(isColAdjacent) = colMid(isColAdjacent);

    rowMid = (rA + rB) / 2;
    r1(isRowAdjacent) = rowMid(isRowAdjacent);
    c1(isRowAdjacent) = cA(isRowAdjacent) - 0.5;
    r2(isRowAdjacent) = rowMid(isRowAdjacent);
    c2(isRowAdjacent) = cA(isRowAdjacent) + 0.5;

    if strcmp(ownerSide, 'A')
        ownerR = rA; ownerC = cA;
    else
        ownerR = rB; ownerC = cB;
    end

    [linkCrack, linkSlot, linkDegree, coord1, coord2] = ...
        buildCrackLinkTable(r1, c1, r2, c2, ownerR, ownerC);

    [xData, yData] = walkAllChains(linkCrack, linkSlot, linkDegree, ...
        coord1, coord2, cornerRadiusPx);
end

function [linkCrack, linkSlot, linkDegree, coord1, coord2] = ...
    buildCrackLinkTable(r1, c1, r2, c2, ownerR, ownerC)

    n = numel(r1);
    coord1 = [r1 c1];
    coord2 = [r2 c2];

    key1 = round(2*r1) * 1e6 + round(2*c1);
    key2 = round(2*r2) * 1e6 + round(2*c2);
    ownerKey = ownerR * 100000 + ownerC;

    allVertKey  = [key1; key2];
    allCrack    = [(1:n)'; (1:n)'];
    allSlot     = [ones(n,1); 2*ones(n,1)];
    allOwnerKey = [ownerKey; ownerKey];

    [sortedKey, sortOrder] = sort(allVertKey);
    sortedCrack = allCrack(sortOrder);
    sortedSlot  = allSlot(sortOrder);
    sortedOwner = allOwnerKey(sortOrder);

    m = numel(sortedKey);
    groupStart = [true; diff(sortedKey) ~= 0];
    idxInGroupStart = find(groupStart);
    idxInGroupEnd = [idxInGroupStart(2:end)-1; m];
    nGroups = numel(idxInGroupStart);

    linkCrack = zeros(n,2);
    linkSlot = zeros(n,2);
    linkDegree = zeros(n,2);

    for g = 1:nGroups
        lo = idxInGroupStart(g); hi = idxInGroupEnd(g);
        mCrack = sortedCrack(lo:hi);
        mSlot  = sortedSlot(lo:hi);
        mOwner = sortedOwner(lo:hi);
        deg = numel(mCrack);

        if deg == 1
            linkDegree(mCrack(1), mSlot(1)) = 1;
            continue;
        end

        if deg == 2
            linkCrack(mCrack(1), mSlot(1)) = mCrack(2);
            linkSlot(mCrack(1), mSlot(1))  = mSlot(2);
            linkDegree(mCrack(1), mSlot(1)) = 2;
            linkCrack(mCrack(2), mSlot(2)) = mCrack(1);
            linkSlot(mCrack(2), mSlot(2))  = mSlot(1);
            linkDegree(mCrack(2), mSlot(2)) = 2;
            continue;
        end

        used = false(deg,1);
        for a = 1:deg
            if used(a), continue; end
            partner = 0;
            for b = (a+1):deg
                if ~used(b) && mOwner(b) == mOwner(a)
                    partner = b;
                    break;
                end
            end
            if partner > 0
                used(a) = true; used(partner) = true;
                linkCrack(mCrack(a), mSlot(a)) = mCrack(partner);
                linkSlot(mCrack(a), mSlot(a))  = mSlot(partner);
                linkDegree(mCrack(a), mSlot(a)) = deg;
                linkCrack(mCrack(partner), mSlot(partner)) = mCrack(a);
                linkSlot(mCrack(partner), mSlot(partner))  = mSlot(a);
                linkDegree(mCrack(partner), mSlot(partner)) = deg;
            end
        end
        for a = 1:deg
            if ~used(a)
                linkDegree(mCrack(a), mSlot(a)) = deg;
            end
        end
    end
end

function [xData, yData] = walkAllChains(linkCrack, linkSlot, linkDegree, ...
    coord1, coord2, cornerRadiusPx)

    n = size(coord1,1);
    visited = false(n,1);
    xData = []; yData = [];
    t = min(max(cornerRadiusPx, 0), 0.49);

    for pass = 1:2
        for startCrack = 1:n
            if visited(startCrack), continue; end

            if pass == 1
                freeSlot = 0;
                if linkCrack(startCrack,1) == 0
                    freeSlot = 1;
                elseif linkCrack(startCrack,2) == 0
                    freeSlot = 2;
                end
                if freeSlot == 0, continue; end
                entrySlot = freeSlot;
            else
                entrySlot = 1;   % remaining unvisited cracks form a closed loop
            end

            if entrySlot == 1
                chainR = coord1(startCrack,1); chainC = coord1(startCrack,2);
            else
                chainR = coord2(startCrack,1); chainC = coord2(startCrack,2);
            end

            cur = startCrack; curEntrySlot = entrySlot;
            while true
                exitSlot = 3 - curEntrySlot;
                if exitSlot == 1
                    pr = coord1(cur,1); pc = coord1(cur,2);
                else
                    pr = coord2(cur,1); pc = coord2(cur,2);
                end

                nxt = linkCrack(cur, exitSlot);
                nxtSlot = linkSlot(cur, exitSlot);
                deg = linkDegree(cur, exitSlot);
                visited(cur) = true;

                if nxt == 0 || visited(nxt)
                    chainR(end+1,1) = pr; %#ok<AGROW>
                    chainC(end+1,1) = pc; %#ok<AGROW>
                    break;
                end

                appliedCut = false;
                if deg == 2 && t > 0
                    farSlot = 3 - nxtSlot;
                    if farSlot == 1
                        farR = coord1(nxt,1); farC = coord1(nxt,2);
                    else
                        farR = coord2(nxt,1); farC = coord2(nxt,2);
                    end
                    dirIn = [pr pc] - [chainR(end) chainC(end)];
                    dirOut = [farR farC] - [pr pc];
                    nIn = norm(dirIn); nOut = norm(dirOut);
                    if nIn > 0 && nOut > 0
                        uIn = dirIn / nIn;
                        uOut = dirOut / nOut;
                        if norm(uIn - uOut) > 1e-9   % real direction change = a corner
                            cutIn  = [pr pc] - t*uIn;
                            cutOut = [pr pc] + t*uOut;
                            chainR(end+1,1) = cutIn(1); %#ok<AGROW>
                            chainC(end+1,1) = cutIn(2); %#ok<AGROW>
                            chainR(end+1,1) = cutOut(1); %#ok<AGROW>
                            chainC(end+1,1) = cutOut(2); %#ok<AGROW>
                            appliedCut = true;
                        end
                    end
                end

                if ~appliedCut
                    chainR(end+1,1) = pr; %#ok<AGROW>
                    chainC(end+1,1) = pc; %#ok<AGROW>
                end

                cur = nxt; curEntrySlot = nxtSlot;
            end

            xData = [xData; chainC; NaN]; %#ok<AGROW>
            yData = [yData; chainR; NaN]; %#ok<AGROW>
        end
    end
end

function cmap = blueWhiteColormap()

    n = 256;
    t = linspace(0, 1, n)';
    whiteRGB = [1.00 1.00 1.00];
    blueRGB  = [0.02 0.20 0.55];
    cmap = (1 - t) * whiteRGB + t * blueRGB;
end

function applyWorkerGraphicsDefaults()

    set(groot, 'defaultFigureColor', 'w');
    set(groot, 'defaultAxesFontName', 'Times New Roman');
    set(groot, 'defaultTextFontName', 'Times New Roman');
    set(groot, 'defaultAxesFontSize', 11);
    set(groot, 'defaultTextFontSize', 11);
    set(groot, 'defaultAxesLineWidth', 1.0);
    set(groot, 'defaultLineLineWidth', 1.0);
    set(groot, 'defaultAxesTickDir', 'out');
    set(groot, 'defaultAxesBox', 'off');
end

function applyAxesStyle(ax, blackCol)

    ax.FontName = 'Times New Roman';
    ax.FontSize = 11;
    ax.TickDir = 'out';
    ax.TickLength = [0.010 0.010];
    ax.LineWidth = 1.0;
    ax.Layer = 'top';
    ax.XColor = blackCol;
    ax.YColor = blackCol;
    ax.XAxisLocation = 'bottom';
    ax.YAxisLocation = 'left';
    ax.Box = 'off';
    grid(ax, 'off');

    xl = ax.XLim;
    yl = ax.YLim;

    if strcmp(ax.XDir, 'reverse')
        xRight = xl(1);
    else
        xRight = xl(2);
    end
    if strcmp(ax.YDir, 'reverse')
        yTop = yl(1);
    else
        yTop = yl(2);
    end

    wasHeld = ishold(ax);
    hold(ax, 'on');
    plot(ax, xl, [yTop yTop], '-', 'Color', blackCol, 'LineWidth', 1.0, ...
        'HandleVisibility', 'off');
    plot(ax, [xRight xRight], yl, '-', 'Color', blackCol, 'LineWidth', 1.0, ...
        'HandleVisibility', 'off');
    if ~wasHeld
        hold(ax, 'off');
    end
end

function validatePngFile(filePath)

    if ~exist(filePath, 'file')
        error('Expected PNG was not created:\n%s', filePath);
    end
    D = dir(filePath);
    if isempty(D) || D.bytes <= 0
        error('PNG is empty:\n%s', filePath);
    end
    try
        info = imfinfo(filePath);
    catch ME
        error('PNG validation failed for:\n%s\n%s', filePath, ME.message);
    end
    if isempty(info) || info(1).Width <= 0 || info(1).Height <= 0
        error('PNG has invalid dimensions:\n%s', filePath);
    end
end

function publishFileAtomically(sourceFile, destinationFile)

    if ~exist(sourceFile, 'file')
        error('Cannot publish missing source file:\n%s', sourceFile);
    end

    destinationDir = fileparts(destinationFile);
    if ~exist(destinationDir, 'dir')
        mkdir(destinationDir);
    end

    [~,~,ext] = fileparts(destinationFile);
    temporaryDestination = [tempname(destinationDir) ext];

    [okCopy,msgCopy] = copyfile(sourceFile, temporaryDestination, 'f');
    if ~okCopy
        error('Failed to copy file to permanent storage:\n%s', msgCopy);
    end

    [okMove,msgMove] = movefile(temporaryDestination, destinationFile, 'f');
    if ~okMove
        if exist(temporaryDestination, 'file')
            delete(temporaryDestination);
        end
        error('Failed to atomically replace destination:\n%s', msgMove);
    end

    try
        delete(sourceFile);
    catch ME
        error(['Published the permanent file but could not remove the ' ...
               'node-local source:\n%s\n%s'], sourceFile, ME.message);
    end

    if exist(sourceFile, 'file')
        error('Node-local source still exists after publication:\n%s', ...
            sourceFile);
    end
end

function cleanupLocalFileIfPresent(filePath)

    if isempty(filePath) || ~exist(filePath, 'file')
        return;
    end
    try
        delete(filePath);
    catch ME
        warning('Could not remove node-local file %s: %s', filePath, ME.message);
    end
end

function cleanupLocalTaskDirectory(folderPath)

    if isempty(folderPath) || ~exist(folderPath, 'dir')
        return;
    end
    try
        [okRemove,msgRemove] = rmdir(folderPath, 's');
        if ~okRemove
            warning('Could not remove node-local chunk directory %s: %s', ...
                folderPath, msgRemove);
        end
    catch ME
        warning('Could not remove node-local chunk directory %s: %s', ...
            folderPath, ME.message);
    end
end

function closeFigureIfValid(fig)

    if ~isempty(fig) && isgraphics(fig)
        close(fig);
    end
end

function writeChunkDoneText(outFile, ChunkMeta, ResultChunk, chunkMat)

    outDir = fileparts(outFile);
    temporaryFile = [tempname(outDir) '.txt'];

    fid = fopen(temporaryFile, 'w');
    if fid < 0
        error('Cannot write temporary chunk marker:\n%s', temporaryFile);
    end

    statusList = string({ResultChunk.status});

    fprintf(fid, 'Step2_PLIF_interface_2.0 CHUNK COMPLETE\n');
    fprintf(fid, 'RunId: %s\n', ChunkMeta.runId);
    fprintf(fid, 'TaskIndex: %d\n', ChunkMeta.taskIndex);
    fprintf(fid, 'CaseIndex: %d\n', ChunkMeta.caseIndex);
    fprintf(fid, 'Distance: %s\n', ChunkMeta.distance);
    fprintf(fid, 'CaseName: %s\n', ChunkMeta.caseName);
    fprintf(fid, 'ChunkIndex: %d\n', ChunkMeta.chunkIndex);
    fprintf(fid, 'FramesInChunk: %d\n', ChunkMeta.nChunkFrames);
    fprintf(fid, 'StatusOK: %d\n', nnz(statusList == "ok"));
    fprintf(fid, 'StatusInvalidNoBackground: %d\n', ...
        nnz(statusList == "invalid_no_background"));
    fprintf(fid, 'ChunkElapsedMin: %.6f\n', ChunkMeta.chunkElapsedMin);
    fprintf(fid, 'ChunkMAT: %s\n', chunkMat);
    fprintf(fid, 'Finished: %s\n', datestr(ChunkMeta.chunkFinishDatenum, 31));

    fclose(fid);

    [okMove,msgMove] = movefile(temporaryFile, outFile, 'f');
    if ~okMove
        if exist(temporaryFile, 'file'), delete(temporaryFile); end
        error('Failed to publish chunk marker:\n%s', msgMove);
    end
end
