#!/bin/bash
# Usage: bash submit_step2.sh RUN_ID OUTPUT_TAG [CASE_INDEX ...]
# With no case indices, submit all 28 cases. Repeat only after the prior jobs stop.
set -euo pipefail
cd "$(dirname "$0")"
RUN_ID="${1:?Supply a run ID}"
OUTPUT_TAG="${2:?Supply an output tag}"
shift 2
[[ "$RUN_ID" =~ ^[A-Za-z0-9_-]+$ && "$OUTPUT_TAG" =~ ^[A-Za-z0-9_-]+$ ]] || {
    echo 'Run ID and output tag must contain only letters, digits, underscore or hyphen.' >&2; exit 2;
}
if (( $# == 0 )); then set -- {1..28}; fi
seen=' '
for case_index in "$@"; do
    [[ "$case_index" =~ ^([1-9]|1[0-9]|2[0-8])$ ]] || { echo 'Case indices must be 1 to 28.' >&2; exit 2; }
    [[ "$seen" != *" $case_index "* ]] || { echo 'Duplicate case index.' >&2; exit 2; }
    seen+="$case_index "
done
command -v qsub >/dev/null || { echo 'qsub is not on PATH.' >&2; exit 2; }
MASTER=$(cd ../.. && pwd)
MANIFEST="$MASTER/06_MANIFESTS/Step2_PLIF_interface_2.0/$RUN_ID"
mkdir -p "$MANIFEST"
for case_index in "$@"; do
    job=$(qsub -v "CASE_INDEX=$case_index,STEP2_RUN_ID=$RUN_ID,STEP2_OUTPUT_TAG=$OUTPUT_TAG" run_s2case_single.pbs)
    printf '%s\t%s\n' "$case_index" "$job" | tee -a "$MANIFEST/jobs.tsv"
done
