#!/bin/bash
set -euo pipefail
for case_number in {1..27}; do
  /opt/pbs/bin/qsub -v STEP3_CASE="$case_number" run_formal_case_v4.pbs
done
