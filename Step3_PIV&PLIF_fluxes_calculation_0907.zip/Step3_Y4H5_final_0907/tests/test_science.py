import unittest
import numpy as np
from step3_y4h5.numerics import gradients,filter_velocity,kernels,eta_from_terms,xi_bins,contributions
from step3_y4h5.mapping import Map,project
from step3_y4h5.config import P

class ScienceTests(unittest.TestCase):
    def test_decreasing_y_gradient(self):
        x=np.array([0.,.1,.3,.6]);y=np.array([.4,.1,-.2]);X,Y=np.meshgrid(x,y)
        g=gradients(2*X+3*Y,4*X-5*Y,x,y)
        for a,b in zip(g,[2,3,4,-5]):np.testing.assert_allclose(a,b)
    def test_nan_median_preserves_centre(self):
        a=np.arange(9.).reshape(3,3);a[1,1]=np.nan
        b=filter_velocity(a);self.assertTrue(np.isnan(b[1,1]));self.assertTrue(np.isfinite(b[0,1]))
    def test_zero_weight_nan(self):
        m=Map(np.array([True]),np.array([1]),np.array([[0,1,2,3]]),np.array([[1.,0,0,0]]),None,None)
        np.testing.assert_equal(m.sample(np.array([[2.,np.nan],[np.nan,np.nan]])),[2.])
    def test_pooled_eta_not_frame_mean(self):
        eps,eta,g=eta_from_terms(np.array([2.,6.,8.,10.])+np.array([0.,0.,0.,80.]),12)
        self.assertAlmostEqual(eps,P.nu*(-2+12+16+720)/12)
    def test_kernel_before_average(self):
        k=kernels(np.array([1.,3.]),np.array([0.,0.]));self.assertEqual(k[1].mean(),5.)
        self.assertNotEqual(k[1].mean(),k[0].mean()**2)
    def test_signed_bins_and_missing_velocity_probability(self):
        b=xi_bins(np.array([0,.5,.5,1.,1.1]),np.array([1,1,0,1,0],bool))
        np.testing.assert_equal(b,[0,1,-1,1,-2])
        _,s=contributions(np.zeros(2,dtype=int),np.array([1.,np.nan]),np.ones(2),np.array([1,0],bool),np.ones(2,bool))
        self.assertEqual(s[3,0],1);self.assertEqual(s[4,0],2);self.assertEqual(s[5,0],1)
    def test_pixel_and_bin_area_integrals_equal(self):
        ids=np.array([0,1,1,2,1,0]);J=np.array([2.,5.,8.])
        counts=np.bincount(ids)
        self.assertAlmostEqual(2*P.delta**2/P.length*J[ids].sum(),2*P.delta**2/P.length*np.dot(counts,J))
    def test_projective_roundtrip(self):
        T=np.array([[.5,.01,10],[.02,.6,20],[1e-5,2e-5,1.]])
        x=np.array([1.,30.,100.]);y=np.array([10.,20.,40.])
        a,b=project(T,x,y);c,d=project(np.linalg.inv(T),a,b)
        np.testing.assert_allclose(c,x);np.testing.assert_allclose(d,y)
if __name__=='__main__':unittest.main()
