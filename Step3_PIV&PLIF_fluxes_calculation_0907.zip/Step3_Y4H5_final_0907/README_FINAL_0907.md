# Step3 Y4H5 final code package

The detailed handover is in
`Step3_Y4H5_FINAL_CODE_GUIDE_20260907.md`. It is the authoritative description
of the 27-case calculation, file layout, equations, validation and download
procedure.

This is the final Step3 version used for the rerun on Imperial CX3.

- Formal run ID: `run_20260907_formal_v2`
- Number of cases: 27
- `u_bar` plots use direct mean streamwise velocity in m/s; they are not divided by `U_infty`.
- The final combine step writes five table reports (A1 Actual, A2 y approximation, A3 xi approximation, A4 percentage differences from Actual, A5 engulfment-contribution comparison), each with 27 case rows in CSV, TXT and Overleaf-ready TEX formats.
- Aggregate outputs are written under `5D/ALL_CASES/`, `10D/ALL_CASES/`, `30D/ALL_CASES/`, `40D/ALL_CASES/`, `BY_CASE/`, `ALL27_HOLE_SIZE_PDF/` and `TABLES_0906/`.
- Step1/Step2 input files are read-only. Step3 writes only to its own output run directory.
