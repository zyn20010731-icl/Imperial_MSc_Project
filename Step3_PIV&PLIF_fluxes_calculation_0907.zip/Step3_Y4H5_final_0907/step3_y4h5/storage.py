"""All writes are confined to a new run root; inputs are never writable handles."""
from pathlib import Path
import os, json, csv, hashlib, time
import numpy as np
import h5py

class Output:
    def __init__(self, root, master):
        self.root=Path(root).resolve(); self.master=Path(master).resolve()
        allowed=self.master/'06_OUTPUTS_Y4H5'
        if not self.root.is_relative_to(allowed) or self.root==allowed:
            raise ValueError(f'Output must be a dedicated child of {allowed}')
        self.root.mkdir(parents=True,exist_ok=True)
    def path(self, relative):
        p=(self.root/relative).resolve()
        if not p.is_relative_to(self.root): raise ValueError('Output escaped dedicated run')
        p.parent.mkdir(parents=True,exist_ok=True)
        return p
    def json(self, name, data):
        p=self.path(name);tmp=p.with_suffix(p.suffix+'.tmp')
        tmp.write_text(json.dumps(data,indent=2,default=lambda x:x.tolist() if isinstance(x,np.ndarray) else x.item() if isinstance(x,np.generic) else str(x))+'\n')
        os.replace(tmp,p)
    def csv(self,name,rows,fields=None):
        p=self.path(name);tmp=p.with_suffix(p.suffix+'.tmp');rows=list(rows)
        if fields is None: fields=list(rows[0]) if rows else []
        with tmp.open('w',newline='') as f:
            w=csv.DictWriter(f,fieldnames=fields);w.writeheader()
            for row in rows:
                w.writerow({k:format(v,'.12g') if isinstance(v,(float,np.floating)) else v for k,v in row.items()})
        os.replace(tmp,p)
    def h5(self,name,data,attrs=None):
        p=self.path(name);tmp=p.with_suffix(p.suffix+'.tmp')
        def put(g,d):
            for k,v in d.items():
                if isinstance(v,dict): put(g.create_group(k),v)
                elif isinstance(v,str): g.create_dataset(k,data=v,dtype=h5py.string_dtype('utf-8'))
                elif v is not None:
                    a=np.asarray(v)
                    if a.dtype.kind in 'UO': a=np.asarray(v,dtype=h5py.string_dtype('utf-8'))
                    g.create_dataset(k,data=a,**({'compression':'lzf'} if a.ndim and a.size>256 else {}))
        with h5py.File(tmp,'w') as f:
            f.attrs.update(schemaVersion='1.0',outputTag='0906',**(attrs or {}));put(f,data)
        os.replace(tmp,p)
    def log(self,msg):
        line=time.strftime('%Y-%m-%dT%H:%M:%S')+' '+msg
        print(line,flush=True)
        with self.path('runtime/progress_0906.log').open('a') as f:f.write(line+'\n')

def sha(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
    return h.hexdigest()
