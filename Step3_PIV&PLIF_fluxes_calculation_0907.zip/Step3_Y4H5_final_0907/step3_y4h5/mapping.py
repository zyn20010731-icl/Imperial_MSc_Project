"""Column-vector projective mapping on native NetCDF (y,x) arrays."""
import numpy as np
import h5py
from dataclasses import dataclass

@dataclass
class Map:
    valid: np.ndarray
    source: np.ndarray
    corners: np.ndarray
    weights: np.ndarray
    x: np.ndarray
    y: np.ndarray
    def sample(self,field):
        a=np.asarray(field).reshape(-1)[self.corners]
        active=self.weights!=0
        ok=self.valid & np.all(~active|np.isfinite(a),axis=1)
        out=np.sum(np.where(active,a,0)*self.weights,axis=1)
        out[~ok]=np.nan
        return out
    def subset(self,select):return Map(*(getattr(self,k)[select] for k in ('valid','source','corners','weights','x','y')))

def project(T,col,row):
    z=T[2,0]*col+T[2,1]*row+T[2,2]
    return ((T[0,0]*col+T[0,1]*row+T[0,2])/z,(T[1,0]*col+T[1,1]*row+T[1,2])/z)

class Calibration:
    def __init__(self,master,x,y,shape):
        self.x=np.asarray(x);self.y=np.asarray(y);self.shape=shape
        self.ny,self.nx=x.shape;self.crop=132-self.nx;self.retained=self.ny-212
        if not (0<=self.crop<132 and 0<self.retained<=212):raise ValueError('Invalid stitching dimensions')
        self.T=[]
        for name in ('normal','tilted'):
            with h5py.File(str(master)+f'/02_INPUTS/SPATIAL_CALIBRATION/tform_{name}_to_PLIF_matrix.mat','r') as f:
                T=np.asarray(f['T'][()],dtype=float) # HDF5 view is already column-vector form.
            if T.shape!=(3,3) or not np.isfinite(T).all() or abs(np.linalg.det(T))<1e-12:raise ValueError('Bad homography')
            self.T.append(T)
        self.inv=[np.linalg.inv(t) for t in self.T]
    def camera_local(self,rc,cam):
        c,r=project(self.inv[cam-1],rc[:,1],rc[:,0])
        return 133-r/12,c/12
    def source(self,rc):
        # Integer pixel centres inside forward image of each full camera rectangle.
        q=np.floor(rc+.5);src=np.zeros(len(rc),np.uint8)
        inimage=(q[:,0]>=1)&(q[:,0]<=self.shape[0])&(q[:,1]>=1)&(q[:,1]<=self.shape[1])
        for cam in (2,1):
            lx,ly=self.camera_local(q,cam)
            inside=inimage&(lx>=1)&(lx<=132)&(ly>=1)&(ly<=212)
            src[inside]=cam
        return src
    def map(self,rc):
        rc=np.asarray(rc,dtype=float);src=self.source(rc);n=len(rc)
        ix=np.zeros(n);iy=np.zeros(n);valid=np.zeros(n,bool)
        for cam in (1,2):
            sel=src==cam
            lx,ly=self.camera_local(rc[sel],cam)
            if cam==1:
                ok=(lx>=1)&(lx<=self.nx)&(ly>=1)&(ly<=212)
                sx=lx-1;sy=ly-1+self.retained
            else:
                ok=(lx>=1+self.crop)&(lx<=132)&(ly>=1)&(ly<=self.retained)
                sx=lx-1-self.crop;sy=ly-1
            ix[sel]=sx;iy[sel]=sy;valid[sel]=ok
        valid &= np.isfinite(ix)&np.isfinite(iy)&(ix>=0)&(ix<=self.nx-1)&(iy>=0)&(iy<=self.ny-1)
        bx=np.clip(np.floor(ix),0,self.nx-2).astype(np.int64)
        by=np.clip(np.floor(iy),0,self.ny-2).astype(np.int64)
        ax=ix-bx;ay=iy-by
        corners=np.stack((by*self.nx+bx,by*self.nx+bx+1,(by+1)*self.nx+bx,(by+1)*self.nx+bx+1),axis=1)
        weights=np.stack(((1-ax)*(1-ay),ax*(1-ay),(1-ax)*ay,ax*ay),axis=1)
        weights[~valid]=0
        m=Map(valid,src,corners,weights,np.zeros(n),np.zeros(n))
        m.x=m.sample(self.x);m.y=m.sample(self.y)
        return m
    def fixed(self):
        nr,nc=self.shape
        ids=np.arange(nr*nc,dtype=np.int64)
        rc=np.column_stack((ids%nr+1,ids//nr+1))
        m=self.map(rc);sel=m.valid&(m.y>0)
        return ids[sel],rc[sel],m.subset(sel)
