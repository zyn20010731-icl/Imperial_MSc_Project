from dataclasses import asdict
import numpy as np
from .config import P
from .plotting import profiles_plot,pdf_data,pdf_plot

NAMES=('MassFlux','StreamwiseMomentumFlux','KineticEnergyFlux')
UNITS=('kg_m_s','N_m','W_m')

def frame_row(frame,q):
    row=dict(plifFrameNo=frame,pivFrameID=(frame-98)//2,status='success',failureReason='')
    for j,(name,unit,ref) in enumerate(zip(NAMES,UNITS,P.refs)):
        for z,prefix in enumerate(('engulfedHoles','wake')):
            row[prefix+name+'_'+unit]=q[j,z];row[prefix+name+'_nondimensional']=q[j,z]/ref
            rawunit=('kg_s','N','W')[j]
            row[prefix+'Raw'+name+'_'+rawunit]=q[j,z]*P.length/2
        row['engulfedToWake'+name+'Fraction']=q[j,0]/q[j,1] if q[j,1]!=0 else np.nan
    return row

def profile_rows(p,coordinate,eta):
    rows=[]
    for j,x in enumerate(p['coordinate_m']):
        raw=p['raw'][:,j];v=p['finished'][:,j];s=p['sums'][:,j]
        r={coordinate+'_m':x,coordinate+('_over_d' if coordinate=='y' else '_over_eta'):x/(P.d if coordinate=='y' else eta),
          'meanU_raw_m_s':raw[0],'meanU_m_s':v[0],'meanU2_raw_m2_s2':raw[1],'meanU2_m2_s2':v[1],
          'meanKineticKernel_raw_m3_s3':raw[2],'meanKineticKernel_m3_s3':v[2],'PEraw':raw[3],'PE':v[3],
          ('PwakeRaw' if coordinate=='y' else 'PwakeEmpiricalRaw'):raw[4],('Pwake' if coordinate=='y' else 'PwakeTheoreticalStep'):v[4],
          'nVelocitySamples':int(s[3]),'nProbabilityPixels':int(s[4]),'nEngulfedPixels':int(s[5]),'nWakePixels':int(s[6]),
          'sumU':s[0],'sumU2':s[1],'sumKineticKernel':s[2]}
        for a,name in enumerate(('mass','momentum','kinetic')):
            for z,region in enumerate(('Engulfed','Wake')):
                r[name+region+'_'+('kg_m2_s','N_m2','W_m2')[a]]=p['density'][a,z,j]
                r[name+region+'_nondimensional']=p['density'][a,z,j]/(P.refs[a]/P.d)
        rows.append(r)
    return rows

def report(out,case,final,profiles,results):
    holes=[h for r in results for h in r['holes']];title=case['distance']+' / '+case['name'].replace('_',' ')
    identity=dict(distance=case['distance'],caseName=case['name'],sourceCaseName=case['source'])
    # All tables carry explicit frame/hole identities, never implicit ordering keys.
    for h in holes:h.update(identity)
    out.csv('results/02_holes/Y_holes_detailed_case_0906.csv',holes)
    annotations={k:[h[k] for h in holes] for k in ('plifFrameNo','holeIndex','classification','distanceToInterface_m','passesPivResolutionCutoff')}
    out.h5('results/02_holes/Y_holes_annotation_case_0906.h5',annotations)
    countrows=[];countarray=np.stack([r['counts'] for r in results]);totalarea=sum(r['observed_area'] for r in results)
    stats={}
    for k,label in enumerate(('All','Resolved')):
        stats[label]={}
        for z,population in enumerate(('engulfed','internal','total')):
            a=countarray[:,k,z] if z<2 else countarray[:,k].sum(1)
            stats[label][population]=dict(totalCount=int(a.sum()),meanPerFrame=a.mean(),stdPerFrame=a.std(ddof=1) if len(a)>1 else np.nan,
                medianPerFrame=np.median(a),minimumPerFrame=int(a.min()),maximumPerFrame=int(a.max()),arealNumberDensity_m2=a.sum()/totalarea,nondimensionalArealNumberDensity=a.sum()/totalarea*P.d**2)
    stats.update(nSuccessfulFrames=len(results),totalObservedArea_m2=totalarea)
    for r in results:
        row=dict(plifFrameNo=r['frame'],pivFrameID=(r['frame']-98)//2,measurementArea_m2=r['observed_area'])
        for k,label in enumerate(('All','Resolved')):
            row.update({label+'Engulfed':int(r['counts'][k,0]),label+'Internal':int(r['counts'][k,1]),label+'Total':int(r['counts'][k].sum())})
        countrows.append(row)
    out.csv('results/02_holes/Y_hole_counts_by_frame_case_0906.csv',countrows)
    pdf=pdf_data(holes);out.csv('results/02_holes/Y_hole_characteristic_size_PDF_data_case_0906.csv',pdf,
        fields=['binLower_sqrtAh_over_eta','binUpper_sqrtAh_over_eta','binCentre_sqrtAh_over_eta','engulfedCount','engulfedPdf','internalCount','internalPdf'])
    out.h5('results/02_holes/Y_holes_case_0906.h5',dict(CountStatistics=stats,HoleClassification=annotations,SizeAnalysis={k:[r[k] for r in pdf] for k in pdf[0]} if pdf else {},Parameters=asdict(P)))
    pdf_plot(out,pdf,title,case_name=case['name'])
    actualrows=[]
    for r in results:
        row=frame_row(r['frame'],r['actual']);row.update(identity,nVelocityPixels=r['nv'],nProbabilityPixels=r['np'],streamwiseLength_m=P.length)
        actualrows.append(row)
    out.csv('results/03_actual_flux/Y_actual_flux_frames_case_0906.csv',actualrows)
    out.csv('results/03_actual_flux/Y_actual_flux_resolved_engulfed_holes_case_0906.csv',[h for h in holes if h['isEngulfed'] and h['passesPivResolutionCutoff']],fields=list(holes[0]) if holes else [])
    out.h5('results/03_actual_flux/Y_actual_flux_case_0906.h5',dict(Final=final,FrameResults={k:[r[k] for r in actualrows] for k in actualrows[0]},Parameters=asdict(P)))
    for coordinate in ('y','xi'):
        folder='04_y_approximation' if coordinate=='y' else '05_xi_approximation'
        filename='Y_y_approximation_case_0906.h5' if coordinate=='y' else 'Y_mass_flux_approximations_case_0906.h5'
        out.h5('results/'+folder+'/'+filename,dict(Final=final,Profiles=profiles[coordinate],Parameters=asdict(P)))
        out.csv(f'results/{folder}/Y_profiles_{coordinate}_case_0906.csv',profile_rows(profiles[coordinate],coordinate,final['eta_I']))
        profiles_plot(out,profiles[coordinate],coordinate,final['eta_I'],title)
    for stage,name in [('01_eta','Y_eta_summary'),('02_holes','Y_holes_case_summary'),('03_actual_flux','Y_actual_flux_case_summary'),('04_y_approximation','Y_y_approximation_case_summary'),('05_xi_approximation','Y_mass_flux_approximations_case_summary'),('06_final','Y_FINAL_case_summary')]:
        lines=[title,'Units: mass kg/(m s); momentum N/m; kinetic energy W/m',f'L = {P.length:.12g} m',f'epsilon_I = {final["epsilon_I"]:.12g} m^2/s^3',f'eta_I = {final["eta_I"]:.12g} m',f'common frames = {len(results)}']
        for method in ('actual','yBased','xiBased'):lines.append(method+' [rows mass/momentum/energy; columns engulfed/wake]:\n'+np.array2string(final[method],precision=12))
        out.path(f'results/{stage}/{name}_0906.txt').write_text('\n'.join(lines)+'\n')
    return stats
