"""Read completed case results; never reopen raw experiment data for aggregates."""
from pathlib import Path
import argparse,csv,json
import numpy as np
import h5py
from .config import cases,P
from .storage import Output,sha
from .plotting import style,plt,save,COLORS,mirror_y,hole_pdf_figure
from .table_reports import write_table_reports

DISTANCES=('5D','10D','30D','40D')

def read_case(root,c):
    folder=Path(root)/c['distance']/c['name']
    done=folder/'Step3_Y4H5_DONE_0906.txt'
    if not done.is_file():raise ValueError(f'Case not complete: {folder}')
    manifest=folder/'Step3_Y4H5_outputs_0906.tsv';identity=json.loads(done.read_text())
    if identity['manifestSha256']!=sha(manifest):raise ValueError('Case manifest changed')
    with manifest.open() as f:
        for row in csv.DictReader(f,delimiter='\t'):
            file=folder/row['relativePath']
            if file.stat().st_size!=int(row['sizeBytes']) or sha(file)!=row['sha256']:raise ValueError(f'Changed formal output: {file}')
    def load(g):return {k:load(v) if isinstance(v,h5py.Group) else v[()] for k,v in g.items()}
    with h5py.File(folder/'results/06_final/Y_FINAL_case_0906.h5','r') as f:data=load(f)
    return dict(case=c,folder=folder,data=data)

def group_plots(out,items,prefix,groupby):
    style()
    for coord,gname in [('y','ProfilesY'),('xi','ProfilesXi')]:
        for quantity in ['ubar','PE','Pwake','mass_flux_density','momentum_flux_density','kinetic_energy_flux_density']:
            paired='density' in quantity
            fig,axes=plt.subplots(1,2 if paired else 1,figsize=(6.9,2.7) if paired else (3.45,2.7),layout='constrained')
            axes=np.atleast_1d(axes)
            for i,item in enumerate(items):
                p=item['data'][gname];case=item['case'];eta=float(item['data']['Final']['eta_I'])
                x=p['coordinate_m']/(P.d if coord=='y' else eta)
                label=case['name'].replace('_',' ') if groupby=='case' else case['distance']
                color=COLORS[i%len(COLORS)]
                for z,ax in enumerate(axes):
                    if paired:
                        j=['mass_flux_density','momentum_flux_density','kinetic_energy_flux_density'].index(quantity)
                        y=p['density'][j,z]/(P.refs[j]/P.d);ylabel=[r'$J_m/(\rho U_\infty)$',r'$J_p/(\rho U_\infty^2)$',r'$J_k/(0.5\rho U_\infty^3)$'][j]
                        ax.set_title(['(a) Engulfed','(b) Wake'][z],loc='left')
                    else:
                        j=['ubar','PE','Pwake'].index(quantity);y=p['finished'][[0,3,4][j]]
                        ylabel=[r'$\overline{U}\;(\mathrm{m\,s^{-1}})$',r'$P_E$',r'$P_W$'][j]
                    xp,yp=mirror_y(x,y) if coord=='y' else (x,y)
                    ax.plot(xp,yp,label=label,color=color,ls=['-','--','-.',':'][i%4])
                    ax.set(xlabel=r'$y/d$' if coord=='y' else r'$\xi/\eta_I$',ylabel=ylabel)
                    if coord=='xi':ax.set_xlim(-50,50)
            axes[-1].legend(frameon=False,fontsize=7)
            save(fig,out.path(f'{prefix}_{quantity}_{coord}_JFM_0906'))
    for coord,folder in [('y','04_y_approximation'),('xi','05_xi_approximation')]:
        rows=[]
        for item in items:
            with (item['folder']/f'results/{folder}/Y_profiles_{coord}_case_0906.csv').open() as f:
                for row in csv.DictReader(f):rows.append(dict(distance=item['case']['distance'],caseName=item['case']['name'],sourceCaseName=item['case']['source'],**row))
        out.csv(prefix+f'_profiles_{coord}_0906.csv',rows)

def combine(master,runid):
    root=Path(master)/'06_OUTPUTS_Y4H5'/runid;out=Output(root,master)
    items=[read_case(root,c) for c in cases(master)]
    for distance in DISTANCES:
        subset=[i for i in items if i['case']['distance']==distance]
        target=Output(root/distance/'ALL_CASES',master);group_plots(target,subset,'Y_COMBINED','case')
    for name in dict.fromkeys(i['case']['name'] for i in items):
        subset=[i for i in items if i['case']['name']==name]
        target=Output(root/'BY_CASE'/name,master);group_plots(target,subset,'Y_BY_CASE','distance')
    rows=[];pdfrows=[];series=[];style();fig,ax=plt.subplots(figsize=(3.45,3.0),layout='constrained')
    for item in items:
        c=item['case'];final=item['data']['Final'];row=dict(distance=c['distance'],caseName=c['name'],eta_I=float(final['eta_I']),epsilon_I=float(final['epsilon_I']),nFrames=int(final['nFrames']))
        for method in ('actual','yBased','xiBased'):
            for j,quantity in enumerate(('mass','momentum','kinetic')):
                for z,region in enumerate(('engulfed','wake')):row[f'{method}_{quantity}_{region}']=float(final[method][j,z])
                row[f'{method}_{quantity}_fraction']=float(final[method+'Fraction'][j])
        rows.append(row)
        with (item['folder']/'results/02_holes/Y_hole_characteristic_size_PDF_data_case_0906.csv').open() as f:
            pdf_table=list(csv.DictReader(f))
            for r in pdf_table:
                for pop in ('engulfed','internal'):
                    x=float(r['binCentre_sqrtAh_over_eta']);y=float(r[pop+'Pdf'])
                    pdfrows.append(dict(caseName=c['name'],distance=c['distance'],population=pop,binCentre_sqrtAh_over_eta=x,pdf=y))
                    if np.isfinite(y) and y>0:ax.loglog(x,y,'o',ms=2.5,alpha=.6,mfc='none' if pop=='engulfed' else '#b96e64',mec='#397da8' if pop=='engulfed' else '#b96e64',mew=.5)
            for pop in ('engulfed','internal'):
                series.append(dict(caseName=c['name'], population=pop,
                                   x=np.array([float(r['binCentre_sqrtAh_over_eta']) for r in pdf_table]),
                                   pdf=np.array([float(r[pop+'Pdf']) for r in pdf_table])))
    ax.set(xlabel=r'$\sqrt{A_h}/\eta_I$',ylabel='Probability density')
    save(fig,out.path('ALL27_HOLE_SIZE_PDF/Y_hole_size_PDF_all_cases_combined_0906'))
    fig2,_=hole_pdf_figure(series, 'All 27 cases', combined=True)
    save(fig2,out.path('ALL27_HOLE_SIZE_PDF/Y_hole_size_PDF_all_cases_combined_0906'))
    out.csv('ALL27_HOLE_SIZE_PDF/Y_hole_size_PDF_all_cases_combined_data_0906.csv',pdfrows)
    out.csv('Y_all_cases_summary_0906.csv',rows)
    write_table_reports(root, items)
    out.json('run_summary_0906.json',dict(state='ALL27_AGGREGATES_WRITTEN',cases=27))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--master',type=Path,default=Path.home()/'MSc_Project/MSc_2026_final');p.add_argument('--run-id',required=True);a=p.parse_args();combine(a.master,a.run_id)
