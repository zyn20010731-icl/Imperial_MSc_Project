"""Independent numerical identities and output completeness checks before DONE."""
import argparse,json,csv
from pathlib import Path
import numpy as np
import h5py
from PIL import Image
from .config import P
from .storage import sha

REQUIRED=['results/01_eta/Y_eta_case_0906.h5','results/01_eta/Y_eta_frame_terms_0906.csv',
'results/02_holes/Y_holes_case_0906.h5','results/02_holes/Y_holes_detailed_case_0906.csv',
'results/02_holes/Y_holes_annotation_case_0906.h5','results/02_holes/Y_hole_counts_by_frame_case_0906.csv',
'results/02_holes/Y_hole_characteristic_size_PDF_data_case_0906.csv',
'results/03_actual_flux/Y_actual_flux_case_0906.h5','results/03_actual_flux/Y_actual_flux_frames_case_0906.csv',
'results/03_actual_flux/Y_actual_flux_resolved_engulfed_holes_case_0906.csv',
'results/04_y_approximation/Y_y_approximation_case_0906.h5','results/04_y_approximation/Y_profiles_y_case_0906.csv',
'results/05_xi_approximation/Y_mass_flux_approximations_case_0906.h5','results/05_xi_approximation/Y_profiles_xi_case_0906.csv',
'results/05_xi_approximation/Y_xi_fluxes_by_frame_case_0906.csv','results/06_final/Y_FINAL_case_0906.h5',
'results/06_final/Y_stage4_diagnostics_case_0906.h5',
'results/01_eta/Y_eta_summary_0906.txt',
'results/02_holes/Y_holes_case_summary_0906.txt',
'results/03_actual_flux/Y_actual_flux_case_summary_0906.txt',
'results/04_y_approximation/Y_y_approximation_case_summary_0906.txt',
'results/05_xi_approximation/Y_mass_flux_approximations_case_summary_0906.txt',
'results/06_final/Y_FINAL_case_summary_0906.txt',
'results/06_final/Y_FINAL_case_summary_0906.json']

def validate(root,mark_done=False):
    root=Path(root).resolve()
    identity=json.loads((root/'runtime/identity.json').read_text())
    for rel in REQUIRED:
        p=root/rel
        if not p.is_file() or not p.stat().st_size:raise ValueError(f'Missing/empty {rel}')
    # Text/JSON summaries are deliverables, not optional logs. Check their
    # structure before the numerical identities below.
    summary_texts=[root/rel for rel in REQUIRED if rel.endswith('.txt')]
    for path in summary_texts:
        text=path.read_text(encoding='utf-8')
        for marker in ('common frames =','epsilon_I =','eta_I =','actual [rows'):
            if marker not in text:
                raise ValueError(f'Summary text missing {marker}: {path}')
    try:
        final_json=json.loads((root/'results/06_final/Y_FINAL_case_summary_0906.json').read_text())
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError('Final JSON summary is not readable') from exc
    for key in ('epsilon_I','eta_I','nFrames','actual','yBased','xiBased'):
        if key not in final_json: raise ValueError(f'Final JSON missing {key}')
    # CSVs must have a header and at least one data row. This catches partial
    # renames/truncation even when the H5 numerical file is intact.
    for path in sorted(root.rglob('*.csv')):
        with path.open(newline='', encoding='utf-8') as stream:
            reader=csv.reader(stream); header=next(reader, None); first=next(reader, None)
        if not header or first is None:
            raise ValueError(f'CSV missing header/data row: {path}')
    with h5py.File(root/'results/06_final/Y_FINAL_case_0906.h5','r') as f:
        frames=f['frames'][()];n=len(frames)
        if n==0 or len(np.unique(frames))!=n:raise ValueError('Bad frame set')
        np.testing.assert_allclose(f['Final/actual'][()],f['ActualFrames'][()].mean(0),rtol=1e-12)
        np.testing.assert_allclose(f['Final/xiBased'][()],f['XiFrames'][()].mean(0),rtol=1e-12)
        for method in ('actual','yBased','xiBased'):
            a=f['Final/'+method][()]
            if not np.isfinite(a).all():raise ValueError('Nonfinite integrated flux')
            np.testing.assert_allclose(f['Final/'+method+'Nondimensional'][()],a/np.array(P.refs)[:,None],rtol=1e-12)
        for coord,group in [('y','ProfilesY'),('xi','ProfilesXi')]:
            g=f[group];sums=g['sums'][()];p=g['finished'][()]
            if not np.all(sums[5]<=sums[6]) or not np.all(sums[6]<=sums[4]):raise ValueError('Probability count subset failure')
            if np.any(p[3]>p[4]+1e-12):raise ValueError('PE exceeds PW')
            np.testing.assert_allclose(g['density'][()],P.rho*p[:3,None,:]*p[None,3:5,:],rtol=1e-12)
            if coord=='y':np.testing.assert_allclose(f['Final/yBased'][()],2*P.delta*g['density'][()].sum(2),rtol=1e-12)
            else:
                with h5py.File(root/'_work/xi_contributions.h5','r') as c:
                    q=2*P.delta**2/P.length*np.einsum('fj,msj->fms',c['pixelCounts'][()],g['density'][()])
                    np.testing.assert_allclose(q,f['XiFrames'][()],rtol=1e-12,atol=1e-15)
        eps=float(f['Final/epsilon_I'][()]);eta=float(f['Final/eta_I'][()])
        if eps<=0 or eta<=0:raise ValueError('Nonpositive dissipation/eta')
        np.testing.assert_allclose(eta,(P.nu**3/eps)**.25)
    for coord,folder in [('y','04_y_approximation'),('xi','05_xi_approximation')]:
        for name in ['ubar','PE','Pwake','mass_flux_density','momentum_flux_density','kinetic_energy_flux_density']:
            for ext in ['png','pdf']:
                path=root/f'results/{folder}/Y_{name}_{coord}_JFM_case_0906.{ext}'
                if not path.is_file():raise ValueError(f'Missing figure {path}')
                if ext=='png':
                    with Image.open(path) as im:im.verify()
                elif path.stat().st_size < 1000:
                    raise ValueError(f'PDF appears truncated: {path}')
    hole_pdf=root/'results/02_holes/Y_hole_characteristic_size_PDF_case_0906.pdf'
    if not hole_pdf.is_file() or hole_pdf.stat().st_size < 1000:
        raise ValueError('Missing/truncated hole PDF figure')
    expected=[int(f) for f in frames if (int(f)-100)%200==0]
    for frame in expected:
        path=root/f'results/06_final/diagnostic_4panel/Y_4panel_PLIF_{frame:04d}_PIV_{(frame-98)//2:04d}_0906.png'
        with Image.open(path) as im:im.verify()
    for item in identity['inputs']:
        p=Path(item['path']);st=p.stat()
        if st.st_size!=item['size'] or st.st_mtime_ns!=item['mtime_ns']:raise ValueError('Input changed since preflight')
    report=dict(state='VALIDATED_PILOT' if identity['extra']['limit'] is not None else 'VALIDATED',nFrames=n,diagnosticFrames=expected,identity=identity['fingerprint'])
    (root/'runtime/validation_0906.json').write_text(json.dumps(report,indent=2)+'\n')
    if mark_done:
        if identity['extra']['limit'] is not None:raise ValueError('A limited pilot must never receive formal DONE')
        manifest=root/'Step3_Y4H5_outputs_0906.tsv'
        files=sorted(p for folder in ('results','_shared') for p in (root/folder).rglob('*') if p.is_file() and 'FILTERED_VELOCITY_CACHE' not in p.name and p.suffix!='.npz')
        with manifest.open('w',newline='') as f:
            w=csv.writer(f,delimiter='\t');w.writerow(['relativePath','sizeBytes','sha256','role'])
            for p in files:w.writerow([str(p.relative_to(root)),p.stat().st_size,sha(p),'formal'])
        (root/'Step3_Y4H5_DONE_0906.txt').write_text(json.dumps(dict(report,manifestSha256=sha(manifest)),indent=2)+'\n')
    return report

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('root');p.add_argument('--mark-done',action='store_true');a=p.parse_args()
    print(json.dumps(validate(a.root,a.mark_done),indent=2))
