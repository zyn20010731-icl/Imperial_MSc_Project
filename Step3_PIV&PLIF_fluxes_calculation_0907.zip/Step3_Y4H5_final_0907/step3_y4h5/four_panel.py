"""Native-resolution PLIF backgrounds and co-registered PIV overlays.

PLIF intensity is never resampled. Calibration moves PIV mesh coordinates and
vectors into the photograph's coordinate system, without changing their values.
"""
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from matplotlib.collections import LineCollection
from matplotlib.colors import LinearSegmentedColormap, Normalize
from matplotlib.lines import Line2D
from matplotlib.ticker import ScalarFormatter

from .config import P
from .mapping import project
from .numerics import gradients
from .plotting import plt, style, frame_axes

BOUNDARY_COLORS = dict(interface='#d8a500', engulfed='#249444',
                       internal='#111111', unknown='#888888')
BLUE_WHITE = LinearSegmentedColormap.from_list(
    'step3_white_blue', ['#ffffff', '#e9f4fa', '#c5e1ef', '#88bbd5', '#397da8'])
PASTEL_BLUE_RED = LinearSegmentedColormap.from_list(
    'step3_pastel_blue_red', ['#91b9d2', '#d0e2ed', '#fcfcfb', '#f0d6d1', '#d99d95'])


def boundary_segments(pairs):
    """Independent true shared edges, expressed as (column,row), one-based."""
    pairs = np.asarray(pairs, dtype=float).reshape(-1, 4)
    a, b = pairs[:, :2], pairs[:, 2:]
    normal = b - a
    if not np.all(np.abs(normal).sum(axis=1) == 1):
        raise ValueError('Diagnostic boundary contains non-adjacent pixel pairs')
    mid = (a + b) / 2
    tangent = np.column_stack((-normal[:, 1], normal[:, 0])) / 2
    return np.stack(((mid-tangent)[:, ::-1], (mid+tangent)[:, ::-1]), axis=1)


def native_grid_positions(cal, sx, sy, camera):
    """Forward camera calibration for coordinates in the stitched grid."""
    lx = sx + 1 + (cal.crop if camera == 2 else 0)
    ly = sy + 1 - (cal.retained if camera == 1 else 0)
    col, row = project(cal.T[camera-1], 12*ly, 12*(133-lx))
    return row, col


@dataclass
class DisplayGeometry:
    box: tuple
    mask: np.ndarray
    native: list
    width_mm: float
    height_mm: float


def make_geometry(cal):
    """One full rectangular display extent, without separate camera masks."""
    nr, nc = cal.shape
    positions = []
    native = []
    for camera, start, stop in ((2, 0, cal.retained), (1, cal.retained, cal.ny)):
        sy, sx = np.meshgrid(np.arange(start, stop), np.arange(cal.nx), indexing='ij')
        row, col = native_grid_positions(cal, sx, sy, camera)
        positions.append((row, col))
        # Boundary half cells end at the outermost measured vector centres.
        ey = np.clip(np.arange(start, stop+1)-.5, start, stop-1)
        ex = np.clip(np.arange(cal.nx+1)-.5, 0, cal.nx-1)
        esy, esx = np.meshgrid(ey, ex, indexing='ij')
        erow, ecol = native_grid_positions(cal, esx, esy, camera)
        native.append(dict(camera=camera, rows=slice(start, stop), row=row, col=col,
                           edge_row=erow, edge_col=ecol))
    rlo = max(1, int(np.floor(min(r.min() for r, c in positions))))
    rhi = min(nr, int(np.ceil(max(r.max() for r, c in positions))))
    clo = max(1, int(np.floor(min(c.min() for r, c in positions))))
    chi = min(nc, int(np.ceil(max(c.max() for r, c in positions))))
    # Keep all measured PLIF photo pixels within the total bounding rectangle.
    # Camera support/velocity-valid masks belong to science sampling, not to
    # the photo background; masking here produced the unwanted white seam.
    mask = np.ones((rhi-rlo+1, chi-clo+1), dtype=bool)
    mm = P.delta*1000
    for mesh in native:
        for prefix in ('', 'edge_'):
            mesh[prefix+'x'] = (mesh[prefix+'row']-rlo+.5)*mm
            mesh[prefix+'y'] = (mesh[prefix+'col']-clo+.5)*mm
    return DisplayGeometry((rlo, rhi, clo, chi), mask, native,
                           mask.shape[0]*mm, mask.shape[1]*mm)


def crop_native(field, geometry):
    """Transpose + normal Y axis gives a 90-degree counterclockwise display."""
    rlo, rhi, clo, chi = geometry.box
    cropped = np.asarray(field)[rlo-1:rhi, clo-1:chi]
    return np.ma.array(cropped.T, mask=~geometry.mask.T, copy=False)


def display_boundaries(boundaries, cal, geometry):
    rlo, rhi, clo, chi = geometry.box
    mapped = {}
    for kind, pairs in boundaries.items():
        segments = boundary_segments(pairs)
        mid = segments.mean(axis=1)
        valid = ((mid[:, 0] >= clo-.5) & (mid[:, 0] <= chi+.5) &
                 (mid[:, 1] >= rlo-.5) & (mid[:, 1] <= rhi+.5))
        segments = segments[valid]
        # Geometry only: every panel receives the same unmodified edge set.
        xy = np.empty_like(segments)
        xy[..., 0] = (segments[..., 1]-rlo+.5)*P.delta*1000
        xy[..., 1] = (segments[..., 0]-clo+.5)*P.delta*1000
        mapped[kind] = xy
    return mapped


def overlay(ax, boundaries):
    for kind in ('unknown', 'internal', 'engulfed', 'interface'):
        ax.add_collection(LineCollection(boundaries[kind], colors=BOUNDARY_COLORS[kind],
                                        linewidths=1.20 if kind == 'interface' else 1.10,
                                        zorder=4))


def stitched_display_edges(geometry):
    """One connected native PIV mesh over the total rectangular display.

    Adjacent camera rows share a single mesh edge instead of two separately
    clipped patches. Enstrophy samples retain their native values; only the
    exterior display-cell borders are extended to the crop rectangle.
    """
    def edges_from_centres(a):
        padded = np.pad(a, 1, mode='edge')
        padded[0, 1:-1] = 2*a[0]-a[1]
        padded[-1, 1:-1] = 2*a[-1]-a[-2]
        padded[:, 0] = 2*padded[:, 1]-padded[:, 2]
        padded[:, -1] = 2*padded[:, -2]-padded[:, -3]
        return (padded[:-1, :-1]+padded[1:, :-1]+
                padded[:-1, 1:]+padded[1:, 1:])/4
    x = np.concatenate([m['x'] for m in geometry.native], axis=0)
    y = np.concatenate([m['y'] for m in geometry.native], axis=0)
    ex, ey = edges_from_centres(x), edges_from_centres(y)
    # Both native coordinate dimensions decrease in the requested CCW view.
    if not (np.all(np.diff(x, axis=1) < 0) and np.all(np.diff(y, axis=0) < 0)):
        raise ValueError('Unexpected orientation for the stitched display mesh')
    ex = np.clip(ex, 0, geometry.width_mm)
    ey = np.clip(ey, 0, geometry.height_mm)
    ex[:, 0], ex[:, -1] = geometry.width_mm, 0
    ey[0, :], ey[-1, :] = geometry.height_mm, 0
    return ex, ey


def render_four_panel(raw, phi, u, v, X, Y, boundaries, cal, eta, frame, case_name,
                      output_file, *, geometry=None, dpi=260):
    """Pure display from already filtered/classified data; no flux computation."""
    style()
    plt.rcParams.update({'font.size':13, 'axes.labelsize':15, 'xtick.labelsize':12,
                         'ytick.labelsize':12})
    geometry = make_geometry(cal) if geometry is None else geometry
    raw_view = crop_native(raw, geometry)
    phi_view = crop_native(phi, geometry)
    logphi = np.ma.log10(np.ma.maximum(phi_view, 1e-4))
    # Fixed range includes low concentration structures without painting log(0).
    phi_limits = (-4., .25)
    derivative = gradients(u, v, X[0], Y[:, 0])
    omega = derivative[2] - derivative[1]
    enstrophy = omega**2
    logomega = np.log(np.maximum(enstrophy, np.exp(.5)))
    edges = display_boundaries(boundaries, cal, geometry)

    # Explicit inches keep axes, bars and gaps equal; no constrained-layout
    # stretching of one panel or empty slots left for removed titles.
    panel_height = 5.25
    panel_width = panel_height*geometry.width_mm/geometry.height_mm
    left, bottom, bar_gap, bar_width, group_gap = .70, .70, .07, .12, 1.00
    group = panel_width + bar_gap + bar_width + group_gap
    fw, fh = left + 4*group - group_gap + .80, panel_height + bottom + .80
    fig = plt.figure(figsize=(fw, fh))
    axes, bars = [], []
    for j in range(4):
        x = left+j*group
        ax = fig.add_axes((x/fw, bottom/fh, panel_width/fw, panel_height/fh))
        cb = fig.add_axes(((x+panel_width+bar_gap)/fw, bottom/fh,
                           bar_width/fw, panel_height/fh))
        axes.append(ax)
        bars.append(cb)
    extent = (0, geometry.width_mm, 0, geometry.height_mm)
    rawmax = np.iinfo(raw.dtype).max if np.issubdtype(raw.dtype, np.integer) else float(raw_view.max())
    raw_image = axes[0].imshow(raw_view, origin='lower', extent=extent, cmap='gray',
                               vmin=0, vmax=rawmax, interpolation='nearest')
    images = [raw_image]
    for j in (1, 2):
        images.append(axes[j].imshow(logphi, origin='lower', extent=extent,
                                     cmap=BLUE_WHITE, vmin=phi_limits[0],
                                     vmax=phi_limits[1], interpolation='nearest'))
        overlay(axes[j], edges)
    # Render the already-stitched PIV scalar as one continuous mesh, never
    # as separately masked camera patches. No PLIF intensity resampling.
    omega_norm = Normalize(.5, 9.5)
    ex, ey = stitched_display_edges(geometry)
    omega_image = axes[3].pcolormesh(ex, ey, logomega, cmap=PASTEL_BLUE_RED,
                                    norm=omega_norm, shading='flat', rasterized=True)
    for mesh in geometry.native:
        rows = mesh['rows']
        # Rotate velocity vectors by the display coordinate Jacobian, computed
        # per camera so differences never cross the camera stitching seam.
        dx_dy, dx_dx = np.gradient(mesh['x'], Y[rows, 0], X[0], edge_order=1)
        dy_dy, dy_dx = np.gradient(mesh['y'], Y[rows, 0], X[0], edge_order=1)
        vx = dx_dx*u[rows] + dx_dy*v[rows]
        vy = dy_dx*u[rows] + dy_dy*v[rows]
        select = (slice(None, None, 10), slice(None, None, 10))
        positions = np.column_stack((mesh['row'][select].ravel(), mesh['col'][select].ravel()))
        m = cal.map(positions)
        keep = m.valid & (m.source == mesh['camera'])
        keep &= np.isfinite(vx[select].ravel()) & np.isfinite(vy[select].ravel())
        axes[2].quiver(mesh['x'][select].ravel()[keep], mesh['y'][select].ravel()[keep],
                       vx[select].ravel()[keep], vy[select].ravel()[keep],
                       angles='xy', scale_units='xy', scale=300, width=.004,
                       headwidth=3., headlength=4., color='#33444f', zorder=3)
    images.append(omega_image)
    overlay(axes[3], edges)
    labels = ['Raw intensity', r'$\log_{10}(\phi^*)$', r'$\log_{10}(\phi^*)$',
              r'$\ln(\omega_z^2)$']
    # Register ticks to measured PIV x along the middle native grid row.
    # This retains absolute x/d, instead of relabelling crop-relative mm.
    native_x = np.concatenate([m['x'] for m in geometry.native], axis=0)
    middle = X.shape[0]//2
    xd = X[middle]/P.d
    tick_xd = np.arange(np.ceil(xd.min()), np.floor(xd.max())+.01, 1.)
    tick_positions = np.interp(tick_xd, xd, native_x[middle])
    native_y = np.concatenate([m['y'] for m in geometry.native], axis=0)
    middle_x = X.shape[1]//2
    yd = Y[:, middle_x]/P.d
    tick_yd = np.arange(2*np.ceil(yd.min()/2), 2*np.floor(yd.max()/2)+.01, 2.)
    tick_y_positions = np.interp(tick_yd, yd[::-1], native_y[::-1, middle_x])
    for j, (ax, cax, im, label) in enumerate(zip(axes, bars, images, labels)):
        ax.set(xlim=extent[:2], ylim=extent[2:], aspect='equal')
        ax.set_xticks(tick_positions, labels=[f'{v:g}' for v in tick_xd])
        ax.set_yticks(tick_y_positions, labels=[f'{0. if abs(v)<1e-12 else v:g}' for v in tick_yd])
        ax.set_xlabel(r'$x/d$', fontsize=15)
        if j == 0:
            ax.set_ylabel(r'$y/d$', fontsize=15)
        frame_axes(ax)
        ax.tick_params(labelleft=True, labelsize=12, length=4, width=.8)
        ax.text(0, 1.012, f'({chr(97+j)})', transform=ax.transAxes, ha='left', va='bottom',
                fontsize=16, color='black', zorder=10, clip_on=False)
        cb = fig.colorbar(im, cax=cax)
        if j == 0:
            cb.set_ticks(np.linspace(0, rawmax, 4))
            if rawmax == 65535:
                cb.set_ticks([0, 20000, 40000, 60000])
            formatter = ScalarFormatter(useMathText=True)
            formatter.set_powerlimits((0, 0))
            cb.formatter = formatter
            cb.update_ticks()
            cb.ax.yaxis.get_offset_text().set_fontsize(11)
        else:
            cb.set_ticks([-4, -2, 0] if j in (1, 2) else [1, 3, 5, 7, 9])
        cb.set_label(label, fontsize=13, labelpad=5)
        cb.outline.set_edgecolor('black')
        cb.outline.set_linewidth(.6)
        cb.ax.yaxis.set_ticks_position('left')
        cb.ax.yaxis.set_label_position('right')
        cb.ax.tick_params(left=True, right=False, direction='in', length=3,
                          width=.7, labelsize=11, pad=3, labelleft=False, labelright=True)
    legend = [Line2D([0], [0], color=BOUNDARY_COLORS[k], lw=2, label=label)
              for k, label in [('interface','Interface'), ('engulfed','Engulfed'),
                                ('internal','Internal'), ('unknown','Unknown')]]
    fig.legend(handles=legend, loc='upper center', ncol=4, frameon=False,
               fontsize=13, bbox_to_anchor=(.52, .998), handlelength=1.6)
    path = Path(output_file)
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path, dpi=dpi, facecolor='white')
    plt.close(fig)
    return dict(rawCrop=raw_view.data, footprint=~np.ma.getmaskarray(raw_view),
                log10Phi=logphi.filled(np.nan), omega=omega, enstrophy=enstrophy,
                logEnstrophy=logomega, boundaries=edges, cropBoxRC=np.array(geometry.box),
                frame=int(frame), eta=float(eta), phiCLim=np.array(phi_limits),
                xOverD=X/P.d, yOverD=Y/P.d, axisReferenceRow=middle,
                axisReferenceColumn=middle_x)
