import argparse
from pathlib import Path
from .config import cases
from .pipeline import run

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--master',type=Path,default=Path.home()/'MSc_Project/MSc_2026_final')
    p.add_argument('--run-id',required=True)
    p.add_argument('--case',type=int,required=True)
    p.add_argument('--workers',type=int,default=4)
    p.add_argument('--limit',type=int)
    a=p.parse_args()
    if not 1<=a.case<=27:p.error('case must be 1..27')
    if a.workers<1:p.error('workers must be positive')
    if a.limit is not None and ('pilot' not in a.run_id and 'benchmark' not in a.run_id):p.error('limited frames require a pilot/benchmark run ID')
    if '/' in a.run_id or a.run_id in ('.','..'):p.error('run-id must be a single directory name')
    run(a.master,cases(a.master)[a.case-1],a.run_id,a.workers,a.limit)
if __name__=='__main__':main()
