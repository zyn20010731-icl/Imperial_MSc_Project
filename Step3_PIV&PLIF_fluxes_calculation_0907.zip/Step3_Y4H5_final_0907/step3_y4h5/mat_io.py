"""Selective MATLAB v7.3 decoding: no recursive loading of the large result."""
import numpy as np
import h5py

class Step2:
    def __init__(self,path):
        self.f=h5py.File(path,'r')
        self.refs={k:v[()].ravel() for k,v in self.f['ResultEven'].items()}
        self.meta={k:self.decode(v) for k,v in self.f['Meta'].items()}
        self.frames=np.array([self.decode(self.f[r]).item() for r in self.refs['frameNo']],dtype=np.int64)
        expected=np.asarray(self.meta['frameNoEvenUse']).ravel().astype(np.int64)
        if not np.array_equal(self.frames,expected):raise ValueError('ResultEven frame identities differ from Meta')
        if not np.array_equal((self.frames-98)//2,np.asarray(self.meta['pivFrameNoEvenUse']).ravel()):raise ValueError('PIV pairing mismatch')
        self.shape=(int(np.asarray(self.meta['nRows']).item()),int(np.asarray(self.meta['nCols']).item()))
    def decode(self,obj):
        if obj.attrs.get('MATLAB_empty',0): return np.empty(tuple(int(x) for x in obj[()].ravel()))
        a=obj[()]
        if h5py.check_dtype(ref=obj.dtype):return [self.decode(self.f[r]) for r in a.ravel()]
        if obj.attrs.get('MATLAB_class',b'')==b'char':return ''.join(chr(int(x)) for x in a.ravel())
        return a.T
    def field(self,i,key):return self.decode(self.f[self.refs[key][i]])
    def pixels(self,i,key):
        a=self.field(i,key)
        if isinstance(a,list):a=np.concatenate([x.ravel() for x in a]) if a else np.empty(0)
        a=np.asarray(a).ravel().astype(np.int64)-1
        if a.size and (a.min()<0 or a.max()>=np.prod(self.shape)):raise ValueError(f'{key} pixel index out of bounds')
        return a
    def cells(self,i,key):
        a=self.field(i,key)
        return a if isinstance(a,list) else [] if np.asarray(a).size==0 else [a]
    def interface(self,i):
        arrays=[a.reshape(-1,4) for a in self.cells(i,'interfaceRC') if a.size]
        pairs=np.concatenate(arrays).astype(float) if arrays else np.empty((0,4))
        if pairs.size and not np.all(np.abs(pairs[:,:2]-pairs[:,2:]).sum(1)==1):raise ValueError('Non-adjacent interface pair')
        return (pairs[:,:2]+pairs[:,2:])/2
    def close(self):self.f.close()
