"""Table-ready reports generated from completed Step3 case H5 files.

The reporting layer reads the validated per-case results assembled by
``combine.py``. It does not reopen Step1/Step2 inputs or recompute science.
"""

from pathlib import Path
import csv
import math

import numpy as np


METHODS = ("actual", "yBased", "xiBased")
QUANTITIES = (
    ("mass", "M", "kg/(m s)"),
    ("momentum", "P_x", "N/m"),
    ("kinetic", "K", "W/m"),
)
REGIONS = (("engulfed", "e"), ("wake", "w"))


def _scalar(value):
    a = np.asarray(value)
    return a.item() if a.ndim == 0 else value


def _finite(value):
    value = float(value)
    return value if math.isfinite(value) else float("nan")


def _case_label(item):
    case = item["case"]
    return f"{case['distance']} / {case['name']}"


def _final(item):
    return item["data"]["Final"]


def _flux_row(item, method):
    """Return dimensional, non-dimensional and contribution values."""
    final = _final(item)
    case = item["case"]
    values = np.asarray(final[method], dtype=float)
    nondim = np.asarray(final[method + "Nondimensional"], dtype=float)
    fraction = np.asarray(final[method + "Fraction"], dtype=float)
    row = {
        "distance": case["distance"],
        "caseName": case["name"],
        "dataSet": _case_label(item),
        "method": method,
        "nFrames": int(_scalar(final["nFrames"])),
        "epsilon_I_m2_s3": _finite(final["epsilon_I"]),
        "eta_I_m": _finite(final["eta_I"]),
        "xiMax_m": _finite(final.get("xiMax_m", np.nan)),
    }
    for j, (quantity, _, _) in enumerate(QUANTITIES):
        for z, (region, _) in enumerate(REGIONS):
            row[f"{quantity}_{region}"] = _finite(values[j, z])
            row[f"{quantity}_{region}_star"] = _finite(nondim[j, z])
        row[f"{quantity}_contribution"] = _finite(fraction[j])
        row[f"{quantity}_contribution_percent"] = 100.0 * row[f"{quantity}_contribution"]
    return row


def _write_csv(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields = list(rows[0])
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def _fmt(value):
    if isinstance(value, str):
        return value
    try:
        value = float(value)
    except (TypeError, ValueError):
        return str(value)
    return "nan" if not math.isfinite(value) else f"{value:.8g}"


def _write_tsv(path, rows, fields=None):
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields = fields or list(rows[0])
    lines = ["\t".join(fields)]
    lines.extend("\t".join(_fmt(row.get(k, "")) for k in fields) for row in rows)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def _table_rows(items, method):
    """Rows with the same five values per quantity as old Tables A1--A3."""
    rows = []
    for item in items:
        source = _flux_row(item, method)
        row = {"Data set": source["dataSet"]}
        for quantity, _, _ in QUANTITIES:
            row[f"{quantity}_e"] = source[f"{quantity}_engulfed"]
            row[f"{quantity}_e_star"] = source[f"{quantity}_engulfed_star"]
            row[f"{quantity}_w"] = source[f"{quantity}_wake"]
            row[f"{quantity}_w_star"] = source[f"{quantity}_wake_star"]
            row[f"{quantity}_contribution"] = source[f"{quantity}_contribution"]
        rows.append(row)
    return rows


def _comparison_rows(items):
    """Table A4: (approximation - Actual)/Actual in percent."""
    rows = []
    for item in items:
        actual = _flux_row(item, "actual")
        y = _flux_row(item, "yBased")
        xi = _flux_row(item, "xiBased")
        row = {"Data set": actual["dataSet"]}
        # Keep the same column grouping as the old Table A4: all x-y
        # approximation columns first, followed by all xi columns.
        for source, prefix in ((y, "xy"), (xi, "xi")):
            for quantity, _, _ in QUANTITIES:
                for region, short in REGIONS:
                    a = actual[f"{quantity}_{region}"]
                    b = source[f"{quantity}_{region}"]
                    row[f"{prefix}_{quantity}_{short}"] = (
                        100.0 * (b - a) / a if math.isfinite(a) and a != 0 else float("nan")
                    )
        rows.append(row)
    return rows


def _contribution_rows(items):
    """Table A5: contribution fractions and differences from Actual."""
    rows = []
    for item in items:
        actual = _flux_row(item, "actual")
        y = _flux_row(item, "yBased")
        xi = _flux_row(item, "xiBased")
        row = {"Data set": actual["dataSet"]}
        for quantity, _, _ in QUANTITIES:
            a = actual[f"{quantity}_contribution"]
            b = y[f"{quantity}_contribution"]
            c = xi[f"{quantity}_contribution"]
            row[f"{quantity}_actual"] = a
            row[f"{quantity}_xy_minus_actual"] = b - a
            row[f"{quantity}_xi_minus_actual"] = c - a
            row[f"{quantity}_xy_minus_actual_percentage_points"] = 100.0 * (b - a)
            row[f"{quantity}_xi_minus_actual_percentage_points"] = 100.0 * (c - a)
        rows.append(row)
    return rows


def _latex_escape(value):
    return str(value).replace("&", r"\&").replace("_", r"\_")


def _latex_number(value):
    try:
        value = float(value)
    except (TypeError, ValueError):
        return "--"
    return "--" if not math.isfinite(value) else f"{value:.5g}"


def _tex_flux_label(quantity, region, star=False):
    """Return a valid single-subscript TeX label for a flux component."""
    if quantity == "momentum":
        label = f"P_{{x{region}}}"
    else:
        symbol = {"mass": "M", "kinetic": "K"}[quantity]
        label = f"{symbol}_{{{region}}}"
    return label + ("^*" if star else "")


def _tex_contribution_label(quantity):
    return f"{_tex_flux_label(quantity, 'e')}/{_tex_flux_label(quantity, 'w')}"


def _write_flux_tex(path, rows, caption):
    """Write a compact, directly includable version of Tables A1--A3."""
    groups = [(quantity, symbol, unit) for quantity, symbol, unit in QUANTITIES]
    lines = [
        r"\begin{table}[htbp]",
        r"\centering",
        r"\scriptsize",
        r"\setlength{\tabcolsep}{2.5pt}",
        r"\begin{tabular}{l" + "rrrrr" * len(groups) + "}",
        r"\toprule",
        "& " + " & ".join(
            f"\\multicolumn{{5}}{{c}}{{{symbol}}}" for _, symbol, _ in groups
        ) + r"\\",
        r"\cmidrule(lr){2-6}\cmidrule(lr){7-11}\cmidrule(lr){12-16}",
        "Data set & " + " & ".join(
            f"${_tex_flux_label(quantity, 'e')}$ & ${_tex_flux_label(quantity, 'e', True)}$ & "
            f"${_tex_flux_label(quantity, 'w')}$ & ${_tex_flux_label(quantity, 'w', True)}$ & $E/W$"
            for quantity, _, _ in groups
        ) + r"\\",
        "& " + " & ".join(
            f"\\multicolumn{{1}}{{c}}{{{unit}}} & -- & \\multicolumn{{1}}{{c}}{{{unit}}} & -- & --" for _, _, unit in groups
        ) + r"\\",
        r"\midrule",
    ]
    for row in rows:
        values = [_latex_escape(row["Data set"])]
        for quantity, _, _ in groups:
            values.extend(
                _latex_number(row[f"{quantity}_{suffix}"])
                for suffix in ("e", "e_star", "w", "w_star", "contribution")
            )
        lines.append(" & ".join(values) + r"\\")
    lines.extend([r"\bottomrule", r"\end{tabular}", f"\\caption{{{caption}}}", r"\end{table}", ""])
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")


def _write_comparison_tex(path, rows, contribution=False):
    if contribution:
        columns = ["Data set"]
        for quantity, symbol, _ in QUANTITIES:
            columns.extend((f"{quantity}_actual", f"{quantity}_xy_minus_actual", f"{quantity}_xi_minus_actual"))
        header = "Data set & " + " & ".join(
            f"${_tex_contribution_label(quantity)}^{{\\rm Actual}}$ & "
            f"$\\Delta {_tex_contribution_label(quantity)}^{{x-y}}$ & "
            f"$\\Delta {_tex_contribution_label(quantity)}^{{\\xi}}$"
            for quantity, _, _ in QUANTITIES
        ) + r"\\"
        spec = "l" + "rrr" * len(QUANTITIES)
        caption = "Engulfment-to-wake contribution fractions and differences from the Actual calculation."
    else:
        columns = ["Data set"]
        for prefix in ("xy", "xi"):
            for quantity, symbol, _ in QUANTITIES:
                columns.extend((f"{prefix}_{quantity}_e", f"{prefix}_{quantity}_w"))
        header = "Data set & " + " & ".join(
            f"$\\Delta {_tex_flux_label(quantity, 'e')}^{{x-y}}$ & $\\Delta {_tex_flux_label(quantity, 'w')}^{{x-y}}$"
            for quantity, _, _ in QUANTITIES
        ) + " & " + " & ".join(
            f"$\\Delta {_tex_flux_label(quantity, 'e')}^{{\\xi}}$ & $\\Delta {_tex_flux_label(quantity, 'w')}^{{\\xi}}$"
            for quantity, _, _ in QUANTITIES
        ) + r"\\"
        spec = "l" + "rrrr" * len(QUANTITIES)
        caption = "Percentage differences of the y and xi approximations from the Actual calculation."
    lines = [r"\begin{table}[htbp]", r"\centering", r"\scriptsize", f"\\begin{{tabular}}{{{spec}}}", r"\toprule", header, r"\midrule"]
    for row in rows:
        values = [_latex_escape(row["Data set"])]
        values.extend(_latex_number(row[key]) for key in columns[1:])
        lines.append(" & ".join(values) + r"\\")
    lines.extend([r"\bottomrule", r"\end{tabular}", f"\\caption{{{caption}}}", r"\end{table}", ""])
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")


def write_table_reports(root, items):
    """Create complete five-table reports for all completed cases."""
    if len(items) != 27:
        raise ValueError(f"Expected 27 completed cases for table reports, found {len(items)}")
    root = Path(root)
    folder = root / "TABLES_0906"
    folder.mkdir(parents=True, exist_ok=True)

    all_flux = [_flux_row(item, method) for item in items for method in METHODS]
    _write_csv(folder / "Y_flux_all_methods_0906.csv", all_flux)
    _write_tsv(folder / "Y_flux_all_methods_0906.txt", all_flux)

    captions = {
        "actual": "Actual engulfed and wake fluxes for all 27 Step3 cases.",
        "yBased": "Engulfed and wake fluxes from the laboratory-coordinate y approximation for all 27 Step3 cases.",
        "xiBased": "Engulfed and wake fluxes from the local-interface xi approximation for all 27 Step3 cases.",
    }
    for index, method in enumerate(METHODS, 1):
        rows = _table_rows(items, method)
        stem = f"Y_flux_table_A{index}_{method}_0906"
        _write_csv(folder / f"{stem}.csv", rows)
        _write_tsv(folder / f"{stem}.txt", rows)
        _write_flux_tex(folder / f"{stem}.tex", rows, captions[method])

    comparison = _comparison_rows(items)
    _write_csv(folder / "Y_flux_table_A4_percentage_differences_0906.csv", comparison)
    _write_tsv(folder / "Y_flux_table_A4_percentage_differences_0906.txt", comparison)
    _write_comparison_tex(folder / "Y_flux_table_A4_percentage_differences_0906.tex", comparison)

    contribution = _contribution_rows(items)
    _write_csv(folder / "Y_flux_table_A5_contribution_comparison_0906.csv", contribution)
    _write_tsv(folder / "Y_flux_table_A5_contribution_comparison_0906.txt", contribution)
    _write_comparison_tex(folder / "Y_flux_table_A5_contribution_comparison_0906.tex", contribution, contribution=True)

    physics = []
    for item in items:
        final = _final(item)
        case = item["case"]
        physics.append({
            "distance": case["distance"], "caseName": case["name"], "dataSet": _case_label(item),
            "epsilon_I_m2_s3": _finite(final["epsilon_I"]), "eta_I_m": _finite(final["eta_I"]),
            "xiMax_m": _finite(final.get("xiMax_m", np.nan)), "nFrames": int(_scalar(final["nFrames"])),
        })
    _write_csv(folder / "Y_case_physics_summary_0906.csv", physics)
    _write_tsv(folder / "Y_case_physics_summary_0906.txt", physics)

    report = [
        "Step3 Y4H5 complete numerical reports",
        "27 formal cases; L = 30 mm.",
        "Dimensional units: mass kg/(m s), momentum N/m, kinetic energy W/m.",
        "Contribution is the engulfed-to-wake fraction; multiply by 100 for percent.",
        "",
    ]
    for title, rows in (
        ("TABLE A1 — ACTUAL", _table_rows(items, "actual")),
        ("TABLE A2 — Y APPROXIMATION", _table_rows(items, "yBased")),
        ("TABLE A3 — XI APPROXIMATION", _table_rows(items, "xiBased")),
        ("TABLE A4 — PERCENTAGE DIFFERENCES FROM ACTUAL", comparison),
        ("TABLE A5 — ENGULFMENT CONTRIBUTION COMPARISON", contribution),
    ):
        report.append(title)
        if rows:
            fields = list(rows[0])
            report.append("\t".join(fields))
            report.extend("\t".join(_fmt(row.get(k, "")) for k in fields) for row in rows)
        report.append("")
    (folder / "Y_complete_flux_tables_A1_A5_0906.txt").write_text("\n".join(report), encoding="utf-8")

    manifest_path = folder / "Y_TABLES_0906_manifest.txt"
    manifest = sorted(str(path.relative_to(root)) for path in folder.rglob("*") if path.is_file() and path != manifest_path)
    manifest_path.write_text("\n".join(manifest) + "\n", encoding="utf-8")
