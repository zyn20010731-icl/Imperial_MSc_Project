#!/bin/bash
set -euo pipefail

# Run this script from the directory that contains Step1_PLIF_threshold_1.0
# after transferring/unzipping the package to CX3.
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MASTER="${HOME}/MSc_Project/MSc_2026_final"
DST="${MASTER}/01_CODE/Step1_PLIF_threshold_1.0"

mkdir -p "$DST" \
         "$MASTER/04_LOGS/Step1_PLIF_threshold_1.0" \
         "$MASTER/05_OUTPUTS" \
         "$MASTER/06_MANIFESTS"

# Copy package files. This never touches 02_INPUTS/PLIF.
cp -f "$SRC"/Step1_PLIF_threshold_1_0.m "$DST"/
cp -f "$SRC"/cases_28.csv "$DST"/
cp -f "$SRC"/preflight_Step1_PLIF_threshold_1_0.sh "$DST"/
cp -f "$SRC"/run_Step1_PLIF_threshold_1_0.pbs "$DST"/
cp -f "$SRC"/submit_Step1_PLIF_threshold_1_0.sh "$DST"/
cp -f "$SRC"/check_Step1_PLIF_threshold_1_0_progress.sh "$DST"/
cp -f "$SRC"/README.txt "$DST"/

chmod +x "$DST"/*.sh "$DST"/*.pbs
cp -f "$DST/cases_28.csv" "$MASTER/06_MANIFESTS/Step1_PLIF_threshold_1.0_cases_28.csv"

echo "Installed to: $DST"
echo "Next: cd '$DST' && ./preflight_Step1_PLIF_threshold_1_0.sh"
