"""Publication figures: serif typography, restrained blue palette, vector PDFs."""
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import LogLocator, LogFormatterMathtext, NullFormatter
from .config import P
BLUE='#397da8';PALE='#8ac0da';RED='#b96e64'
# Muted JFM-style colours, long enough for all multi-case overlays. The order
# is stable so a case/distance keeps the same colour in every grouped figure.
COLORS=['#245979','#397da8','#579cba','#82bdd0','#a7ccd5','#547b96',
        '#8b758e','#9a6a53','#c1843d','#5f8f73','#6e6e9e','#b06b83']
HOLE_CASE_COLORS = {
    'NoGrid': '#397da8',
    'SFG312_SC11d': '#74609d',
    'SFG312_SC237d': '#b96e64',
    'SFG354_SC15d': '#438c85',
    'SRG38_SC20d': '#a48a48',
    'SRG111_SC22d': '#6689b6',
    'SRG111_SC39d': '#ad779b',
}
HOLE_MARKERS = {'engulfed': '^', 'internal': 's'}

def hole_case_color(case_name):
    canonical = 'SFG312_SC237d' if case_name == 'SFG312_SC237' else case_name
    return HOLE_CASE_COLORS[canonical]

def style():
    plt.rcParams.update({'font.family':'serif','font.serif':['Times New Roman','STIXGeneral','DejaVu Serif'],
      'mathtext.fontset':'stix','font.size':10,'axes.labelsize':11,'axes.titlesize':10,'legend.fontsize':8,
      'axes.linewidth':.7,'lines.linewidth':1.4,'xtick.direction':'in','ytick.direction':'in',
      'xtick.top':False,'ytick.right':False,
      'axes.spines.top':True,'axes.spines.right':True,
      'savefig.dpi':350,'pdf.fonttype':42,'ps.fonttype':42,
      'axes.prop_cycle':matplotlib.cycler(color=COLORS),'figure.facecolor':'white'})

def frame_axes(ax):
    """Use four smooth black spines; ticks only extend from left/bottom."""
    for side in ('left','bottom','right','top'):
        spine=ax.spines[side]
        spine.set_visible(True)
        spine.set_color('black')
        spine.set_linewidth(.7)
    ax.tick_params(axis='x',which='both',bottom=True,top=False,direction='out',
                   length=3.2,width=.7,color='black')
    ax.tick_params(axis='y',which='both',left=True,right=False,direction='out',
                   length=3.2,width=.7,color='black')
    ax.tick_params(axis='both',which='minor',length=1.8,width=.6)

def save(fig,path):
    path.parent.mkdir(parents=True,exist_ok=True)
    for ax in fig.axes: frame_axes(ax)
    fig.savefig(path.with_suffix('.png'),bbox_inches='tight')
    fig.savefig(path.with_suffix('.pdf'),bbox_inches='tight')
    plt.close(fig)

def mirror_y(x, values):
    """Mirror a positive-y profile for display only; it is not reintegrated."""
    x=np.asarray(x)
    v=np.asarray(values)
    return np.concatenate((-x[::-1],x)), np.concatenate((v[...,::-1],v),axis=-1)

def profiles_plot(out,profile,coordinate,eta,title):
    style();folder='04_y_approximation' if coordinate=='y' else '05_xi_approximation'
    x=profile['coordinate_m']/(P.d if coordinate=='y' else eta)
    xlabel=r'$y/d$' if coordinate=='y' else r'$\xi/\eta_I$'
    quantities=[('ubar',profile['finished'][0],r'$\overline{U}\;(\mathrm{m\,s^{-1}})$'),
                ('PE',profile['finished'][3],r'$P_E$'),('Pwake',profile['finished'][4],r'$P_W$')]
    for name,a,label in quantities:
        xp,ap=mirror_y(x,a) if coordinate=='y' else (x,a)
        fig,ax=plt.subplots(figsize=(3.45,2.6),layout='constrained')
        if coordinate=='xi' and name=='ubar':
            # ξ=0 can be an empty bin because the interface lies between
            # neighbouring pixel centres.  Do not plot its synthetic zero;
            # connecting the two nearest valid sides keeps the line smooth.
            keep=~((profile['bins']==0)&(profile['sums'][4]==0))
            ax.plot(xp[keep],ap[keep],color=BLUE)
        else:
            ax.plot(xp,ap,color=BLUE)
        ax.set(xlabel=xlabel,ylabel=label)
        if coordinate=='xi':
            if name=='ubar':
                ax.set_xlim(-300,300)
                ax.set_xticks([-300,-150,0,150,300])
            else:ax.set_xlim(-50,50)
        save(fig,out.path(f'results/{folder}/Y_{name}_{coordinate}_JFM_case_0906'))
    refs=np.array(P.refs)/P.d
    for j,(name,label) in enumerate(zip(('mass','momentum','kinetic_energy'),(r'$J_m/(\rho U_\infty)$',r'$J_p/(\rho U_\infty^2)$',r'$J_k/(\frac{1}{2}\rho U_\infty^3)$'))):
        fig,axes=plt.subplots(1,2,figsize=(6.9,2.6),layout='constrained')
        for z,ax in enumerate(axes):
            values=profile['density'][j,z]/refs[j]
            xp,yp=mirror_y(x,values) if coordinate=='y' else (x,values)
            ax.plot(xp,yp,color=(BLUE if z==0 else PALE))
            ax.set(xlabel=xlabel,ylabel=label,title=('(a) Engulfed' if z==0 else '(b) Wake'))
            if coordinate=='xi':ax.set_xlim(-50,50)
        save(fig,out.path(f'results/{folder}/Y_{name}_flux_density_{coordinate}_JFM_case_0906'))

def pdf_data(holes):
    rows=[h for h in holes if h['passesPivResolutionCutoff']]
    sizes=np.array([h['characteristicSize_normalisedByEta'] for h in rows]);eng=np.array([h['isEngulfed'] for h in rows],bool)
    if not len(sizes):return []
    lower=sizes.min();upper=sizes.max()
    if lower==upper:lower/=np.sqrt(10);upper*=np.sqrt(10)
    edges=np.geomspace(lower,upper,21);centres=np.sqrt(edges[:-1]*edges[1:]);counts=[];densities=[]
    for mask in (eng,~eng):
        counts.append(np.histogram(sizes[mask],edges)[0]);n=int(mask.sum())
        densities.append(counts[-1]/(n*np.diff(edges)) if n else np.full(20,np.nan))
    return [dict(binLower_sqrtAh_over_eta=edges[j],binUpper_sqrtAh_over_eta=edges[j+1],binCentre_sqrtAh_over_eta=centres[j],engulfedCount=int(counts[0][j]),engulfedPdf=densities[0][j],internalCount=int(counts[1][j]),internalPdf=densities[1][j]) for j in range(20)]

def hole_pdf_figure(series, title='', *, combined=False):
    """Plot saved PDF points; shape encodes population, color encodes case family.

    Each series supplies caseName, population, x and pdf. Distances retain their
    own PDF bins. Combining concatenates plotted points only, never raw holes.
    """
    style()
    fig, ax = plt.subplots(figsize=(5.2,4.7), layout='constrained')
    ax.set(xscale='log', yscale='log')
    points = {'engulfed': [], 'internal': []}
    present_cases = set()
    for data in series:
        population = data['population']
        x, y = np.asarray(data['x'], dtype=float), np.asarray(data['pdf'], dtype=float)
        valid = np.isfinite(x) & np.isfinite(y) & (x>0) & (y>0)
        if not valid.any():
            continue
        xx, yy = x[valid], y[valid]
        color = hole_case_color(data['caseName'])
        ax.plot(xx, yy, linestyle='none', marker=HOLE_MARKERS[population],
                ms=3.5 if combined else 6.2,
                mfc='none' if population=='engulfed' else color, mec=color,
                mew=.8 if combined else 1.0, alpha=.65 if combined else .95,
                zorder=3)
        points[population].append((xx, yy))
        present_cases.add(data['caseName'])

    for population, slope in [('engulfed',-5), ('internal',-3)]:
        if not points[population]:
            continue
        x = np.concatenate([part[0] for part in points[population]])
        y = np.concatenate([part[1] for part in points[population]])
        if x.min() == x.max():
            continue
        # Fixed exponents from the guide; the anchor is the geometric mean of
        # each population's positive saved PDF points, not a regression fit.
        x0, y0 = np.exp(np.log(x).mean()), np.exp(np.log(y).mean())
        xref = np.geomspace(x.min(), x.max(), 100)
        yref = y0*(xref/x0)**slope
        ax.plot(xref, yref, '--', color='.55', lw=1.1, zorder=2)
        k = 72
        ax.annotate(rf'${slope}$ Slope', (xref[k], yref[k]),
                    xytext=(-10,-7) if population=='engulfed' else (7,8),
                    ha='right' if population=='engulfed' else 'left',
                    va='top' if population=='engulfed' else 'bottom',
                    textcoords='offset points', fontsize=12, color='.40')

    all_x = [part[0] for population in points.values() for part in population]
    if all_x:
        x = np.concatenate(all_x)
        # Include the next full decade, so the logarithmic axis has the same
        # explicit 10^n tick notation as the user's reference figure.
        ax.set_xlim(x.min()*.88, 10**np.ceil(np.log10(x.max()*1.05)))
    else:
        ax.text(.5,.5,'No resolved holes',ha='center',transform=ax.transAxes)
    ax.set_xlabel(r'$A_h^{1/2}/\eta_I$', fontsize=16)
    ax.set_ylabel(r'$P\!\left(A_h^{1/2}/\eta_I\right)$', fontsize=16)
    # The thesis supplies the caption; do not place a case/pilot title inside.
    ax.tick_params(labelsize=13)
    for axis in (ax.xaxis, ax.yaxis):
        axis.set_major_locator(LogLocator(base=10, subs=(1,), numticks=10))
        axis.set_major_formatter(LogFormatterMathtext(base=10))
        axis.set_minor_locator(LogLocator(base=10, subs=(2,5), numticks=30))
        axis.set_minor_formatter(NullFormatter())
    legend_color = hole_case_color(next(iter(present_cases))) if len(present_cases)==1 else '.35'
    handles = [Line2D([],[],linestyle='none',marker=HOLE_MARKERS[population],
                      markersize=6.2, markeredgecolor=legend_color,
                      markerfacecolor='none' if population=='engulfed' else legend_color,
                      label=population.capitalize())
               for population in points if points[population]]
    if handles:
        ax.legend(handles=handles, frameon=False, fontsize=12)
    return fig, ax


def pdf_plot(out,rows,title,*,case_name):
    x = np.array([r['binCentre_sqrtAh_over_eta'] for r in rows])
    series = [dict(caseName=case_name, population=population, x=x,
                   pdf=np.array([r[population+'Pdf'] for r in rows]))
              for population in ('engulfed','internal')]
    fig, _ = hole_pdf_figure(series, title)
    save(fig,out.path('results/02_holes/Y_hole_characteristic_size_PDF_case_0906'))
