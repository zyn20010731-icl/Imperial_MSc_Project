"""Precheck read-only inputs and submit a NEW 27-case run; never delete a run."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

CODE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(CODE))
import h5py
import netCDF4
from step3_y4h5.config import cases

LARGE = {16,17,18,19,20,21,23,24,25,26,27}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--master', type=Path, default=Path.home()/'MSc_Project/MSc_2026_final')
    parser.add_argument('--run-id', required=True)
    parser.add_argument('--python', default='/rds/general/user/iz425/ephemeral/conda_envs/step3_env/bin/python')
    parser.add_argument('--dry-run', action='store_true', help='Read-only precheck; no files or jobs created')
    args = parser.parse_args()
    if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*', args.run_id):
        parser.error('run-id must be a single directory name')
    master = args.master.resolve(strict=True)
    root = master/'06_OUTPUTS_Y4H5'/args.run_id
    if root.exists():
        raise ValueError('Output directory already exists; choose a new run-id. This tool never resubmits a partial run.')
    py = Path(args.python).absolute()
    # PBS -v is comma-separated: these HPC paths must have no spaces/commas.
    for path in (master, CODE, py):
        if not re.fullmatch(r'/[A-Za-z0-9_./-]+', str(path)):
            raise ValueError(f'Unsupported PBS environment path: {path}')
    if not py.is_file():
        raise FileNotFoundError(py)
    case_list = cases(master)
    input_paths = {master/'01_CODE/Step2_PLIF_interface_2.0/cases_28.csv'}
    input_paths.update(master/f'02_INPUTS/SPATIAL_CALIBRATION/tform_{cam}_to_PLIF_matrix.mat'
                       for cam in ('normal','tilted'))
    for case in case_list:
        input_paths.update(Path(case[key]) for key in ('mat','piv','done'))
        with h5py.File(case['mat'], 'r') as f:
            if float(f['Meta/minHoleAreaPx'][()].squeeze()) != 0 or bool(f['Meta/areaBasedCleanup'][()].squeeze()):
                raise ValueError(f'Old Step2 cleanup metadata: {case["mat"]}')
        with netCDF4.Dataset(case['piv'], 'r') as f:
            pair = ('vel_xFulls','vel_yFulls') if 'vel_xFulls' in f.variables else ('velxFulls','velyFulls')
            if f[pair[0]].shape != f[pair[1]].shape or f[pair[0]].shape[0] != 2501:
                raise ValueError(f'Expected 2501 smoothed U/V frames: {case["piv"]}')
    snapshots = []
    for path in sorted(input_paths):
        if not path.is_file():
            raise FileNotFoundError(path)
        st = path.stat()
        snapshots.append(dict(path=str(path),size=st.st_size,mtime_ns=st.st_mtime_ns))
    plan = dict(state='PRECHECK_PASSED', runId=args.run_id, code=str(CODE), root=str(root),
                cases=[dict(index=c['index'],distance=c['distance'],name=c['name'],
                            memoryGB=64 if c['index'] in LARGE else 32, cpus=8) for c in case_list])
    if args.dry_run:
        print(json.dumps(plan, indent=2))
        return
    # Exclusive creation prevents duplicate submissions and completed-run overwrites.
    root.mkdir(parents=True, exist_ok=False)
    control = root/'_control'
    logs = control/'pbs_logs'
    logs.mkdir(parents=True)
    (control/'input_precheck.json').write_text(json.dumps(snapshots,indent=2)+'\n')
    hashes = {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (CODE/'step3_y4h5').glob('*.py')}
    (control/'SOURCE_SHA256.json').write_text(json.dumps(hashes,indent=2)+'\n')
    (control/'submission_plan.json').write_text(json.dumps(plan,indent=2)+'\n')
    env = f'STEP3_MASTER={master},STEP3_CODE={CODE},STEP3_RUN={args.run_id},STEP3_PY={py}'
    with (control/'submissions.jsonl').open('x') as stream:
        def record(value):
            stream.write(json.dumps(value)+'\n')
            stream.flush()
            os.fsync(stream.fileno())
        def submit(info, argv):
            record(dict(info,state='SUBMITTING',args=argv))
            try:
                result = subprocess.run(['/opt/pbs/bin/qsub',*argv],cwd=CODE,text=True,
                                        capture_output=True,timeout=60)
            except subprocess.TimeoutExpired:
                record(dict(info,state='SUBMISSION_UNKNOWN',error='qsub timed out; inspect PBS before any retry'))
                raise
            value = dict(info,state='SUBMITTED' if result.returncode==0 else 'FAILED',
                         jobId=result.stdout.strip(),stderr=result.stderr.strip())
            record(value)
            print(json.dumps(value),flush=True)
            result.check_returncode()
            return value['jobId']
        jobs = []
        for case in plan['cases']:
            index=case['index']
            jobs.append(submit(dict(kind='case',caseIndex=index),[
                '-N',f'step3_{index:02d}','-v',env+f',STEP3_CASE={index}',
                '-l',f'select=1:ncpus=8:mem={case["memoryGB"]}gb',
                '-o',str(logs/f'case_{index:02d}.log'),str(CODE/'hpc/run_case.pbs')]))
        submit(dict(kind='combine',dependsOn=jobs),[
            '-v',env,'-W','depend=afterok:'+':'.join(jobs),
            '-o',str(logs/'combine.log'),str(CODE/'hpc/run_combine.pbs')])


if __name__ == '__main__':
    main()
