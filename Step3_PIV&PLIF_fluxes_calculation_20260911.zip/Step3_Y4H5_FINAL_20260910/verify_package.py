"""Verify every archived source/document against PACKAGE_SHA256.json (read only)."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parent
manifest = json.loads((root/'PACKAGE_SHA256.json').read_text())
for entry in manifest['files']:
    path = root/entry['relativePath']
    if not path.is_file():
        raise SystemExit(f'Missing package file: {path}')
    if path.stat().st_size != entry['sizeBytes']:
        raise SystemExit(f'Changed package size: {path}')
    if hashlib.sha256(path.read_bytes()).hexdigest() != entry['sha256']:
        raise SystemExit(f'Changed package content: {path}')
print(f'VERIFIED: {len(manifest["files"])} package files')
