"""Read-only audit of the restored PIV-area cutoff v4 run against its own numerical results.

Run from the deployed Step3 code directory with the Step3 Python environment.
The report is printed to stdout; this script never writes experiment files.
"""
import argparse
import csv
import hashlib
import json
import re
from pathlib import Path

import h5py
import numpy as np

from step3_y4h5.config import P, cases

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--master', type=Path, default=Path.home() / 'MSc_Project/MSc_2026_final')
parser.add_argument('--run-id', required=True)
args = parser.parse_args()
if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]*', args.run_id):
    parser.error('run-id must be a single directory name')
master = args.master.resolve()
root = master / '06_OUTPUTS_Y4H5' / args.run_id
source_root = Path(__file__).resolve().parent
quantities = ('mass', 'momentum', 'kinetic')
methods = ('actual', 'yBased', 'xiBased')
data = {}
report = {'cases': 0, 'input_and_code_identity_cases': 0, 'checked_summary_texts': 0,
          'checked_profile_csvs': 0, 'tables': {}}


def rows(path, delimiter=','):
    with path.open(newline='', encoding='utf-8') as stream:
        return list(csv.DictReader(stream, delimiter=delimiter))


def equal(actual, expected, rtol=1e-12, atol=1e-15):
    np.testing.assert_allclose(actual, expected, rtol=rtol, atol=atol, equal_nan=True)


for case in cases(master):
    folder = root / case['distance'] / case['name']
    done = json.loads((folder / 'Step3_Y4H5_DONE_0906.txt').read_text())
    assert done['state'] == 'VALIDATED', (folder, done['state'])
    manifest = folder / 'Step3_Y4H5_outputs_0906.tsv'
    assert hashlib.sha256(manifest.read_bytes()).hexdigest() == done['manifestSha256']
    for entry in rows(manifest, '\t'):
        path = folder / entry['relativePath']
        assert path.is_file() and path.stat().st_size == int(entry['sizeBytes']), path
    identity = json.loads((folder / 'runtime/identity.json').read_text())
    assert identity['extra']['case']['phiTag'] == case['phiTag']
    assert identity['extra']['case']['mat'] == case['mat']
    if case['distance'] == '5D':
        assert case['phiTag'] == 'phi0500'
    for name, expected in identity['extra']['code'].items():
        assert hashlib.sha256((source_root / 'step3_y4h5' / name).read_bytes()).hexdigest() == expected, name
    with h5py.File(case['mat'], 'r') as step2:
        assert float(np.asarray(step2['Meta/minHoleAreaPx'][()]).squeeze()) == 0
        assert not bool(np.asarray(step2['Meta/areaBasedCleanup'][()]).squeeze())
    report['input_and_code_identity_cases'] += 1
    for entry in identity['inputs']:
        stat = Path(entry['path']).stat()
        assert (stat.st_size, stat.st_mtime_ns) == (entry['size'], entry['mtime_ns'])
    with h5py.File(folder / '_shared/Y_MEAN_VELOCITY_0906.h5', 'r') as mean:
        minimum = 4*float(np.median(np.diff(mean['x'][0])))*float(np.median(np.abs(np.diff(mean['y'][:, 0]))))
    with (folder / 'results/02_holes/Y_holes_detailed_case_0906.csv').open(newline='') as stream:
        for hole in csv.DictReader(stream):
            assert int(hole['area_px'])*P.delta**2 >= minimum, (case, hole['holeIndex'])
            assert hole['passesPivResolutionCutoff'] == 'True'
            equal(float(hole['minimumResolvedHoleArea_m2']), minimum, rtol=6e-12)
    report.setdefault('piv_area_cutoff_cases_verified', 0)
    report['piv_area_cutoff_cases_verified'] += 1
    with h5py.File(folder / 'results/06_final/Y_FINAL_case_0906.h5', 'r') as f:
        final = {key: val[()] for key, val in f['Final'].items()}
        label = case['distance'] + ' / ' + case['name']
        data[label] = final
        equal(final['actual'], f['ActualFrames'][()].mean(axis=0))
        equal(final['xiBased'], f['XiFrames'][()].mean(axis=0))
        equal(final['yBased'], 2 * P.delta * f['ProfilesY/density'][()].sum(axis=2))
        for population in ('engulfed', 'internal', 'total'):
            for key in f['HoleCountStatistics/All/' + population]:
                equal(f['HoleCountStatistics/All/' + population + '/' + key][()],
                      f['HoleCountStatistics/Resolved/' + population + '/' + key][()])
        for row in rows(folder / 'results/02_holes/Y_hole_counts_by_frame_case_0906.csv'):
            for population in ('Engulfed', 'Internal', 'Total'):
                assert int(row['All' + population]) == int(row['Resolved' + population])
        for group in ('ProfilesY', 'ProfilesXi'):
            sums = f[group + '/sums'][()]
            valid = sums[3] > 0
            equal(f[group + '/raw'][0, valid], sums[0, valid] / sums[3, valid])
        xi = f['ProfilesXi']
        keep = ~((xi['bins'][()] == 0) & (xi['sums'][4] == 0))
        report.setdefault('empty_xi_zero_bins_omitted', 0)
        report['empty_xi_zero_bins_omitted'] += int(np.any(~keep))
        for method in methods:
            equal(final[method+'Nondimensional'], final[method] / np.array(P.refs)[:, None])
            equal(final[method+'Fraction'], final[method][:, 0] / final[method][:, 1])
        for coord, group, stage in [('y', 'ProfilesY', '04_y_approximation'), ('xi', 'ProfilesXi', '05_xi_approximation')]:
            table = rows(folder / f'results/{stage}/Y_profiles_{coord}_case_0906.csv')
            # Output.csv prints 12 significant figures; allow its rounding.
            equal([float(row['meanU_m_s']) for row in table], f[group+'/finished'][0], rtol=6e-12)
            report['checked_profile_csvs'] += 1
        for path in folder.glob('results/*/*summary*0906.txt'):
            text = path.read_text()
            for key in ('epsilon_I', 'eta_I'):
                match = re.search(rf'^{key} = (\S+)', text, re.M)
                assert match, (path, key)
                equal(float(match[1]), final[key], rtol=1e-10)
            assert int(re.search(r'common frames = (\d+)', text)[1]) == int(final['nFrames'])
            for method in methods:
                match = re.search(rf'{method} \[rows[^\n]+\n(\[\[.*?\]\])', text, re.S)
                assert match, (path, method)
                a = np.fromstring(match[1].replace('[', '').replace(']', ''), sep=' ').reshape(3, 2)
                equal(a, final[method], rtol=1e-10, atol=6e-13)
            report['checked_summary_texts'] += 1
        saved_json = json.loads((folder / 'results/06_final/Y_FINAL_case_summary_0906.json').read_text())
        for method in methods:
            equal(saved_json[method], final[method])
    report['cases'] += 1


for index, method in enumerate(methods, 1):
    stem = f'Y_flux_table_A{index}_{method}_0906'
    for suffix, delimiter, rtol in [('.csv', ',', 1e-12), ('.txt', '\t', 1e-7)]:
        table = rows(root / 'TABLES_0906' / (stem + suffix), delimiter)
        assert len(table) == 27
        assert {r['Data set'] for r in table} == set(data)
        for row in table:
            final = data[row['Data set']]
            for j, quantity in enumerate(quantities):
                for z, region in enumerate(('e', 'w')):
                    equal(float(row[f'{quantity}_{region}']), final[method][j, z], rtol=rtol)
                    equal(float(row[f'{quantity}_{region}_star']), final[method+'Nondimensional'][j, z], rtol=rtol)
                equal(float(row[f'{quantity}_contribution']), final[method+'Fraction'][j], rtol=rtol)
    report['tables'][f'A{index}'] = len(table)

for index, stem in [(4, 'Y_flux_table_A4_percentage_differences_0906'), (5, 'Y_flux_table_A5_contribution_comparison_0906')]:
    for suffix, delimiter, rtol in [('.csv', ',', 1e-12), ('.txt', '\t', 1e-7)]:
        table = rows(root / 'TABLES_0906' / (stem + suffix), delimiter)
        assert len(table) == 27 and {r['Data set'] for r in table} == set(data)
        for row in table:
            final = data[row['Data set']]
            for j, quantity in enumerate(quantities):
                if index == 4:
                    for prefix, method in [('xy', 'yBased'), ('xi', 'xiBased')]:
                        for z, region in enumerate(('e', 'w')):
                            a = final['actual'][j, z]
                            expected = 100 * (final[method][j, z] - a) / a if a else np.nan
                            equal(float(row[f'{prefix}_{quantity}_{region}']), expected, rtol=rtol)
                else:
                    a = final['actualFraction'][j]
                    equal(float(row[f'{quantity}_actual']), a, rtol=rtol)
                    for prefix, method in [('xy', 'yBased'), ('xi', 'xiBased')]:
                        difference = final[method+'Fraction'][j] - a
                        equal(float(row[f'{quantity}_{prefix}_minus_actual']), difference, rtol=rtol)
                        equal(float(row[f'{quantity}_{prefix}_minus_actual_percentage_points']), difference * 100, rtol=rtol)
    report['tables'][f'A{index}'] = len(table)

for path in sorted((root / 'TABLES_0906').glob('Y_flux_table_A*.tex')):
    tex = path.read_text()
    body = tex.split(r'\midrule', 1)[1].split(r'\bottomrule', 1)[0]
    lines = [line for line in body.splitlines() if ' & ' in line]
    assert len(lines) == 27, path
    source_rows = rows(path.with_suffix('.csv'))
    for line, row in zip(lines, source_rows):
        cells = line.rstrip().removesuffix(r'\\').split(' & ')
        assert cells[0] == row['Data set'].replace('_', r'\_')
        fields = [key for key in row if key != 'Data set' and not key.endswith('_percentage_points')]
        assert len(cells) == len(fields) + 1
        for cell, field in zip(cells[1:], fields):
            equal(float(cell) if cell.strip() != '--' else np.nan, float(row[field]), rtol=6e-5)
    assert r'\multicolumn{5}{c}{P_x}' not in tex, ('TeX math mode missing', path)
    assert tex.count(r'\begin{table}') == tex.count(r'\end{table}') == 1
    report['tables'][path.stem + '_tex_rows'] = 27

for line in (root / 'TABLES_0906/Y_TABLES_0906_manifest.txt').read_text().splitlines():
    assert (root / line).is_file(), line
assert len(rows(root / 'TABLES_0906/Y_flux_all_methods_0906.csv')) == 81
assert len(rows(root / 'TABLES_0906/Y_case_physics_summary_0906.csv')) == 27
assert len(rows(root / 'Y_all_cases_summary_0906.csv')) == 27
for path in (root / 'TABLES_0906').glob('Y_flux_table_A*.csv'):
    for row in rows(path):
        assert all(np.isfinite(float(value)) for key, value in row.items() if key != 'Data set'), path
report['all_five_table_cells_finite'] = True
combined_text = (root / 'TABLES_0906/Y_complete_flux_tables_A1_A5_0906.txt').read_text()
for path in (root / 'TABLES_0906').glob('Y_flux_table_A*.txt'):
    assert path.read_text().strip() in combined_text, path
from PIL import Image
groups = [(root / distance / 'ALL_CASES', 'Y_COMBINED') for distance in ('5D','10D','30D','40D')]
groups += [(root / 'BY_CASE' / name, 'Y_BY_CASE') for name in dict.fromkeys(c['name'] for c in cases(master))]
figure_pairs = [(folder / (prefix+'_'+name+'_'+coord+'_JFM_0906'))
                for folder, prefix in groups for coord in ('y', 'xi')
                for name in ('ubar','PE','Pwake','mass_flux_density','momentum_flux_density','kinetic_energy_flux_density')]
figure_pairs += [root / 'ALL27_HOLE_SIZE_PDF/Y_hole_size_PDF_all_cases_combined_0906']
for path in figure_pairs:
    with Image.open(path.with_suffix('.png')) as im: im.verify()
    pdf = path.with_suffix('.pdf')
    assert pdf.stat().st_size > 1000
    with pdf.open('rb') as stream: assert stream.read(5) == b'%PDF-'
report['checked_aggregate_png_pdf_pairs'] = len(figure_pairs)
assert json.loads((root / 'run_summary_0906.json').read_text())['state'] == 'ALL27_AGGREGATES_WRITTEN'
from datetime import datetime, timezone
report['run_id'] = root.name
report['output_root'] = str(root.resolve())
report['verified_utc'] = datetime.now(timezone.utc).isoformat()
report['manifest_check'] = 'DONE manifest hashes and current file sizes checked; combine previously SHA256-verified every case output before aggregation'
report['state'] = 'VERIFIED'
print(json.dumps(report, indent=2))
