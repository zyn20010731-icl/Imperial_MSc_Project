import unittest
from dataclasses import replace
from unittest.mock import patch

import numpy as np

from step3_y4h5 import pipeline
from step3_y4h5.config import P


class PivAreaCutoffTests(unittest.TestCase):
    def run_frame(self, hole_pixels=None, observed=None):
        # Unit PLIF spacing makes the exact 4-grid-cell boundary representable.
        physics = replace(P, pixels_per_m=1.0)
        holes = [np.array(v) for v in (
            [0, 1, 2], [8, 9, 10, 11], [16, 17, 18, 19, 20],
            [55, 56, 57], [48, 49, 50, 51], [40, 41, 42, 43, 44])]
        if hole_pixels is not None:
            holes = hole_pixels

        class Step2Fixture:
            shape = (8, 8)
            def cells(self, i, field):
                assert field == 'holePixelIdx'
                return [a + 1 for a in holes]

        ids = np.arange(64) if observed is None else np.asarray(observed)
        labels = np.ones(64, np.uint8)
        labels[63] = 2
        u = np.linspace(.2, 1.2, len(ids))
        v = np.full(len(ids), .3)
        u[ids == 10] = np.nan
        dp = labels[ids] != 2
        dv = dp & np.isfinite(u) & np.isfinite(v)
        b = dict(i=0, frame=100, status='success', mids=np.array([[1., 1.]]),
                 label=labels, dp=dp, dv=dv, mu=u, mv=v)
        context = dict(st=Step2Fixture(), ids=ids,
                       rc=np.column_stack((ids % 8 + 1, ids // 8 + 1)),
                       yb=np.zeros(len(ids), np.int64),
                       x=np.array([0., 1.]), y=np.array([1., 0.]))
        with patch.object(pipeline, 'CTX', context), patch.object(pipeline, 'P', physics), patch.object(pipeline, 'basic', return_value=b):
            result = pipeline.analyse_frame((0, 3/18))
        np.testing.assert_array_equal(labels, np.r_[np.ones(63, np.uint8), 2])
        return result, physics, ids, u, v, dp, dv

    def test_strict_area_boundary_and_both_classes(self):
        result, *_ = self.run_frame()
        self.assertEqual([h['holeIndex'] for h in result['holes']], [2, 3, 5, 6])
        self.assertEqual([h['classification'] for h in result['holes']],
                         ['engulfed', 'engulfed', 'internal', 'internal'])
        np.testing.assert_array_equal(result['counts'], [[2, 2], [2, 2]])
        for hole in result['holes']:
            self.assertEqual(hole['minimumResolvedHoleArea_m2'], 4)
            self.assertTrue(hole['passesPivResolutionCutoff'])

    def test_filtered_pixels_remain_wake_and_probability_samples(self):
        result, physics, ids, u, v, dp, dv = self.run_frame()
        factor = 2*physics.rho*physics.delta**2/physics.length
        e = np.isin(ids, [8, 9, 10, 11, 16, 17, 18, 19, 20]) & dv
        for column, mask in ((0, e), (1, dv)):
            expected = factor*np.array([u[mask].sum(), (u[mask]**2).sum(),
                                        (.5*(u[mask]**2+v[mask]**2)*u[mask]).sum()])
            np.testing.assert_allclose(result['actual'][:, column], expected)
        for coordinate in ('y', 'xi'):
            sums = result[coordinate][1].sum(axis=1)
            self.assertEqual(sums[3], dv.sum())
            self.assertEqual(sums[4], dp.sum())
            self.assertEqual(sums[5], 9)  # Missing velocity still counts in P.
            self.assertEqual(sums[6], dp.sum())

    def test_frame_with_only_small_holes_remains_valid(self):
        result, *_ = self.run_frame([np.array([0, 1, 2]), np.array([55, 56, 57])])
        self.assertEqual(result['status'], 'success')
        self.assertEqual(result['holes'], [])
        np.testing.assert_array_equal(result['counts'], 0)
        np.testing.assert_array_equal(result['actual'][:, 0], 0)
        self.assertTrue(np.all(result['actual'][:, 1] > 0))

    def test_area_uses_full_hole_before_piv_crop(self):
        result, *_ = self.run_frame([np.array([8, 9, 10, 11])], observed=[8, 9, 30, 31])
        self.assertEqual(len(result['holes']), 1)
        self.assertEqual(result['holes'][0]['area_px'], 4)
        self.assertEqual(result['holes'][0]['nPixelsInPositivePivDomain'], 2)


if __name__ == '__main__':
    unittest.main()
