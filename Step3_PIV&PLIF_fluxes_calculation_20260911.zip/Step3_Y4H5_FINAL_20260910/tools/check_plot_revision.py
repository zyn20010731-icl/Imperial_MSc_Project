"""Compare final plotting entry points with the executed v4 source snapshot."""
from pathlib import Path
import json
import sys
import tempfile
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import numpy as np
from step3_y4h5 import plotting as new, combine as new_group
from provenance.verified_v4_modules import plotting as old, combine as old_group


class OutputStub:
    def path(self, name):
        return Path(name)
    def csv(self, *args):
        pass


def snapshot(module, call):
    captured = {}
    def save(fig, path):
        captured[str(path)] = [dict(xlim=ax.get_xlim(), ylim=ax.get_ylim(),
            xlabel=ax.get_xlabel(), ylabel=ax.get_ylabel(), title=ax.get_title(),
            lines=[(line.get_xdata().copy(),line.get_ydata().copy(),line.get_color(),line.get_linestyle())
                   for line in ax.lines]) for ax in fig.axes]
        new.plt.close(fig)
    with patch.object(module, 'save', save):
        call()
    return captured


def compare(a, b):
    assert a.keys() == b.keys()
    for key in a:
        for aa, bb in zip(a[key], b[key], strict=True):
            expected = (-300., 300.) if 'ubar_xi' in key else aa['xlim']
            assert bb['xlim'] == expected, key
            for field in ('ylim','xlabel','ylabel','title'):
                assert aa[field] == bb[field], (key,field)
            for la, lb in zip(aa['lines'],bb['lines'],strict=True):
                np.testing.assert_array_equal(la[0],lb[0])
                np.testing.assert_array_equal(la[1],lb[1])
                assert la[2:] == lb[2:]


def main():
    bins=np.arange(-4,5)
    sums=np.ones((7,len(bins)));sums[:,bins==0]=0
    values=np.vstack([np.linspace(.4,.2,len(bins)),np.ones(len(bins))*.2,
                      np.ones(len(bins))*.04,np.ones(len(bins))*.1,np.ones(len(bins))])
    values[:,bins==0]=0
    p=dict(coordinate_m=bins*.001,bins=bins,sums=sums,finished=values,
           density=np.ones((3,2,len(bins))))
    count=0
    for coord in ('y','xi'):
        a=snapshot(old,lambda:old.profiles_plot(OutputStub(),p,coord,1e-4,''))
        b=snapshot(new,lambda:new.profiles_plot(OutputStub(),p,coord,1e-4,''))
        compare(a,b);count+=len(a)
    with tempfile.TemporaryDirectory() as temp:
        folder=Path(temp)
        for coord,stage in [('y','04_y_approximation'),('xi','05_xi_approximation')]:
            path=folder/'results'/stage/f'Y_profiles_{coord}_case_0906.csv'
            path.parent.mkdir(parents=True)
            path.write_text('coordinate,meanU\n0,0.3\n')
        items=[dict(folder=folder,case=dict(name=name,source=name,distance='5D'),
                    data=dict(ProfilesY=p,ProfilesXi=p,Final=dict(eta_I=1e-4)))
               for name in ('NoGrid','SFG312_SC11d')]
        for grouping in ('case','distance'):
            a=snapshot(old_group,lambda:old_group.group_plots(OutputStub(),items,'Y_COMBINED',grouping))
            b=snapshot(new_group,lambda:new_group.group_plots(OutputStub(),items,'Y_COMBINED',grouping))
            compare(a,b);count+=len(a)
    print(json.dumps(dict(state='PASSED',figureComparisons=count,
                         curveValuesAndOtherFigureSettingsUnchanged=True,
                         xiVelocityLimits=[-300,300])))


if __name__=='__main__':
    main()
