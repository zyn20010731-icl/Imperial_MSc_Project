from pathlib import Path
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor
from dataclasses import asdict
import multiprocessing as mp
import json, time, os, traceback, pickle
import numpy as np
import h5py, netCDF4
from scipy.spatial import cKDTree
from .config import P,TAG,fingerprint
from .storage import Output,sha
from .mat_io import Step2
from .mapping import Calibration
from .numerics import filter_velocity,gradients,kernels,eta_from_terms,xi_bins,contributions,finish

CTX={}
def array(a):return np.asarray(np.ma.filled(a,np.nan),dtype=float)
def worker_init(master,case,cache,mapfile):
    global CTX
    st=Step2(case['mat']);cache=h5py.File(cache,'r')
    x=cache['x'][()];y=cache['y'][()]
    cal=Calibration(master,x,y,st.shape)
    saved=np.load(mapfile)
    from .mapping import Map
    m=Map(*(saved[k] for k in ('valid','source','corners','weights','x','y')))
    CTX=dict(st=st,cache=cache,cal=cal,m=m,ids=saved['ids'],rc=saved['rc'],yb=saved['yb'],
             meanu=cache['meanU'][()],meanv=cache['meanV'][()],x=x[0],y=y[:,0])

def basic(i,eta_only=False):
    c=CTX;s=c['st'];frame=int(s.frames[i]);idx=(frame-100)//2
    mids=s.interface(i)
    if not mids.size:return dict(i=i,frame=frame,status='excluded',reason='no_interface')
    wake=s.pixels(i,'wakePixelIdx');bad=s.pixels(i,'invalidPixelIdx');unknown=s.pixels(i,'unknownPixelIdx')
    total=np.prod(s.shape);label=np.zeros(total,np.uint8);label[wake]=1
    label[bad]=2;label[unknown]=2
    u=c['cache']['U'][idx];v=c['cache']['V'][idx]
    lab=label[c['ids']];dp=lab!=2
    if eta_only and np.isfinite(u).all() and np.isfinite(v).all():
        mu=mv=None;dv=dp
    else:
        mu=c['m'].sample(u);mv=c['m'].sample(v);dv=dp&np.isfinite(mu)&np.isfinite(mv)
    reason='no_wake' if len(wake)==0 else 'no_valid_velocity' if not dv.any() else 'no_observable_wake' if not ((lab==1)&dv).any() else ''
    if reason:return dict(i=i,frame=frame,status='excluded',reason=reason)
    return dict(i=i,frame=frame,status='success',mids=mids,label=label,dp=dp,dv=dv,u=u,v=v,mu=mu,mv=mv)

def eta_frame(i):
    b=basic(i,eta_only=True)
    if b['status']!='success':return b
    c=CTX;g=gradients(b['u']-c['meanu'],b['v']-c['meanv'],c['x'],c['y'])
    m=c['cal'].map(b['mids']);a=np.stack([m.sample(v) for v in g]);valid=np.isfinite(a).all(0)
    return dict(i=i,frame=b['frame'],status='success',reason='',terms=np.square(a[:,valid]).sum(1),count=int(valid.sum()),nInterface=len(b['mids']))

def analyse_frame(arg):
    i,eta=arg;b=basic(i)
    if b['status']!='success':return b
    c=CTX;s=c['st'];nr,nc=s.shape
    tree=cKDTree(b['mids']);holepix=s.cells(i,'holePixelIdx')
    rows=[];E=np.zeros(nr*nc,bool);resolution=4*float(np.median(np.diff(c['x'])))*float(np.median(np.abs(np.diff(c['y']))))
    # O(N) lookup allows per-hole sums without scanning the FoV for each hole.
    lookup=np.full(nr*nc,-1,np.int32);lookup[c['ids']]=np.arange(len(c['ids']),dtype=np.int32)
    kval=kernels(b['mu'],b['mv']);kval[:,~b['dv']]=0
    for j,a in enumerate(holepix):
        ids=a.ravel().astype(np.int64)-1
        if ids.size==0:raise ValueError('Empty formal hole')
        area=len(ids)*P.delta**2
        # Filter complete Step2 holes before classification, counts and PDFs.
        # Their pixels remain in the untouched Step2 wake/probability domain.
        if area<resolution:continue
        rr=ids%nr+1;cc=ids//nr+1
        centroid=(rr.mean(),cc.mean());dist=float(tree.query(centroid)[0])*P.delta
        eng=dist<=18*eta
        resolved=True
        if eng:E[ids]=True
        loc=lookup[ids];loc=loc[loc>=0];loc=loc[b['dv'][loc]]
        raw=P.rho*P.delta**2*kval[:,loc].sum(1)
        rows.append(dict(plifFrameNo=b['frame'],pivFrameID=(b['frame']-98)//2,holeIndex=j+1,
          centroidX_px=centroid[0],centroidY_px=centroid[1],distanceToInterface_m=dist,distanceToInterface_normalisedByEta=dist/eta,
          isEngulfed=eng,classification='engulfed' if eng else 'internal',area_px=len(ids),area_m2=area,area_mm2=area*1e6,
          area_over_d2=area/P.d**2,characteristicSize_m=np.sqrt(area),characteristicSize_mm=np.sqrt(area)*1000,
          characteristicSize_normalisedByEta=np.sqrt(area)/eta,streamwiseExtent_px=int(np.ptp(rr)+1),crossStreamExtent_px=int(np.ptp(cc)+1),
          aspectRatio_streamwiseToCrossStream=float((np.ptp(rr)+1)/(np.ptp(cc)+1)),touchesPlifImageBoundary=bool(((rr==1)|(rr==nr)|(cc==1)|(cc==nc)).any()),
          minimumResolvedHoleArea_m2=resolution,passesPivResolutionCutoff=resolved,nPixelsInPositivePivDomain=len(loc),
          observedArea_m2=len(loc)*P.delta**2,rawMassFlux_kg_s=raw[0],rawStreamwiseMomentumFlux_N=raw[1],rawKineticEnergyFlux_W=raw[2]))
    dp=b['dp'];dv=b['dv'];eng=E[c['ids']];wake=b['label'][c['ids']]==1
    if np.any(eng&~wake):raise ValueError('Engulfed not a subset of wake')
    actual=2*P.rho*P.delta**2/P.length*np.stack([kval[:,eng&dv].sum(1),kval[:,wake&dv].sum(1)],axis=1)
    dist=tree.query(c['rc'][dp],workers=1)[0]
    xb=xi_bins(dist,wake[dp]);yb=c['yb'][dp]
    yc=contributions(yb,b['mu'][dp],b['mv'][dp],eng[dp],wake[dp]);xc=contributions(xb,b['mu'][dp],b['mv'][dp],eng[dp],wake[dp])
    counts=np.array([[sum(r['isEngulfed']==e for r in rows) for e in (True,False)],
                     [sum(r['isEngulfed']==e and r['passesPivResolutionCutoff'] for r in rows) for e in (True,False)]],dtype=np.int64)
    return dict(i=i,frame=b['frame'],status='success',reason='',holes=rows,actual=actual,y=yc,xi=xc,counts=counts,
                observed_area=float((b['label']!=2).sum()*P.delta**2),nv=int(dv.sum()),np=int(dp.sum()),xi_max=float(dist[wake[dp]].max()*P.delta))

def prepare(master,case,out,workers):
    with netCDF4.Dataset(case['piv'],'r') as nc:
        names=('vel_xFulls','vel_yFulls') if 'vel_xFulls' in nc.variables else ('velxFulls','velyFulls')
        x=array(nc['gridxFull'][:]);y=array(nc['gridyFull'][:]);nt,ny,nx=nc[names[0]].shape
        if nt!=2501:raise ValueError('Expected complete 2501-frame PIV sequence')
        if not (np.allclose(x,x[0][None,:],rtol=0,atol=1e-10) and np.allclose(y,y[:,0][:,None],rtol=0,atol=1e-10)):
            raise ValueError('PIV coordinates are not rectilinear')
        if not (np.all(np.diff(x[0])>0) and np.all(np.diff(y[:,0])<0)):raise ValueError('Unexpected PIV axis order')
        st=Step2(case['mat']);cal=Calibration(master,x,y,st.shape);ids,rc,m=cal.fixed()
        out.log(f'mapping points={len(ids)} cameras={np.bincount(m.source).tolist()}')
        mapfile=out.path('_shared/map.npz')
        np.savez(mapfile,ids=ids,rc=rc,yb=np.floor(m.y/P.delta).astype(np.int64),**{k:getattr(m,k) for k in ('valid','source','corners','weights','x','y')})
        out.h5('_shared/Y_PLIF_TO_PIV_BILINEAR_MAP_0906.h5',dict(plifIndex0=ids,rc=rc,**{k:getattr(m,k) for k in ('valid','source','corners','weights','x','y')}))
        cache=out.path('_shared/Y_FILTERED_VELOCITY_CACHE_0906.h5');tmp=cache.with_suffix('.tmp')
        sums=np.zeros((2,ny,nx));counts=np.zeros((2,ny,nx),np.uint64)
        with h5py.File(tmp,'w') as f, ThreadPoolExecutor(max_workers=workers) as pool:
            f['x']=x;f['y']=y
            U=f.create_dataset('U',shape=(nt,ny,nx),dtype='f8',chunks=(1,ny,nx))
            V=f.create_dataset('V',shape=(nt,ny,nx),dtype='f8',chunks=(1,ny,nx))
            for start in range(0,nt,32):
                end=min(start+32,nt);data=[array(nc[n][start:end]) for n in names]
                for component,dataset in enumerate((U,V)):
                    batch=np.stack(list(pool.map(filter_velocity,data[component])))
                    dataset[start:end]=batch;finite=np.isfinite(batch)
                    sums[component]+=np.where(finite,batch,0).sum(0);counts[component]+=finite.sum(0).astype(np.uint64)
                if start%256==0:out.log(f'preprocess {end}/{nt}')
            mean=np.divide(sums,counts,out=np.full_like(sums,np.nan),where=counts>0)
            f['meanU']=mean[0];f['meanV']=mean[1]
        os.replace(tmp,cache)
        out.h5('_shared/Y_MEAN_VELOCITY_0906.h5',dict(Ubar=mean[0],Vbar=mean[1],counts=counts,x=x,y=y))
        frames=st.frames.copy();st.close()
    return str(cache),str(mapfile),frames

def merge_contributions(items,key):
    lo=min(r[key][0] for r in items);hi=max(r[key][0]+r[key][1].shape[1] for r in items)
    total=np.zeros((7,hi-lo));framecounts=np.zeros((len(items),hi-lo),dtype=np.uint64)
    for i,r in enumerate(items):
        offset,a=r[key];start=offset-lo;total[:,start:start+a.shape[1]]+=a
        framecounts[i,start:start+a.shape[1]]=a[4].astype(np.uint64)
    # y represents all strips from the physical origin, including missing leading bins.
    if key=='y' and lo>0:
        total=np.pad(total,((0,0),(lo,0)));framecounts=np.pad(framecounts,((0,0),(lo,0)));lo=0
    return np.arange(lo,lo+total.shape[1]),total,framecounts

def run(master,case,runid,workers=4,limit=None):
    root=Path(master)/'06_OUTPUTS_Y4H5'/runid/case['distance']/case['name'];out=Output(root,master)
    if out.path('Step3_Y4H5_DONE_0906.txt').exists():raise ValueError('Case already complete; use validation/replot, not overwrite')
    source=[Path(__file__).parent/n for n in (
        'config.py','mat_io.py','mapping.py','numerics.py','pipeline.py',
        'plotting.py','four_panel.py','diagnostics.py','reporting.py','table_reports.py'
    )]
    inputpaths=[case['mat'],case['piv'],case['done']]+[str(Path(master)/f'02_INPUTS/SPATIAL_CALIBRATION/tform_{cam}_to_PLIF_matrix.mat') for cam in ('normal','tilted')]
    identity=fingerprint(inputpaths,dict(code={p.name:sha(p) for p in source},limit=limit,case=case))
    old=out.path('runtime/identity.json')
    if old.exists() and json.loads(old.read_text())['fingerprint']!=identity['fingerprint']:raise ValueError('Run identity changed; use a new run ID')
    out.json('runtime/identity.json',identity);out.log(f'start {case["distance"]}/{case["name"]} workers={workers} limit={limit}')
    t=time.monotonic()
    try:
        cache=str(out.path('_shared/Y_FILTERED_VELOCITY_CACHE_0906.h5'));mapfile=str(out.path('_shared/map.npz'))
        if Path(cache).exists() and Path(mapfile).exists():
            st=Step2(case['mat']);frames=st.frames.copy();st.close();out.log('resume complete preprocessing cache')
        else:cache,mapfile,frames=prepare(master,case,out,workers)
        selection=list(range(len(frames))) if limit is None else list(range(min(limit,len(frames))))
        with ProcessPoolExecutor(max_workers=workers,mp_context=mp.get_context('spawn'),initializer=worker_init,initargs=(str(master),case,cache,mapfile)) as pool:
            terms=[];pending=[]
            for i in selection:
                ck=out.path(f'_work/eta/{i:04d}.pkl')
                if ck.exists():
                    with ck.open('rb') as f:terms.append(pickle.load(f))
                else:pending.append(i)
            for r in pool.map(eta_frame,pending,chunksize=8):
                ck=out.path(f'_work/eta/{r["i"]:04d}.pkl');tmp=ck.with_suffix('.tmp')
                with tmp.open('wb') as f:pickle.dump(r,f,protocol=5)
                os.replace(tmp,ck);terms.append(r)
                if len(terms)%100==0:out.log(f'eta {len(terms)}/{len(selection)}')
            good=[r for r in terms if r['status']=='success'];count=sum(r['count'] for r in good)
            eps,eta,means=eta_from_terms(np.sum([r['terms'] for r in good],axis=0),count)
            out.log(f'pooled epsilon={eps:.8g} eta_mm={eta*1000:.8g} samples={count}')
            out.h5('results/01_eta/Y_eta_case_0906.h5',dict(Final=dict(epsilon_I=eps,eta_I=eta,meanGradientSquares=means,totalCount=count),frames=frames[selection]))
            out.csv('results/01_eta/Y_eta_frame_terms_0906.csv',[dict(plifFrameNo=r['frame'],pivFrameID=(r['frame']-98)//2,status=r['status'],failureReason=r.get('reason',''),nValidMicroElements=r.get('count',0),**dict(zip(('sumDuDx2','sumDuDy2','sumDvDx2','sumDvDy2'),r.get('terms',[np.nan]*4)))) for r in terms])
            results=[];pending=[]
            for g in good:
                ck=out.path(f'_work/flux/{g["i"]:04d}.pkl')
                if ck.exists():
                    with ck.open('rb') as f:results.append(pickle.load(f))
                else:pending.append((g['i'],eta))
            for r in pool.map(analyse_frame,pending,chunksize=4):
                ck=out.path(f'_work/flux/{r["i"]:04d}.pkl');tmp=ck.with_suffix('.tmp')
                with tmp.open('wb') as f:pickle.dump(r,f,protocol=5)
                os.replace(tmp,ck);results.append(r)
                if len(results)%100==0:out.log(f'flux/profiles {len(results)}/{len(good)}')
        results=sorted([r for r in results if r['status']=='success'],key=lambda r:r['i'])
        if not results:raise ValueError('No common valid flux frames')
        actual=np.stack([r['actual'] for r in results]);profiles={};q={};xi_frames=None
        for key in ('y','xi'):
            bins,sums,counts=merge_contributions(results,key);profiles[key]=finish(bins,sums,key)
            J=profiles[key]['density']
            if key=='y':q[key]=2*P.delta*J.sum(2)
            else:
                xi_frames = 2 * P.delta**2 / P.length * np.einsum(
                    'fj,msj->fms', counts, J
                )
                q[key] = xi_frames.mean(0)
            out.h5(f'_work/{key}_contributions.h5',dict(frames=[r['frame'] for r in results],bins=bins,sums=sums,pixelCounts=counts))
        final=dict(epsilon_I=eps,eta_I=eta,actual=actual.mean(0),yBased=q['y'],xiBased=q['xi'],nFrames=len(results),xiMax_m=max(r['xi_max'] for r in results))
        for method in ('actual','yBased','xiBased'):
            v=final[method];final[method+'Nondimensional']=v/np.asarray(P.refs)[:,None]
            final[method+'Fraction']=np.divide(v[:,0],v[:,1],out=np.full(3,np.nan),where=v[:,1]!=0)
        holes=[h for r in results for h in r['holes']]
        out.csv('results/02_holes/Y_holes_detailed_case_0906.csv',holes)
        out.h5('results/06_final/Y_FINAL_case_0906.h5',dict(Final=final,ProfilesY=profiles['y'],ProfilesXi=profiles['xi'],ActualFrames=actual,frames=[r['frame'] for r in results],Parameters=asdict(P)))
        out.json('results/06_final/Y_FINAL_case_summary_0906.json',final)
        from .reporting import report,frame_row
        from .diagnostics import diagnostic
        stats=report(out,case,final,profiles,results)
        out.csv('results/05_xi_approximation/Y_xi_fluxes_by_frame_case_0906.csv',[frame_row(r['frame'],q) for r,q in zip(results,xi_frames)])
        diagnostic(out,master,case,results,eta)
        out.h5('results/06_final/Y_FINAL_case_0906.h5',dict(Final=final,ProfilesY=profiles['y'],ProfilesXi=profiles['xi'],ActualFrames=actual,XiFrames=xi_frames,frames=[r['frame'] for r in results],HoleCountStatistics=stats,Parameters=asdict(P)))
        after=fingerprint(inputpaths,identity['extra'])
        if after['inputs']!=identity['inputs']:raise RuntimeError('Input metadata changed during run')
        # Final DONE is emitted only after separate output validation.

        out.json('runtime/status_0906.json',dict(state='OUTPUTS_READY_FOR_VALIDATION',elapsed=time.monotonic()-t,frames=len(results),pilot=limit is not None))
        out.log(f'outputs ready elapsed={time.monotonic()-t:.1f}s; output/plot validation still required')
        return out,final,profiles,results
    except Exception:
        out.json('runtime/status_0906.json',dict(state='FAILED',error=traceback.format_exc()))
        out.path('runtime/errors_0906.log').write_text(traceback.format_exc());raise
