"""Read existing Step2 classifications and cached PIV for diagnostic figures."""
from pathlib import Path

import h5py
import numpy as np
from PIL import Image

from .config import P
from .four_panel import boundary_segments, make_geometry, render_four_panel
from .mapping import Calibration
from .mat_io import Step2


def _join_pairs(cells):
    parts = [np.asarray(a).reshape(-1, 4) for a in cells if a.size]
    return np.concatenate(parts) if parts else np.empty((0, 4), np.uint32)


def diagnostic(out, master, case, results, eta):
    """Use cached filtered instantaneous U/V; never reclassify any holes."""
    st = Step2(case['mat'])
    by_frame = {int(frame): i for i, frame in enumerate(st.frames)}
    snapshots = {}
    try:
        with h5py.File(out.path('_shared/Y_FILTERED_VELOCITY_CACHE_0906.h5'), 'r') as cache:
            X, Y = cache['x'][()], cache['y'][()]
            resolution = 4*float(np.median(np.diff(X[0])))*float(np.median(np.abs(np.diff(Y[:, 0]))))
            cal = Calibration(master, X, Y, st.shape)
            geometry = make_geometry(cal)
            for result in results:
                frame = int(result['frame'])
                if (frame-100) % 200:
                    continue
                i = by_frame[frame]
                filename = st.field(i, 'frameName')
                source = Path(str(st.meta['plifDir'])) / filename
                if not source.is_file():
                    source = Path(master) / '02_INPUTS/PLIF' / case['distance'] / case['source'] / filename
                with Image.open(source) as im:
                    raw = np.asarray(im).copy()
                if raw.shape != st.shape:
                    raise ValueError('Unexpected diagnostic TIFF shape')
                bg = np.asarray(st.meta['B_profile_even']).ravel()
                norm = np.asarray(st.meta['Phi_ref_even_forNorm']).ravel()
                phi = np.maximum(raw.astype(float)-bg[:, None], 0) / np.maximum(norm[:, None], 1e-12)
                hole_cells = st.cells(i, 'holeBoundaryRC')
                hole_pixels = st.cells(i, 'holePixelIdx')
                holes = {int(h['holeIndex']): h for h in result['holes']}
                expected = {j for j, a in enumerate(hole_pixels, 1) if a.size*P.delta**2 >= resolution}
                if len(hole_cells) != len(hole_pixels) or len(holes) != len(result['holes']) or set(holes) != expected:
                    raise ValueError('Saved hole classification identities do not match Step2')
                boundaries = {
                    'interface': _join_pairs(st.cells(i, 'interfaceRC')),
                    'unknown': _join_pairs(st.cells(i, 'unknownBoundaryRC')),
                }
                for kind, flag in (('engulfed', True), ('internal', False)):
                    boundaries[kind] = _join_pairs([
                        a for j, a in enumerate(hole_cells, 1)
                        if j in holes and bool(holes[j]['isEngulfed']) == flag
                    ])
                piv_index = (frame-100)//2
                u, v = cache['U'][piv_index], cache['V'][piv_index]
                filename = f'Y_4panel_PLIF_{frame:04d}_PIV_{piv_index+1:04d}_0906.png'
                snapshots[str(frame)] = render_four_panel(
                    raw, phi, u, v, X, Y, boundaries, cal, eta, frame,
                    case['distance']+' / '+case['name'],
                    out.path('results/06_final/diagnostic_4panel/'+filename),
                    geometry=geometry, dpi=350,
                )
                out.log(f'diagnostic PLIF={frame}')
            out.h5('results/06_final/Y_stage4_diagnostics_case_0906.h5',
                   dict(DiagnosticResults=snapshots, X=X, Y=Y))
    finally:
        st.close()
