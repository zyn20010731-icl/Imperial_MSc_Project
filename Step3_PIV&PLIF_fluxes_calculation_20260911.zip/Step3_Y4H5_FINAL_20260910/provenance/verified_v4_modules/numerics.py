import numpy as np
from scipy.ndimage import median_filter, generic_filter
from .config import P

def filter_velocity(a):
    a=np.asarray(a,dtype=np.float64)
    if np.isfinite(a).all():return median_filter(a,size=3,mode='nearest')
    good=np.isfinite(a); b=np.where(good,a,np.nan)
    def finite_median(x):
        x=x[np.isfinite(x)];return np.median(x) if len(x) else np.nan
    b=generic_filter(b,finite_median,size=3,mode='nearest');b[~good]=np.nan
    return b

def gradients(u,v,x,y):
    du_dy,du_dx=np.gradient(u,y,x,edge_order=1)
    dv_dy,dv_dx=np.gradient(v,y,x,edge_order=1)
    return np.stack((du_dx,du_dy,dv_dx,dv_dy))

def kernels(u,v):return np.stack((u,u*u,.5*(u*u+v*v)*u))

def eta_from_terms(sums,count):
    if count<=0:raise ValueError('No jointly valid interface gradients')
    means=np.asarray(sums)/count
    eps=P.nu*np.dot([-1,2,2,8],means)
    if not np.isfinite(eps) or eps<=0:raise ValueError(f'Nonpositive pooled epsilon: {eps}')
    return eps,(P.nu**3/eps)**.25,means

def xi_bins(distance,wake):
    # Exact zero reserved; signed bins have edges at integer pixel distances.
    b=np.ceil(distance).astype(np.int64)
    return np.where(wake,b,-b)

def contributions(bins,u,v,engulf,wake):
    lo=int(bins.min());hi=int(bins.max());b=bins-lo;n=hi-lo+1
    sums=np.zeros((7,n),dtype=np.float64)
    valid=np.isfinite(u)&np.isfinite(v)
    for j,a in enumerate(kernels(u[valid],v[valid])):sums[j]=np.bincount(b[valid],weights=a,minlength=n)
    sums[3]=np.bincount(b[valid],minlength=n)
    sums[4]=np.bincount(b,minlength=n)
    sums[5]=np.bincount(b[engulf],minlength=n)
    sums[6]=np.bincount(b[wake],minlength=n)
    return lo,sums

def fill_profile(x,a,probability=False):
    good=np.isfinite(a);n=int(good.sum())
    if n==0:raise ValueError('No samples in profile support')
    xx=x[good];yy=a[good];out=np.interp(x,xx,yy)
    if not probability and n>1:
        k=min(5,n)
        for edge,sl in [(x<xx[0],slice(0,k)),(x>xx[-1],slice(-k,None))]:
            xp=xx[sl];yp=yy[sl];xc=xp.mean()
            slope=np.dot(xp-xc,yp-yp.mean())/np.dot(xp-xc,xp-xc)
            out[edge]=yp.mean()+slope*(x[edge]-xc)
    return np.clip(out,0,1) if probability else out

def finish(bins,sums,coordinate):
    x=(bins+.5)*P.delta if coordinate=='y' else np.sign(bins)*(np.abs(bins)-.5)*P.delta
    x[bins==0]=P.delta/2 if coordinate=='y' else 0.
    with np.errstate(invalid='ignore',divide='ignore'):
        raw=np.vstack((sums[:3]/sums[3],sums[5:7]/sums[4]))
    out=np.full_like(raw,np.nan)
    regions=[np.ones(len(x),bool)] if coordinate=='y' else [bins<0,bins>0]
    for region in regions:
        if not region.any():continue
        for j in range(5):
            if coordinate=='xi' and j>=3:
                out[j,region]=0 if (bins[region]<0).all() else (1 if j==4 else fill_profile(x[region],raw[j,region],True))
            else:out[j,region]=fill_profile(x[region],raw[j,region],j>=3)
    if coordinate=='xi' and (bins==0).any():
        z=bins==0
        if sums[4,z].sum():
            if not np.isfinite(raw[:3,z]).all():raise ValueError('Observed zero xi bin lacks velocity')
            out[:,z]=raw[:,z];out[4,z]=1
        else:
            # Keep the empty zero bin out of the plotted velocity profile.
            # Its numerical weight remains zero; plotting code omits this
            # synthetic point and connects the nearest valid bins smoothly.
            out[:,z]=0
    out[1]=np.maximum(out[1],out[0]**2)
    out[3]=np.minimum(np.clip(out[3],0,1),out[4])
    density=P.rho*out[:3,None,:]*out[None,3:5,:]
    return dict(bins=bins,coordinate_m=x,sums=sums,raw=raw,finished=out,density=density,filled=~np.isfinite(raw),modified=np.isfinite(raw)&(out!=raw))
