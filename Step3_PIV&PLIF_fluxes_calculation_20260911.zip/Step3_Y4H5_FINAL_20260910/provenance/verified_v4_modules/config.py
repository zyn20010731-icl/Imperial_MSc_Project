from dataclasses import dataclass, asdict
from pathlib import Path
import csv, hashlib, json

@dataclass(frozen=True)
class Physics:
    rho: float = 1000.
    nu: float = 1e-6
    d: float = .010
    uinf: float = .38
    pixels_per_m: float = 23920.
    length: float = .030
    symmetry: float = 2.
    eta_multiplier: float = 18.
    @property
    def delta(self): return 1/self.pixels_per_m
    @property
    def refs(self): return (self.rho*self.uinf*self.d, self.rho*self.uinf**2*self.d, .5*self.rho*self.uinf**3*self.d)
P = Physics()
TAG = '0906'

def cases(master):
    result=[]
    with (Path(master)/'01_CODE/Step2_PLIF_interface_2.0/cases_28.csv').open() as f:
        for row in csv.DictReader(f):
            dist,src=row['Distance'],row['CaseName']
            if (dist,src)==('40D','SRG111_SC39d'): continue
            # Step2 was rerun with the revised threshold for every 5D case.
            # Keep the other distances tied to the authoritative case list.
            phi=0.500 if dist=='5D' else float(row['PhiThEven'])
            tag=f"phi{int(phi*1000+.5):04d}"
            canonical='SFG312_SC237d' if src=='SFG312_SC237' else src
            base=Path(master)/'05_OUTPUTS'/dist/src/f'Y_interface_detection_method1_even_{tag}_final_0905'
            result.append(dict(index=len(result)+1, distance=dist, source=src, name=canonical, phi=phi, phiTag=tag,
                mat=str(base/f'interface_holes_{dist}_{src}_{tag}_0905.mat'),
                done=str(base/'Step2_PLIF_interface_2.0_DONE_0905.txt'),
                piv=str(Path(master)/'02_INPUTS/STITCHED_PIV'/dist/src/'stitched_PIV.nc')))
    if len(result)!=27: raise ValueError(f'Expected 27 cases, found {len(result)}')
    return result

def fingerprint(paths, extra):
    entries=[]
    for path in paths:
        p=Path(path).resolve(strict=True); st=p.stat()
        entries.append(dict(path=str(p),size=st.st_size,mtime_ns=st.st_mtime_ns))
    data=dict(inputs=entries,physics=asdict(P),extra=extra)
    data['fingerprint']=hashlib.sha256(json.dumps(data,sort_keys=True).encode()).hexdigest()
    return data
