"""Redraw only xi mean-velocity figures from verified Step3 results, on HPC."""
import hashlib
import json
import os
from datetime import datetime, timezone
from pathlib import Path
import sys

os.environ.setdefault('MPLBACKEND', 'Agg')
os.environ.setdefault('PYTHONDONTWRITEBYTECODE', '1')

MASTER = Path.home() / 'MSc_Project/MSc_2026_final'
SOURCE_CODE = MASTER / '01_CODE/Step3_Y4H5_piv4_restore_0909_v1'
RUN_ID = 'run_20260909_formal_v4_piv4_restore'
ROOT = MASTER / '06_OUTPUTS_Y4H5' / RUN_ID
CONTROL = ROOT / '_control/xi_ubar_pm300_0910'
MANIFEST = 'Y_XI_UBAR_PM300_0910_manifest.json'
DISTANCES = ('5D', '10D', '30D', '40D')
CASE_NAMES = ('NoGrid', 'SFG312_SC11d', 'SFG312_SC237d', 'SFG354_SC15d',
              'SRG38_SC20d', 'SRG111_SC22d', 'SRG111_SC39d')
XLIM = (-300., 300.)

sys.path.insert(0, str(SOURCE_CODE))
import h5py
import numpy as np
from PIL import Image
from step3_y4h5.plotting import BLUE, COLORS, plt, save, style


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def write_json(path, value):
    tmp = path.with_name(path.name + '.tmp')
    tmp.write_text(json.dumps(value, indent=2) + '\n')
    tmp.replace(path)


def main():
    CONTROL.mkdir(parents=True, exist_ok=True)
    audit = json.loads((ROOT / 'Y_final_release_verification_piv4_0909.json').read_text())
    assert audit['state'] == 'VERIFIED' and audit['cases'] == 27
    assert audit['piv_area_cutoff_cases_verified'] == 27
    list_path = ROOT / 'Y_DOWNLOAD_MANIFEST_v4_0909.json'
    assert sha(list_path) == 'f9e51260299981f87952c73f989024727aaa88ab6c826bc03e2e85641326eafd'
    source_manifest = json.loads(list_path.read_text())
    expected = {entry['relativePath']: entry for entry in source_manifest['files']}
    assert source_manifest['runId'] == RUN_ID

    identity_rel = '5D/NoGrid/runtime/identity.json'
    assert sha(ROOT / identity_rel) == expected[identity_rel]['sha256']
    identity = json.loads((ROOT / identity_rel).read_text())
    for name, digest in identity['extra']['code'].items():
        assert sha(SOURCE_CODE / 'step3_y4h5' / name) == digest, name

    items = []
    sources = []
    for distance in DISTANCES:
        for name in CASE_NAMES:
            if (distance, name) == ('40D', 'SRG111_SC39d'):
                continue
            rel = f'{distance}/{name}/results/06_final/Y_FINAL_case_0906.h5'
            path = ROOT / rel
            entry = expected[rel]
            assert path.stat().st_size == entry['sizeBytes'] and sha(path) == entry['sha256'], rel
            with h5py.File(path, 'r') as f:
                profile = f['ProfilesXi']
                eta = float(f['Final/eta_I'][()])
                x = profile['coordinate_m'][()] / eta
                y = profile['finished'][0]
                keep = ~((profile['bins'][()] == 0) & (profile['sums'][4] == 0))
                assert np.isfinite(eta) and eta > 0
                assert np.isfinite(x[keep]).all() and np.isfinite(y[keep]).all()
                items.append(dict(distance=distance, name=name, x=x[keep], y=y[keep]))
            sources.append(entry)
    assert len(items) == 27

    files, figures = [], []
    style()

    def render(subset, stem, groupby=None):
        # Match the original single/group plot size, data, colours and line styles.
        fig, ax = plt.subplots(figsize=(3.45, 2.6 if groupby is None else 2.7),
                               layout='constrained')
        for index, item in enumerate(subset):
            if groupby is None:
                line, = ax.plot(item['x'], item['y'], color=BLUE)
            else:
                label = item['name'].replace('_', ' ') if groupby == 'case' else item['distance']
                line, = ax.plot(item['x'], item['y'], label=label,
                                color=COLORS[index % len(COLORS)],
                                ls=('-', '--', '-.', ':')[index % 4])
            # Plotting must not change a single stored velocity value.
            np.testing.assert_array_equal(line.get_xdata(), item['x'])
            np.testing.assert_array_equal(line.get_ydata(), item['y'])
        ax.set(xlabel=r'$\xi/\eta_I$', ylabel=r'$\overline{U}\;(\mathrm{m\,s^{-1}})$')
        ax.set_xlim(*XLIM)
        ax.set_xticks([-300, -150, 0, 150, 300])
        if groupby is not None:
            ax.legend(frameon=False, fontsize=7)
        assert tuple(ax.get_xlim()) == XLIM and ax.get_title() == ''
        assert 'xlim300_0910' in stem
        target = ROOT / stem
        save(fig, target)
        for suffix in ('.png', '.pdf'):
            path = target.with_suffix(suffix)
            if suffix == '.png':
                with Image.open(path) as im:
                    im.verify()
            else:
                with path.open('rb') as stream:
                    assert stream.read(5) == b'%PDF-' and path.stat().st_size > 1000
            files.append(dict(relativePath=path.relative_to(ROOT).as_posix(),
                              sizeBytes=path.stat().st_size, sha256=sha(path)))
        figures.append(dict(stem=stem, xlim=list(XLIM),
                            cases=[f"{item['distance']}/{item['name']}" for item in subset]))
        write_json(CONTROL / 'progress.json', dict(state='PLOTTING',
                    figurePairs=len(figures), expectedFigurePairs=38))
        print(f'Figures {len(figures)}/38: {stem}', flush=True)

    for item in items:
        render([item], f"{item['distance']}/{item['name']}/results/05_xi_approximation/"
                      'Y_ubar_xi_JFM_case_xlim300_0910')
    for distance in DISTANCES:
        render([item for item in items if item['distance'] == distance],
               f'{distance}/ALL_CASES/Y_COMBINED_ubar_xi_JFM_xlim300_0910', 'case')
    for name in CASE_NAMES:
        render([item for item in items if item['name'] == name],
               f'BY_CASE/{name}/Y_BY_CASE_ubar_xi_JFM_xlim300_0910', 'distance')
    assert len(figures) == 38 and len(files) == 76
    # Preserve the original, already-downloaded release and all its checksums.
    # Only the new xlim300 filenames and their own manifest/control files are written.
    for entry in source_manifest['files']:
        path = ROOT / entry['relativePath']
        assert path.stat().st_size == entry['sizeBytes'] and sha(path) == entry['sha256'], entry['relativePath']
    report = dict(state='VERIFIED', runId=RUN_ID, remoteRoot=str(ROOT.resolve()),
                  cases=27, figurePairs=38, fileCount=76, xlim=list(XLIM),
                  totalBytes=sum(entry['sizeBytes'] for entry in files),
                  originalReleaseFilesUnchanged=len(source_manifest['files']),
                  sourceResultsUnchanged=True, sourceFiles=sources, files=files,
                  figures=figures, verifiedUtc=datetime.now(timezone.utc).isoformat())
    write_json(ROOT / MANIFEST, report)
    write_json(CONTROL / 'progress.json', dict(state='VERIFIED', figurePairs=38, files=76))
    print(f'VERIFIED: 38 figures / 76 files. Manifest: {ROOT / MANIFEST}', flush=True)


if __name__ == '__main__':
    main()
