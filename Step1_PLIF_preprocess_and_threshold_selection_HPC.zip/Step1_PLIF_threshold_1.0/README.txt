Step1_PLIF_threshold_1.0 — MSc_2026_final

NAMING NOTE
-----------
The package/folder name is Step1_PLIF_threshold_1.0.
MATLAB function names cannot contain a period, so the executable MATLAB file/function is
Step1_PLIF_threshold_1_0.m / Step1_PLIF_threshold_1_0(caseIndex).
This is a naming-only distinction; the scientific workflow is unchanged.
=====================================

Purpose
-------
Final 28-case HPC package for the validated three-in-one PLIF workflow:
Step 0 black-stripe screening -> Step 1 background profile -> Step 2 centreline
normalisation profile -> Step 3 Method 3 threshold selection.

Scientific logic
----------------
The scientific processing in Step1_PLIF_threshold_1_0.m is inherited from the validated
40D/NoGrid baseline supplied on 2026-08-29. The 28-case version changes routing,
input-integrity checks, HPC execution, case metadata, and completion tracking.
Core parameters remain:
- downstream even PLIF frames only;
- fully black horizontal stripe thickness > 10 px is problematic;
- PIV frame = (even PLIF frame - 98)/2;
- background columns 1980:2020;
- final background smoothing: centred 15-point moving mean;
- yCL = 514.45 px;
- centreline trend: movmedian(51) + SG(3,151);
- PCHIP repair x-index 560:650;
- final centreline smoothing: centred 15-point moving mean;
- Method 1 preprocessing in Step 3: x movmean radius 7 then SG(3,31) along y;
- threshold sweep 0:0.01:2.00;
- select threshold values in 0.1-0.4 and 0.8-1.1, then fit against log10(threshold);
- no reflection-removal stage is added.

Required location on CX3
------------------------
Place this package as:
  $HOME/MSc_Project/MSc_2026_final/01_CODE/Step1_PLIF_threshold_1.0

Input root
----------
  $HOME/MSc_Project/MSc_2026_final/02_INPUTS/PLIF

Each case path is a soft link created earlier, e.g.
  .../02_INPUTS/PLIF/40D/NoGrid

The MATLAB program NEVER writes to the PLIF input tree.

Output root
-----------
  $HOME/MSc_Project/MSc_2026_final/05_OUTPUTS/<distance>/<case>

This is the shared permanent case directory. Other later programs may create
additional subfolders in the same case directory.

Input integrity gate
--------------------
The shell preflight requires exactly 5002 TIFF files, with literal filenames
0100.tif through 5101.tif. Before quantitative processing, every MATLAB task requires:
- exactly 5002 recognised numeric-suffix tif/tiff files;
- numeric frame numbers exactly 0100:5101, once each;
- image size 1600 x 2560;
- every image encountered in the Step-0 scan must have the same dimensions.
A corrupted cine frame exported as a same-size zero TIFF remains in sequence and
is naturally detected by the existing black-stripe screening.

HPC configuration
-----------------
MATLAB module: MATLAB/2024b
PBS array: 1-28%12
One array task = one case.
Each task requests: 2 CPU, 8 GB RAM, 8 h walltime.
No MATLAB parpool is opened by this package.

Files
-----
Step1_PLIF_threshold_1_0.m
    Main MATLAB function. Run one case as Step1_PLIF_threshold_1_0(index), index=1:28.

cases_28.csv
    Authoritative index-to-case mapping used by MATLAB and shell scripts.

preflight_Step1_PLIF_threshold_1_0.sh
    Verifies that all 28 soft-link inputs are present and contain the complete
    5002-frame numbered sequence before array submission.

run_Step1_PLIF_threshold_1_0.pbs
    PBS array job definition.

submit_Step1_PLIF_threshold_1_0.sh
    Runs preflight, archives the manifest under 06_MANIFESTS, then qsubs the
    28-case array.

check_Step1_PLIF_threshold_1_0_progress.sh
    Reports per-case completion markers and optionally PBS array states.

Normal workflow
---------------
1. Put this package at the required location.
2. Make shell/PBS files executable:
     chmod +x *.sh run_Step1_PLIF_threshold_1_0.pbs
3. Preflight only:
     ./preflight_Step1_PLIF_threshold_1_0.sh
   Do not submit until READY = 28 / 28.
4. Submit:
     ./submit_Step1_PLIF_threshold_1_0.sh
5. Monitor (replace JOBID with qsub output):
     ./check_Step1_PLIF_threshold_1_0_progress.sh 'JOBID'
   Or inspect outputs only:
     ./check_Step1_PLIF_threshold_1_0_progress.sh

Completion
----------
A successfully completed case writes:
  <case output>/Step1_PLIF_threshold_1.0_DONE.txt
The marker records the case identity, number of good/bad even frames, selected
Method 3 threshold, and completion time.

Logs
----
Detailed task logs are written to:
  $HOME/MSc_Project/MSc_2026_final/04_LOGS/Step1_PLIF_threshold_1.0

Notes
-----
- Do not move the currently running cine-extraction tools until that extraction
  array is fully finished.
- This package does not require the PLIF TIFF storage itself to be writable.
- If a case is re-run, files with the same names inside this program's own
  output subfolders may be overwritten; the case-level completion marker is
  removed at run start and recreated only after successful completion.

PARALLEL STARTUP FIX
--------------------
The PBS launcher uses a private node-local MATLAB_PREFDIR and TMPDIR for every
array task and staggers the first 12 MATLAB starts by 5 seconds (0--55 s).
The scientific tasks still run concurrently with PBS array 1-28%12. This
isolates per-process MATLAB startup state while avoiding a simultaneous
12-process startup burst against network-home/licensing services.

A 12-way parallel smoke-test PBS file is included:
  test_MATLAB_parallel_12.pbs
It does not read or write PLIF scientific data.


PARALLEL STARTUP FIX v2
-----------------------
CX3 PBS array jobs provide a per-task TMPDIR whose path contains square brackets
(e.g. ...pbs.123456[1].pbs-7). MATLAB R2024b was observed to exit with code 1
before MATLAB startup output when launched from those array tasks, while the same
MATLAB module and Step 1 code ran normally in a non-array PBS job. This package
therefore overrides TMPDIR and MATLAB_PREFDIR with a private node-local /tmp tree
whose path contains no square brackets. The scientific MATLAB algorithm is
unchanged. The formal PBS array remains 1-28%12.

ENGLISH PROGRAM GUIDE
---------------------
Step1_Readme.docx is the complete English program guide. It covers installation,
all processing stages, parameter meanings, output interpretation, the 28-case
manifest, and troubleshooting. A separate identical copy is supplied alongside
the ZIP archive.

IMPLEMENTATION DETAILS
----------------------
- Positive-threshold histogram counts include values equal to the threshold
  (phiStar >= threshold). Threshold zero explicitly uses phiStar > 0.
- MATLAB matrix dimension 1 is streamwise x (image rows); dimension 2 is y
  (image columns). The centreline at y=514.45 interpolates columns 514 and 515.
- The PCHIP repair interval 560:650 refers to row indices. In the reversed
  plotting coordinate x_px=1600:-1:1, it corresponds to x=951:1041.
- A DONE marker confirms that the program reached its end. The selected
  threshold must still be checked: nearly parallel fitted lines can yield NaN,
  and the intersection is not constrained to the sweep or fitting ranges.
- The deployment helper copies an explicit legacy file list. To retain the
  Word guide and optional smoke test, copy the entire package to 01_CODE,
  or copy those two files separately after using the helper.

DOCUMENTATION REVISION
----------------------
The supplied source package already used English comments and messages. This
revision clarifies the histogram boundary convention and fitting-range units,
and adds Step1_Readme.docx. Scientific calculations, case mapping, resource
requests, file paths, and numerical parameters are unchanged.
