#!/bin/bash
set -u

MASTER="${HOME}/MSc_Project/MSc_2026_final"
CODEDIR="${MASTER}/01_CODE/Step1_PLIF_threshold_1.0"
OUTROOT="${MASTER}/05_OUTPUTS"
LOGDIR="${MASTER}/04_LOGS/Step1_PLIF_threshold_1.0"
CASECSV="${CODEDIR}/cases_28.csv"
JOBID="${1:-}"

if [[ ! -f "$CASECSV" ]]; then
    echo "ERROR: cannot find $CASECSV" >&2
    exit 2
fi

if [[ -n "$JOBID" ]]; then
    echo "PBS states for $JOBID"
    qstat -t "$JOBID" 2>/dev/null || true
    echo
    echo "State counts:"
    qstat -t "$JOBID" 2>/dev/null | awk '$1 ~ /\[[0-9]+\]/ {s[$5]++} END {for(k in s) print "  " k ": " s[k]}' | sort || true
    echo
fi

doneCount=0
incompleteCount=0
notStartedCount=0

printf '%-4s %-5s %-22s %-20s\n' "IDX" "DIST" "CASE" "OUTPUT STATUS"
printf '%-4s %-5s %-22s %-20s\n' "----" "-----" "----------------------" "--------------------"

while IFS=, read -r idx dist caseName; do
    [[ "$idx" == "Index" ]] && continue
    caseName="${caseName%$'\r'}"
    out="$OUTROOT/$dist/$caseName"
    marker="$out/Step1_PLIF_threshold_1.0_DONE.txt"

    if [[ -f "$marker" ]]; then
        status="DONE"
        ((doneCount+=1))
    elif [[ -d "$out/PLIF_black_stripe_check_widthGT10_PLIF" || \
            -d "$out/PLIF_background_profile_col1980_2020" || \
            -d "$out/PLIF_normalisation_profile_even_final" || \
            -d "$out/Y_threshold_selection_method3_even_final" || \
            -f "$out/summary_complete_blackStripe_background_norm_method3_even.txt" ]]; then
        status="RUNNING/FAILED"
        ((incompleteCount+=1))
    else
        status="NOT_STARTED"
        ((notStartedCount+=1))
    fi

    printf '%-4s %-5s %-22s %-20s\n' "$idx" "$dist" "$caseName" "$status"
done < "$CASECSV"

echo
echo "DONE:           $doneCount / 28"
echo "RUNNING/FAILED: $incompleteCount / 28"
echo "NOT_STARTED:    $notStartedCount / 28"

if [[ -d "$LOGDIR" ]]; then
    echo
    echo "Recent error-like CURRENT-run log lines (if any):"
    find "$LOGDIR" -maxdepth 1 -type f \( -name 'task_*.log' -o -name 'S1_PLIF_TH10.o*' \) -print0 2>/dev/null \
      | xargs -0 -r grep -HniE 'INPUT_NOT_READY|Error using|ERROR|Out of memory|License checkout failed|Killed|Segmentation|MATLAB exit code: [1-9]' 2>/dev/null \
      | tail -40 || true
fi
