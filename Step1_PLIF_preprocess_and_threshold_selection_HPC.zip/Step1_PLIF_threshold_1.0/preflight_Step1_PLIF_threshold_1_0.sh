#!/bin/bash
set -u

MASTER="${HOME}/MSc_Project/MSc_2026_final"
CODEDIR="${MASTER}/01_CODE/Step1_PLIF_threshold_1.0"
INPUTROOT="${MASTER}/02_INPUTS/PLIF"
CASECSV="${CODEDIR}/cases_28.csv"

if [[ ! -f "$CASECSV" ]]; then
    echo "ERROR: cannot find $CASECSV" >&2
    exit 2
fi

expected=5002
ready=0
bad=0

echo "Step1_PLIF_threshold_1_0 preflight"
echo "Input root: $INPUTROOT"
echo
printf '%-4s %-5s %-22s %-8s %-10s\n' "IDX" "DIST" "CASE" "TIFFS" "STATUS"
printf '%-4s %-5s %-22s %-8s %-10s\n' "----" "-----" "----------------------" "--------" "----------"

while IFS=, read -r idx dist caseName; do
    [[ "$idx" == "Index" ]] && continue
    d="$INPUTROOT/$dist/$caseName"

    if [[ ! -d "$d" ]]; then
        printf '%-4s %-5s %-22s %-8s %-10s\n' "$idx" "$dist" "$caseName" "0" "NOT_READY"
        ((bad+=1))
        continue
    fi

    n=$(find -L "$d" -maxdepth 1 -type f \( -iname '*.tif' -o -iname '*.tiff' \) -printf '.' 2>/dev/null | wc -c)

    exact=1
    if [[ "$n" -eq "$expected" ]]; then
        for frame in $(seq 100 5101); do
            fn=$(printf '%04d.tif' "$frame")
            if [[ ! -f "$d/$fn" ]]; then
                exact=0
                break
            fi
        done
    else
        exact=0
    fi

    if [[ "$n" -eq "$expected" && "$exact" -eq 1 ]]; then
        printf '%-4s %-5s %-22s %-8s %-10s\n' "$idx" "$dist" "$caseName" "$n" "READY"
        ((ready+=1))
    else
        printf '%-4s %-5s %-22s %-8s %-10s\n' "$idx" "$dist" "$caseName" "$n" "NOT_READY"
        ((bad+=1))
    fi
done < "$CASECSV"

echo
echo "READY: $ready / 28"
echo "NOT_READY: $bad / 28"

if [[ "$ready" -ne 28 ]]; then
    echo "Preflight FAILED: do not submit the 28-case MATLAB array yet."
    exit 1
fi

echo "Preflight PASSED: all 28 PLIF inputs contain 5002 numbered TIFF frames."
