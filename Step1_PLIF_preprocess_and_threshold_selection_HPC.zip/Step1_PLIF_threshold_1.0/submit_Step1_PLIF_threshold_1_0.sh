#!/bin/bash
set -euo pipefail

MASTER="${HOME}/MSc_Project/MSc_2026_final"
CODEDIR="${MASTER}/01_CODE/Step1_PLIF_threshold_1.0"
LOGDIR="${MASTER}/04_LOGS/Step1_PLIF_threshold_1.0"
MANIFESTDIR="${MASTER}/06_MANIFESTS"

mkdir -p "$LOGDIR" "$MANIFESTDIR"

cd "$CODEDIR"
./preflight_Step1_PLIF_threshold_1_0.sh

cp -f cases_28.csv "$MANIFESTDIR/Step1_PLIF_threshold_1.0_cases_28.csv"

# Archive previous top-level Step1 run logs so old failed attempts do not pollute
# the current progress/error scan.
if compgen -G "$LOGDIR/task_*.log" >/dev/null || compgen -G "$LOGDIR/S1_PLIF_TH10.o*" >/dev/null; then
    ARCHIVE="$LOGDIR/archive_$(date '+%Y%m%d_%H%M%S')"
    mkdir -p "$ARCHIVE"
    mv "$LOGDIR"/task_*.log "$ARCHIVE"/ 2>/dev/null || true
    mv "$LOGDIR"/S1_PLIF_TH10.o* "$ARCHIVE"/ 2>/dev/null || true
fi

cd "$LOGDIR"
JOBID=$(qsub "$CODEDIR/run_Step1_PLIF_threshold_1_0.pbs")

echo
echo "Submitted Step1_PLIF_threshold_1.0 array job: $JOBID"
echo "Array: 1-28%12"
echo "Parallel-safe MATLAB startup: private MATLAB_PREFDIR/TMPDIR per task + 5 s stagger"
echo "Logs: $LOGDIR"
echo "Monitor with:"
echo "  $CODEDIR/check_Step1_PLIF_threshold_1_0_progress.sh '$JOBID'"
