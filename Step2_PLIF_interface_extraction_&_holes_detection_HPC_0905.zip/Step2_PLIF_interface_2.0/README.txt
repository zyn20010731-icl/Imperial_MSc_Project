============================================================
Step2_PLIF_interface_2.0 -- PARALLEL EXECUTION PACKAGE (2026-09-05)
============================================================

WHAT THIS PACKAGE IS
---------------------
This is the complete, corrected set of files needed to run Step2 for all
28 cases using the new per-case-parallel architecture (10 workers /
256GB per case, cases run as a PBS array job). It replaces only the
EXECUTION layer of the previous package. The scientific algorithm is
byte-identical to your last known-good v5 code, with one small,
backward-compatible naming parameter added (see below).

FILES INCLUDED (6)
---------------------
1. Step2_PLIF_interface_2_0_chunk.m   -- LOCKED scientific file, patched
2. Step2_PLIF_interface_2_0_merge.m   -- LOCKED scientific file, patched
3. s2case_driver.m                     -- NEW: per-case parallel driver
4. validate_case1_parallel.pbs         -- PBS script: single-case test run
5. run_s2case_parallel_cases.pbs       -- PBS array script: cases 2-28
6. apply_outputTag_patch.py            -- the patch script already run on
                                           CX3 (included for the record /
                                           reproducibility only; you do
                                           NOT need to run it again)

WHAT CHANGED IN THE TWO LOCKED FILES (chunk.m / merge.m)
---------------------------------------------------------
Exactly one change, applied identically to both files: the function
signature gained a third, optional argument:

    Step2_PLIF_interface_2_0_chunk(taskIndex, runId, outputTag)
    Step2_PLIF_interface_2_0_merge(caseIndex, runId, outputTag)

outputTag defaults to '0904' if omitted, so calling either function the
old two-argument way reproduces the exact old behaviour and old output
paths. Every place that used to hardcode the literal string "0904" in an
output folder/file name now uses this outputTag variable instead. This is
a pure naming/parameterization change:
  - No computation, classification rule, threshold, or numeric algorithm
    was touched.
  - No plotting/figure code was touched.
  - No output file FORMAT or CONTENT (fields, .mat structure, image
    layout) was touched.
  - The only thing that changes is the folder/file suffix string, driven
    by whatever outputTag you pass in.
This package calls both functions with outputTag = '0905', so this run's
outputs land in *_0905 folders/files, never overwriting or colliding with
the earlier *_0904 results.

Verified: diffed byte-for-byte against your original uploaded
Step2_PLIF_interface_2.0_v5_0904.zip. Only the hunks described above
differ; nothing else in either file changed.

WHAT'S NEW (execution layer, not scientific code)
---------------------------------------------------------
s2case_driver.m is a brand-new function, written from scratch this
session -- it does NOT reuse or extend the old, suspect
Step2_PLIF_interface_2_0_case.m / case_serial.m files. For one case, it:
  1. Scans which of the 51 chunks are already done (chunk_NNN.mat +
     chunk_NNN_DONE.txt both present) and skips them -- safe to re-run.
  2. If any chunks remain, starts a 10-worker process pool
     (JobStorageLocation under $TMPDIR, node-local, never network
     storage) and runs the remaining chunks with parfor, each calling the
     unmodified Step2_PLIF_interface_2_0_chunk(taskIndex, runId,
     outputTag).
  3. Verifies all 51 chunks are really present.
  4. Calls Step2_PLIF_interface_2_0_merge(caseIndex, runId, outputTag).
  5. Writes coarse-grained STAGE_case.txt checkpoints throughout
     (driver_entered / chunk_scan_done / pool_starting / pool_started /
     parfor_completed / about_to_merge / complete), written only by this
     driver process, never by a parfor worker.

Each of the 28 cases is fully independent: its own row of cases_28.csv,
its own PLIF input folder, its own output folder, its own manifest/
checkpoint folder under 06_MANIFESTS/Step2_PLIF_interface_2.0/<runId>/
case_NN/. Nothing here reads or writes anything belonging to another
case.

validate_case1_parallel.pbs already ran case 1 successfully on CX3 with
this exact code (job 3990020.pbs-7, walltime extended to 2h after the
first 1h attempt was walltime-killed at the merge step).

run_s2case_parallel_cases.pbs is the production array job for the
remaining 27 cases (PBS array 2-28, %8 = up to 8 running concurrently,
10 cpu / 256GB / 12h walltime each, staggered start to avoid a login-node
thundering herd). It has NOT been submitted yet -- submit it only after
you've confirmed case 1's validation run finished completely.

WHAT'S DELIBERATELY NOT INCLUDED
---------------------------------------------------------
- cases_28.csv: already correct and in place on CX3; not touched or
  reproduced here so there is no risk of an out-of-date copy overwriting
  it.
- The old Step2_PLIF_interface_2_0_case.m / case_serial.m: retired.
  They are not part of this architecture and are not needed on CX3
  anymore for this run (you can leave them where they are, or remove
  them later, at your discretion -- this package does not touch them).

HOW TO DEPLOY
---------------------------------------------------------
All 6 files go into the same folder on CX3 where the current
Step2_PLIF_interface_2.0 code already lives:

    $HOME/MSc_Project/MSc_2026_final/01_CODE/Step2_PLIF_interface_2.0/

apply_outputTag_patch.py does not need to be re-run -- chunk.m and
merge.m in this package are already patched. If for any reason CX3's
copies are ever reset to the original 0904-only version, this script can
reproduce the exact same patch again.

After copying the files into place, case 1 has already been validated;
proceed straight to submitting run_s2case_parallel_cases.pbs for cases
2-28 (exact qsub command and monitoring commands to follow once you
confirm case 1 is fully complete).
