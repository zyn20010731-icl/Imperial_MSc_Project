function s2case_driver(caseIndex, runId, workers, outputTag)
%s2case_driver Process one complete case with intra-case parallel chunks.
%
% EXECUTION-LAYER ONLY. Calls the two LOCKED scientific functions exactly
% as before, unmodified in behaviour:
%   Step2_PLIF_interface_2_0_chunk(taskIndex, runId, outputTag)
%   Step2_PLIF_interface_2_0_merge(caseIndex, runId, outputTag)
%
% Each case is fully independent: its own case/threshold row from
% cases_28.csv, its own PLIF input folder, its own output folder, its own
% chunk-checkpoint manifest folder. Nothing here reads or writes anything
% belonging to another case.
%
% Within one case, the 51 fixed 50-frame chunks are distributed over a
% process-based MATLAB pool (default 10 workers) using parfor -- this
% matches the execution layout the locked chunk.m file's own header
% comment already assumes ("ten workers belonging to the same PBS case
% task may run different chunks concurrently").

clc; close all force;

nCases = 28;
nChunksPerCase = 51;

if nargin < 1 || isempty(caseIndex)
    caseIndex = str2double(getenv('PBS_ARRAY_INDEX'));
end
if nargin < 2 || isempty(runId)
    runId = getenv('STEP2_RUN_ID');
end
if nargin < 3 || isempty(workers)
    workers = 10;
end
if nargin < 4 || isempty(outputTag)
    outputTag = '0905';
end

if ~(isnumeric(caseIndex) && isscalar(caseIndex) && isfinite(caseIndex) && ...
        caseIndex == round(caseIndex) && caseIndex >= 1 && ...
        caseIndex <= nCases)
    error('caseIndex must be an integer from 1 to %d.', nCases);
end
if isempty(runId) || isempty(regexp(runId, '^[A-Za-z0-9_-]+$', 'once'))
    error('runId must contain only letters, numbers, underscore or hyphen.');
end
if ~(isnumeric(workers) && isscalar(workers) && isfinite(workers) && ...
        workers == round(workers) && workers >= 1 && workers <= 10)
    error('workers must be an integer from 1 to 10.');
end
if isempty(outputTag) || isempty(regexp(outputTag, '^[A-Za-z0-9_-]+$', 'once'))
    error('outputTag must contain only letters, numbers, underscore or hyphen.');
end

caseIndex = double(caseIndex);
workers = double(workers);

thisFile = mfilename('fullpath');
codeDir = fileparts(thisFile);
masterDir = fileparts(fileparts(codeDir));
manifestRunRoot = fullfile(masterDir, '06_MANIFESTS', ...
    'Step2_PLIF_interface_2.0', runId);
caseChunkDir = fullfile(manifestRunRoot, sprintf('case_%02d', caseIndex));
if ~exist(caseChunkDir, 'dir'), mkdir(caseChunkDir); end

writeDriverStage(caseChunkDir, 'driver_entered');

fprintf('============================================================\n');
fprintf('s2case_driver | case %d / %d\n', caseIndex, nCases);
fprintf('Run ID: %s\n', runId);
fprintf('Output tag: %s\n', outputTag);
fprintf('Requested process workers: %d\n', workers);
fprintf('============================================================\n\n');

%% ------------------------------------------------------------
%  Resume support: skip chunks whose MAT + DONE checkpoint both exist
%% ------------------------------------------------------------

chunkIndicesToRun = zeros(0,1);
for chunkIndex = 1:nChunksPerCase
    chunkMat = fullfile(caseChunkDir, sprintf('chunk_%03d.mat', chunkIndex));
    chunkDone = fullfile(caseChunkDir, sprintf('chunk_%03d_DONE.txt', chunkIndex));
    if exist(chunkMat, 'file') && exist(chunkDone, 'file')
        fprintf('Existing checkpoint retained: case %02d chunk %03d\n', caseIndex, chunkIndex);
    else
        chunkIndicesToRun(end+1,1) = chunkIndex; %#ok<AGROW>
    end
end
writeDriverStage(caseChunkDir, 'chunk_scan_done');
fprintf('case %d: %d of %d chunks need to run\n', caseIndex, numel(chunkIndicesToRun), nChunksPerCase);

%% ------------------------------------------------------------
%  Parallel chunk processing (only if there is anything left to do)
%% ------------------------------------------------------------

if ~isempty(chunkIndicesToRun)
    tmpRoot = getenv('TMPDIR');
    if isempty(tmpRoot)
        error('TMPDIR is empty. Run this function through the supplied PBS job.');
    end
    poolStorage = fullfile(tmpRoot, sprintf('parallel_case_%02d', caseIndex));
    if ~exist(poolStorage, 'dir'), mkdir(poolStorage); end

    oldPool = gcp('nocreate');
    if ~isempty(oldPool), delete(oldPool); end

    processCluster = parcluster('Processes');
    processCluster.JobStorageLocation = poolStorage;

    writeDriverStage(caseChunkDir, 'pool_starting');
    pool = parpool(processCluster, workers);
    writeDriverStage(caseChunkDir, 'pool_started');

    try
        parfor iChunk = 1:numel(chunkIndicesToRun)
            chunkIndex = chunkIndicesToRun(iChunk); %#ok<PFBNS>
            taskIndex = (caseIndex - 1) * nChunksPerCase + chunkIndex;
            fprintf('--- case %02d : chunk %03d / %d (task %d) ---\n', ...
                caseIndex, chunkIndex, nChunksPerCase, taskIndex);
            Step2_PLIF_interface_2_0_chunk(taskIndex, runId, outputTag);
        end
        writeDriverStage(caseChunkDir, 'parfor_completed');
    catch ME
        writeDriverStage(caseChunkDir, sprintf('FAILED: %s', ME.identifier));
        delete(pool);
        rethrow(ME);
    end

    delete(pool);
end

%% ------------------------------------------------------------
%  Verify every chunk checkpoint is really present before merging
%% ------------------------------------------------------------

missingChunks = zeros(0,1);
for chunkIndex = 1:nChunksPerCase
    chunkMat = fullfile(caseChunkDir, sprintf('chunk_%03d.mat', chunkIndex));
    chunkDone = fullfile(caseChunkDir, sprintf('chunk_%03d_DONE.txt', chunkIndex));
    if ~exist(chunkMat, 'file') || ~exist(chunkDone, 'file')
        missingChunks(end+1,1) = chunkIndex; %#ok<AGROW>
    end
end
if ~isempty(missingChunks)
    writeDriverStage(caseChunkDir, sprintf('FAILED: missing chunks %s', mat2str(missingChunks.')));
    error('Case %d is missing chunk checkpoint(s): %s', caseIndex, mat2str(missingChunks.'));
end

writeDriverStage(caseChunkDir, 'about_to_merge');
Step2_PLIF_interface_2_0_merge(caseIndex, runId, outputTag);
writeDriverStage(caseChunkDir, 'complete');

fprintf('\nCASE COMPLETE: %d / %d\n', caseIndex, nCases);

end

function writeDriverStage(caseChunkDir, tag)
% Coarse-grained stage checkpoint, written ONLY by this client-side
% function (never by a parfor worker) so there is never more than one
% writer touching STAGE_case.txt at once.
    try
        fid = fopen(fullfile(caseChunkDir, 'STAGE_case.txt'), 'w');
        if fid > 0
            fprintf(fid, '%s | %s | host=%s | pid=%d\n', ...
                datestr(now, 'yyyy-mm-dd HH:MM:SS'), tag, ...
                getenv('HOSTNAME'), feature('getpid'));
            fclose(fid);
        end
    catch
    end
end
