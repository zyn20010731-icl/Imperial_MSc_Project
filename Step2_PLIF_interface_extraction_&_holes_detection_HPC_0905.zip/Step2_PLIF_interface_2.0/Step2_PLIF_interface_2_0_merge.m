function Step2_PLIF_interface_2_0_merge(caseIndex, runId, outputTag)
%Step2_PLIF_interface_2_0_merge Merge one case after all 51 chunks succeed.
%
% SCIENTIFIC BASELINE: v5 connected-component label-based interface/hole
% detection (Step2_v5_final_algorithm_summary.md; run under the
% "Step2_PLIF_interface_2.0" package identity; output suffix is an
% execution-layer choice supplied by the caller as outputTag, default
% "0904" if omitted). See Step2_PLIF_interface_2_0_chunk.m header and the project
% algorithm specification document for the full description. This function
% does no new scientific computation -- it only concatenates the 51
% persistent per-chunk checkpoints (in original good-even-frame order),
% verifies every required diagnostic/high-resolution PNG exists and is
% readable, writes a human-readable per-case frame-check text file, saves
% the final case-level MAT file, and writes the completion marker. It never
% overwrites a chunk checkpoint and never re-runs any frame.
%
% SAFETY BEHAVIOUR: any missing or inconsistent chunk checkpoint, any
% missing/corrupt PNG, or any post-save verification failure raises a hard
% MATLAB error that is never caught here. It propagates out of this
% function (called at the end of Step2_PLIF_interface_2_0_case), which
% then also fails and stops that case only, exactly like a chunk-stage
% failure. The completion marker is written only after every check passes.

clc; close all force;

framesPerChunk = 50;
nominalEvenFrameCount = 2501;
nCases = 28;
nChunksPerCase = ceil(nominalEvenFrameCount / framesPerChunk);

if nargin < 1 || isempty(caseIndex)
    caseIndex = str2double(getenv('PBS_ARRAY_INDEX'));
end
if nargin < 2 || isempty(runId)
    runId = getenv('STEP2_RUN_ID');
end
if nargin < 3 || isempty(outputTag)
    outputTag = '0904';
end

if ~(isnumeric(caseIndex) && isscalar(caseIndex) && isfinite(caseIndex) && ...
        caseIndex == round(caseIndex) && caseIndex >= 1 && ...
        caseIndex <= nCases)
    error('caseIndex must be an integer from 1 to %d.', nCases);
end
if isempty(runId) || isempty(regexp(runId, '^[A-Za-z0-9_-]+$', 'once'))
    error('runId must contain only letters, numbers, underscore or hyphen.');
end
if isempty(outputTag) || isempty(regexp(outputTag, '^[A-Za-z0-9_-]+$', 'once'))
    error('outputTag must contain only letters, numbers, underscore or hyphen.');
end

caseIndex = double(caseIndex);
versionTag = 'Step2_PLIF_interface_2.0';

%% ============================================================
%  Resolve case and paths
%% ============================================================

thisFile = mfilename('fullpath');
codeDir = fileparts(thisFile);
masterDir = fileparts(fileparts(codeDir));
caseTablePath = fullfile(codeDir, 'cases_28.csv');

Cases = readtable(caseTablePath, 'TextType', 'string');
requiredColumns = {'Index','Distance','CaseName','PhiThEven'};
if height(Cases) ~= nCases || ...
        ~all(ismember(requiredColumns, Cases.Properties.VariableNames)) || ...
        any(Cases.Index(:) ~= (1:nCases).')
    error('Invalid cases_28.csv manifest.');
end

thisCase = Cases(caseIndex,:);
distanceName = char(thisCase.Distance);
caseName = char(thisCase.CaseName);
phi_th_even = double(thisCase.PhiThEven);
phiTag = sprintf('phi%04d', round(phi_th_even * 1000));
caseLabel = sprintf('%s / %s', distanceName, caseName);

nRows = 1600;
nCols = 2560;

plifDir = fullfile(masterDir, '02_INPUTS', 'PLIF', distanceName, caseName);
caseOutputRoot = fullfile(masterDir, '05_OUTPUTS', distanceName, caseName);
blackStripeFile = fullfile(caseOutputRoot, ...
    'PLIF_black_stripe_check_widthGT10_PLIF', ...
    'PLIF_black_stripe_check_widthGT10_results_PLIF.mat');
backgroundProfileFile = fullfile(caseOutputRoot, ...
    'PLIF_background_profile_col1980_2020', ...
    'PLIF_background_profile_col1980_2020_even_goodFrames.mat');
normalisationProfileFile = fullfile(caseOutputRoot, ...
    'PLIF_normalisation_profile_even_final', ...
    'PLIF_normalisation_profile_rawMean_bgCol1980_2020_even_goodFrames.mat');

outDir = fullfile(caseOutputRoot, ...
    sprintf('Y_interface_detection_method1_even_%s_final_%s', phiTag, outputTag));
diagnosticDir = fullfile(outDir, sprintf('Diagnostic_4panel_%s', outputTag));
highResolutionDir = fullfile(outDir, sprintf('High_resolution_panel_%s', outputTag));

manifestRunRoot = fullfile(masterDir, '06_MANIFESTS', ...
    'Step2_PLIF_interface_2.0', runId);
caseChunkDir = fullfile(manifestRunRoot, sprintf('case_%02d', caseIndex));

% v2.0 uses its own completion-marker filename (2.0, not 1.0), since this is
% a new output tree (outputTag suffix, this round) that never coexists with
% 1.x or the earlier 0902-suffixed v4-algorithm outputs.
doneMarkerFile = fullfile(outDir, sprintf('Step2_PLIF_interface_2.0_DONE_%s.txt', outputTag));
if exist(doneMarkerFile, 'file'), delete(doneMarkerFile); end

fprintf('============================================================\n');
fprintf('Step2 v2.0 merge | case %d / %d\n', caseIndex, nCases);
fprintf('Version: %s\n', versionTag);
fprintf('Run ID: %s\n', runId);
fprintf('Case: %s\n', caseLabel);
fprintf('Threshold: %.6f (%s)\n', phi_th_even, phiTag);
fprintf('============================================================\n\n');

%% ============================================================
%  Load authoritative Step-1 inputs -- same gates as the chunk stage
%% ============================================================

requiredFiles = {blackStripeFile, backgroundProfileFile, ...
    normalisationProfileFile};
for iReq = 1:numel(requiredFiles)
    if ~exist(requiredFiles{iReq}, 'file')
        error('Required Step-1 input is missing:\n%s', requiredFiles{iReq});
    end
end

Sblack = load(blackStripeFile);
requiredBlackFields = {'frameNoEvenUse','pivFrameNoEvenUse', ...
    'badEvenFrameNos','badEvenFileNames','excludedPIVFrameNos'};
for iField = 1:numel(requiredBlackFields)
    if ~isfield(Sblack, requiredBlackFields{iField})
        error('Missing %s in:\n%s', requiredBlackFields{iField}, ...
            blackStripeFile);
    end
end

frameNoEven_toProcess = double(Sblack.frameNoEvenUse(:));
pivFrameNoEvenUse = double(Sblack.pivFrameNoEvenUse(:));
badEvenFrameNos = double(Sblack.badEvenFrameNos(:));
badEvenFileNames = Sblack.badEvenFileNames;
excludedPIVFrameNos = double(Sblack.excludedPIVFrameNos(:));

if isempty(frameNoEven_toProcess) || ...
        any(mod(frameNoEven_toProcess,2) ~= 0) || ...
        any(diff(frameNoEven_toProcess) <= 0) || ...
        numel(unique(frameNoEven_toProcess)) ~= ...
        numel(frameNoEven_toProcess)
    error('Invalid Step-1 frameNoEvenUse population.');
end
if numel(pivFrameNoEvenUse) ~= numel(frameNoEven_toProcess) || ...
        any(pivFrameNoEvenUse ~= (frameNoEven_toProcess - 98)./2)
    error('pivFrameNoEvenUse is inconsistent with frameNoEvenUse.');
end

Sbg = load(backgroundProfileFile);
if ~isfield(Sbg, 'B_profile_even')
    error('Missing B_profile_even in:\n%s', backgroundProfileFile);
end
B_profile_even = double(Sbg.B_profile_even(:));
if any(~isfinite(B_profile_even))
    error('B_profile_even contains non-finite values:\n%s', backgroundProfileFile);
end
if isfield(Sbg,'frameNoEvenUse') && ...
        ~isequal(double(Sbg.frameNoEvenUse(:)), frameNoEven_toProcess)
    error('Background MAT frameNoEvenUse disagrees with black-stripe MAT.');
end
if isfield(Sbg,'pivFrameNoEvenUse') && ...
        ~isequal(double(Sbg.pivFrameNoEvenUse(:)), pivFrameNoEvenUse)
    error('Background MAT pivFrameNoEvenUse disagrees with black-stripe MAT.');
end

Snorm = load(normalisationProfileFile);
if ~isfield(Snorm, 'Phi_ref_even_forNorm')
    error('Missing Phi_ref_even_forNorm in:\n%s', ...
        normalisationProfileFile);
end
Phi_ref_even_forNorm = double(Snorm.Phi_ref_even_forNorm(:));
if isfield(Snorm,'yCL_col')
    yCL_col = double(Snorm.yCL_col);
else
    yCL_col = 514.45;
end
if isfield(Snorm,'frameNoEvenUse') && ...
        ~isequal(double(Snorm.frameNoEvenUse(:)), frameNoEven_toProcess)
    error('Normalisation MAT frameNoEvenUse disagrees with black-stripe MAT.');
end
if isfield(Snorm,'pivFrameNoEvenUse') && ...
        ~isequal(double(Snorm.pivFrameNoEvenUse(:)), pivFrameNoEvenUse)
    error('Normalisation MAT pivFrameNoEvenUse disagrees with black-stripe MAT.');
end
if any(~isfinite(Phi_ref_even_forNorm)) || any(Phi_ref_even_forNorm <= 0)
    error('Phi_ref_even_forNorm contains invalid values.');
end

nProcess = numel(frameNoEven_toProcess);
frameStartEven = min(frameNoEven_toProcess);
frameEndEven = max(frameNoEven_toProcess);
diagnosticEveryNFrames = 20;
highResolutionEveryNFrames = 100;
diagnosticFrameNoPlanned = frameNoEven_toProcess( ...
    1:diagnosticEveryNFrames:nProcess);
highResolutionFrameNoPlanned = frameNoEven_toProcess( ...
    1:highResolutionEveryNFrames:nProcess);

%% ============================================================
%  Merge all 51 chunk checkpoints into original ResultEven order
%% ============================================================

ResultEven = repmat(makeEmptyResultV2(), nProcess, 1);
seenGlobalIndices = false(nProcess,1);
chunkStartTimes = nan(nChunksPerCase,1);
chunkFinishTimes = nan(nChunksPerCase,1);
chunkElapsedMin = nan(nChunksPerCase,1);

for chunkIndex = 1:nChunksPerCase
    chunkMat = fullfile(caseChunkDir, sprintf('chunk_%03d.mat', chunkIndex));
    chunkDone = fullfile(caseChunkDir, ...
        sprintf('chunk_%03d_DONE.txt', chunkIndex));

    if ~exist(chunkMat, 'file') || ~exist(chunkDone, 'file')
        error('Missing chunk checkpoint or marker for case %d chunk %d.', ...
            caseIndex, chunkIndex);
    end

    C = load(chunkMat, 'ResultChunk', 'ChunkMeta');
    if ~isfield(C,'ResultChunk') || ~isfield(C,'ChunkMeta')
        error('Invalid chunk MAT:\n%s', chunkMat);
    end

    M = C.ChunkMeta;
    expectedStart = (chunkIndex - 1) * framesPerChunk + 1;
    expectedEnd = min(chunkIndex * framesPerChunk, nProcess);
    if expectedStart <= nProcess
        expectedIndices = (expectedStart:expectedEnd).';
    else
        expectedIndices = zeros(0,1);
    end

    if ~strcmp(M.runId, runId) || M.caseIndex ~= caseIndex || ...
            M.chunkIndex ~= chunkIndex || ...
            ~strcmp(M.distance, distanceName) || ...
            ~strcmp(M.caseName, caseName) || ...
            abs(M.phi_th_even - phi_th_even) > 1e-12 || ...
            ~isequal(double(M.globalIndices(:)), expectedIndices) || ...
            numel(C.ResultChunk) ~= numel(expectedIndices)
        error('Chunk metadata mismatch:\n%s', chunkMat);
    end

    if ~isempty(expectedIndices)
        expectedFrames = frameNoEven_toProcess(expectedIndices);
        actualFrames = double([C.ResultChunk.frameNo]).';
        if ~isequal(actualFrames, expectedFrames)
            error('Chunk frame-number mismatch:\n%s', chunkMat);
        end
        ResultEven(expectedIndices) = C.ResultChunk(:);
        seenGlobalIndices(expectedIndices) = true;
    end

    chunkStartTimes(chunkIndex) = M.chunkStartDatenum;
    chunkFinishTimes(chunkIndex) = M.chunkFinishDatenum;
    chunkElapsedMin(chunkIndex) = M.chunkElapsedMin;

    fprintf('Merged chunk %3d / %3d | frames = %d\n', ...
        chunkIndex, nChunksPerCase, numel(expectedIndices));
end

if ~all(seenGlobalIndices)
    error('Merged chunks do not cover every GOOD EVEN frame exactly once.');
end

statusList = string({ResultEven.status});
if any(~ismember(statusList, ["ok","invalid_no_background"]))
    error(['Unexpected status value found while merging case %d. Only ' ...
        '''ok'' and ''invalid_no_background'' are valid v2.0 statuses.'], ...
        caseIndex);
end
nStatusOK = nnz(statusList == "ok");
nStatusInvalidNoBackground = nnz(statusList == "invalid_no_background");

%% ============================================================
%  Verify that every required 1200-dpi output PNG exists and is readable
%% ============================================================

verifyExpectedPngOutputsV2(frameNoEven_toProcess, phiTag, ...
    diagnosticDir, highResolutionDir, ...
    diagnosticEveryNFrames, highResolutionEveryNFrames);

%% ============================================================
%  Per-frame check TXT (v2.0 content: invalid frames + summary counts)
%% ============================================================

outFrameCheckTxt = fullfile(outDir, sprintf( ...
    'interface_check_%s_%s_%s_%s.txt', distanceName, caseName, phiTag, outputTag));
temporaryFrameCheckTxt = [tempname(outDir) '.txt'];
writeFrameCheckTextV2(ResultEven, temporaryFrameCheckTxt, ...
    frameStartEven, frameEndEven);
replaceFileAtomically(temporaryFrameCheckTxt, outFrameCheckTxt);

%% ============================================================
%  Metadata
%% ============================================================

validStartTimes = chunkStartTimes(isfinite(chunkStartTimes));
validFinishTimes = chunkFinishTimes(isfinite(chunkFinishTimes));
if isempty(validStartTimes) || isempty(validFinishTimes)
    elapsedMin = NaN;
else
    elapsedMin = (max(validFinishTimes) - min(validStartTimes)) * 24 * 60;
end

Meta = struct();
Meta.version = versionTag;
Meta.caseIndex = caseIndex;
Meta.distance = distanceName;
Meta.caseName = caseName;
Meta.caseLabel = caseLabel;
Meta.coordinateConvention = [ ...
    'row = image row index (1..nRows, vertical); ' ...
    'col = image column index (1..nCols, horizontal); ' ...
    'every *RC field is Nx2 [row col]; every *boundary field ' ...
    '(holeBoundaryRC, unknownBoundaryRC) and interfaceRC is a cell array of ' ...
    'Nx4 [rowA colA rowB colB] matrices, one cell per hole ID / unknown-' ...
    'block ID / wake1.0 block ID respectively -- each row one 4-connected ' ...
    'pixel pair (a "crack"), unordered within its cell; two different ' ...
    'holes/unknown-blocks/wake1.0 blocks are never mixed into the same ' ...
    'cell, even where they touch at a single pixel-grid corner.'];
Meta.connectivity = 'v5: 0-side 4-connectivity, 1-side 8-connectivity (see algorithmVersion/description below)';
Meta.algorithmVersion = sprintf('v5 (Step2_v5_final_algorithm_summary.md), run 2026-09, output suffix _%s', outputTag);
Meta.phi_th_even = phi_th_even;
Meta.phiTag = phiTag;
Meta.frameNoEvenUse = frameNoEven_toProcess;
Meta.pivFrameNoEvenUse = pivFrameNoEvenUse;
Meta.badEvenFrameNos = badEvenFrameNos;
Meta.badEvenFileNames = badEvenFileNames;
Meta.excludedPIVFrameNos = excludedPIVFrameNos;
Meta.nNominalEvenFrames = nominalEvenFrameCount;
Meta.nGoodEvenFramesProcessed = nProcess;
Meta.nBadEvenFramesExcluded = numel(badEvenFrameNos);
Meta.firstGoodEvenFrame = frameStartEven;
Meta.lastGoodEvenFrame = frameEndEven;
Meta.nStatusOK = nStatusOK;
Meta.nStatusInvalidNoBackground = nStatusInvalidNoBackground;
Meta.nRows = nRows;
Meta.nCols = nCols;
Meta.yCL_col = yCL_col;
Meta.centreBandHalfWidth = 25;
Meta.minHoleAreaPx = 4;
Meta.minWakeOneAreaPx = 200;
Meta.cornerRadiusPx = 0.15;
Meta.plifDir = plifDir;
Meta.caseOutputRoot = caseOutputRoot;
Meta.blackStripeFile = blackStripeFile;
Meta.backgroundProfileFile = backgroundProfileFile;
Meta.normalisationProfileFile = normalisationProfileFile;
Meta.outputDir = outDir;
Meta.diagnosticDir = diagnosticDir;
Meta.highResolutionDir = highResolutionDir;
Meta.diagnosticEveryNFrames = diagnosticEveryNFrames;
Meta.highResolutionEveryNFrames = highResolutionEveryNFrames;
Meta.diagnosticFrameNoPlanned = diagnosticFrameNoPlanned;
Meta.highResolutionFrameNoPlanned = highResolutionFrameNoPlanned;
Meta.B_profile_even = B_profile_even;
Meta.Phi_ref_even_forNorm = Phi_ref_even_forNorm;
Meta.diagnosticResolutionDPI = 1200;
Meta.highResolutionPanelDPI = 1200;
Meta.interfaceCol = [1.00 0.90 0.00];
Meta.holeBoundaryCol = [0.85 0.05 0.05];
Meta.unknownBoundaryCol = [0.65 0.65 0.65];
Meta.reflectionRemoval = false;
Meta.instantaneousSpatialSmoothing = false;
Meta.areaBasedCleanup = true;
Meta.areaBasedCleanupNote = 'Holes only: area < minHoleAreaPx loses formal hole status but keeps wake status. Background/unknown/wake-centreline/hole-selection classification never otherwise depends on component size.';
Meta.holeMeanPhiStarRecheck = false;
Meta.frameCheckTxt = outFrameCheckTxt;
Meta.requestedWorkers = 10;
Meta.elapsedMin = elapsedMin;
Meta.framesPerChunk = framesPerChunk;
Meta.nChunksPerCase = nChunksPerCase;
Meta.sumChunkElapsedMin = sum(chunkElapsedMin, 'omitnan');
Meta.chunkManifestDirectory = caseChunkDir;
Meta.executionArchitecture = ...
    ['PBS case array, at most 8 cases; 10 MATLAB process workers per case; ' ...
     '51 persistent frame chunks; merge inside the same case job'];
Meta.description = [ ...
    'v5 algorithm (Step2_v5_final_algorithm_summary.md; supersedes the v4 ' ...
    'doc Step2_v2_label_based_algorithm_spec.md -- see that v5 doc section ' ...
    '13 for the complete list of differences from v4). ' ...
    'GOOD EVEN PLIF frames are loaded directly from the Step-1 good-even list. ' ...
    'Step 2 does not repeat black-stripe detection. ' ...
    'No reflection removal. No instantaneous spatial smoothing. ' ...
    'Raw PLIF is background-subtracted using Step-1 B_profile_even, negative ' ...
    'values are clipped to zero, and the result is divided by Step-1 ' ...
    'Phi_ref_even_forNorm before thresholding, giving phiStar. ' ...
    'A non-finite phiStar pixel is an invalid pixel: excluded before any ' ...
    'labelling, never affects any other pixel''s classification. ' ...
    'Every other valid pixel is thresholded into a 0-side or 1-side field. ' ...
    'The two sides use DIFFERENT connectivity (v5 change): 0-side is 4-' ...
    'connectivity-labelled, unchanged from v4; 1-side is 8-connectivity-' ...
    'labelled (diagonal touches count as one block), applied directly to ' ...
    'the raw 1-side mask with NO morphological pre-processing -- this ' ...
    'replaces v4''s "4-connectivity plus a 3x3 morphological closing used ' ...
    'only for the centreline-crossing test". The single 8-connected ' ...
    'labelling serves both the centreline-crossing test and the per-block ' ...
    'numbering used for interface grouping. ' ...
    'BACKGROUND = every 0-side component touching the last image column; ' ...
    'decided once, never revisited. A frame with no such component is ' ...
    'INVALID (status = invalid_no_background) and carries no wake/hole/' ...
    'interface output. Every non-background 0-side component that touches ' ...
    'the first column, first row or last row is reclassified UNKNOWN (its ' ...
    'true extent is beyond the camera field of view), excluded from every ' ...
    'statistic; every other non-background 0-side component is a hole ' ...
    'CANDIDATE, not yet labelled. ' ...
    'WAKE1.0 (v5 change) requires a 1-side component to BOTH contain at ' ...
    'least one pixel whose column falls within ' ...
    '[yCL_col-centreBandHalfWidth, yCL_col+centreBandHalfWidth] (the wake ' ...
    'centreline band) AND have total pixel area strictly greater than ' ...
    'minWakeOneAreaPx (200 px). A component crossing the band but with ' ...
    'area <= minWakeOneAreaPx is NOT wake1.0 -- it falls back to ' ...
    '"unlabelled 1-side", exactly like a component that never crossed the ' ...
    'band at all; its only remaining route into the final wake set is the ' ...
    'wake2.0 promotion below. This area threshold only ever excludes a ' ...
    'truly self-contained small component (one not 8-connected to any ' ...
    'larger qualifying block, which would already share its area). ' ...
    'HOLE SELECTION is LOOSENED from v4 (v5 change): a candidate becomes a ' ...
    'formal HOLE (pre-area-filter) as soon as it touches AT LEAST ONE ' ...
    'wake1.0-labelled 1-side pixel anywhere on its boundary -- v4''s extra ' ...
    'requirement of full encirclement (touching NO non-wake 1-side pixel ' ...
    'at all) is dropped entirely. A formal hole with area < minHoleAreaPx ' ...
    'loses formal hole status (excluded from nHoles/holeID/holeRC/' ...
    'holeArea_px, produces no hole boundary) but keeps its wake status. ' ...
    'WAKE2.0 (v5 addition, did not exist in v4): after hole selection ' ...
    '(using the FULL, pre-area-filter hole pixel set), a 1-side component ' ...
    'still unlabelled after the wake1.0 test is promoted to WAKE2.0 if it ' ...
    'is FULLY surrounded by hole-labelled 0-side pixels. WAKE2.0 pixels ' ...
    'count toward the final wake set (nWake2/wake2ID/wake2PixelIdx/' ...
    'wake2RC/wake2Area_px) but do not drive any separate visualised line. ' ...
    'WAKE (final) = WAKE1.0 pixels UNION WAKE2.0 pixels UNION every ' ...
    'selected hole''s pixels (formal or area-filtered) -- hole pixels are ' ...
    'the only case where a pixel carries two labels (hole + wake) at once. ' ...
    'WAKE1.0 is given its own per-block numbering (nWake1/wake1ID/' ...
    'wake1PixelIdx/wake1RC/wake1Area_px), reusing the single 8-connected ' ...
    '1-side labelling directly (no separate re-labelling step, unlike v4); ' ...
    'this numbering has no effect on any classification and exists solely ' ...
    'to group interface cracks per block, below. ' ...
    'INTERFACE = every 4-connected pixel pair ("crack") between a ' ...
    'background pixel and a WAKE1.0-labelled 1-side pixel ONLY (never ' ...
    'wake2.0; background next to a non-wake1.0, off-centreline, or too- ' ...
    'small-area 1-side pixel does NOT produce interface), grouped per ' ...
    'WAKE1.0 block ID exactly as hole/unknown boundary are grouped per ' ...
    'hole/unknown ID -- this ensures two WAKE1.0 blocks that are not truly ' ...
    '8-connected to each other are never traced/drawn as if they were one ' ...
    'boundary. HOLE BOUNDARY / UNKNOWN BOUNDARY = the analogous cracks ' ...
    'between a formal-hole / unknown pixel and ANY 1-side pixel (not ' ...
    'restricted to wake-labelled -- for a formal hole every neighbour is ' ...
    'wake1.0-labelled by construction anyway, but the boundary is defined ' ...
    'against the raw 1-side mask to keep it self-contained; an unknown ' ...
    'region was never subjected to the "surrounded by wake" test so its ' ...
    'neighbours can be a genuine mix), attributed per region. All are ' ...
    'unordered pixel-pair sets, not ordered curves. Area-based cleanup is ' ...
    'used in exactly two places (holes, minHoleAreaPx; wake1.0, ' ...
    'minWakeOneAreaPx); background/unknown/hole-selection classification ' ...
    'never otherwise depends on component size. No independent re-check ' ...
    'of mean phiStar inside a hole (true by construction under this ' ...
    'framework). ' ...
    'LINE-DRAWING (v5 change, replaces v4''s crack-midpoint + distance- ' ...
    'threshold method entirely): every crack is drawn as its own true ' ...
    'unit-length pixel-boundary edge with both endpoints at real grid ' ...
    'vertices (never a midpoint); cracks sharing a real vertex are chained ' ...
    'by vertex-adjacency alone (no distance threshold); a 3-or-4-crack ' ...
    '"checkerboard" branch vertex pairs cracks sharing the same owning ' ...
    'pixel (interface pairs by the wake1.0 side, hole/unknown boundary by ' ...
    'the hole/unknown side); a small corner-rounding cut (radius ' ...
    'cornerRadiusPx = 0.15 px) is applied only at ordinary 2-crack ' ...
    'vertices where the path direction genuinely changes. See ' ...
    'Step2_v5_final_algorithm_summary.md section 11 for the full rationale. ' ...
    'A four-panel 1200-dpi diagnostic (raw / colour phiStar (white-to-blue) ' ...
    '/ binary mask with invalid points marked / phiStar (white-to-blue) ' ...
    'with interface-hole boundary-unknown boundary overlay, true-edge ' ...
    'lines) is saved every 20th processed good-even frame (PNG only, no ' ...
    'PDF, this round). A 1200-dpi standalone high-resolution panel (raw ' ...
    'PLIF with the same line overlay) is saved every 100th processed ' ...
    'good-even frame.'];

%% ============================================================
%  Save final MAT
%% ============================================================

outMat = fullfile(outDir, sprintf( ...
    'interface_holes_%s_%s_%s_%s.mat', distanceName, caseName, phiTag, outputTag));
temporaryMat = [tempname(outDir) '.mat'];
save(temporaryMat, 'ResultEven', 'Meta', '-v7.3');
replaceFileAtomically(temporaryMat, outMat);
verifyFinalMatFile(outMat);

%% ============================================================
%  Completion marker -- written only after verification
%% ============================================================

temporaryDone = [tempname(outDir) '.txt'];
fidDone = fopen(temporaryDone, 'w');
if fidDone < 0
    error('Cannot write completion marker:\n%s', temporaryDone);
end
fprintf(fidDone, 'Step2_PLIF_interface_2.0 COMPLETE\n');
fprintf(fidDone, 'CaseIndex: %d\n', caseIndex);
fprintf(fidDone, 'Distance: %s\n', distanceName);
fprintf(fidDone, 'CaseName: %s\n', caseName);
fprintf(fidDone, 'Threshold: %.6f\n', phi_th_even);
fprintf(fidDone, 'ThresholdTag: %s\n', phiTag);
fprintf(fidDone, 'GoodEvenProcessed: %d\n', nProcess);
fprintf(fidDone, 'BadEvenExcluded: %d\n', numel(badEvenFrameNos));
fprintf(fidDone, 'StatusOK: %d\n', nStatusOK);
fprintf(fidDone, 'StatusInvalidNoBackground: %d\n', nStatusInvalidNoBackground);
fprintf(fidDone, 'ResultMAT: %s\n', outMat);
fprintf(fidDone, 'Finished: %s\n', datestr(now,31));
fclose(fidDone);
replaceFileAtomically(temporaryDone, doneMarkerFile);

% Chunk MATs duplicate the now-verified final ResultEven data. Remove only
% this successfully merged case's generated intermediates; retain the small
% chunk DONE texts and all logs for audit/progress records.
cleanupMergedChunkMatFiles(caseChunkDir);

fprintf('\n============================================================\n');
fprintf('CASE MERGE COMPLETE\n');
fprintf('Case: %s\n', caseLabel);
fprintf('GOOD EVEN frames: %d (ok = %d, invalid_no_background = %d)\n', ...
    nProcess, nStatusOK, nStatusInvalidNoBackground);
fprintf('Final MAT: %s\n', outMat);
fprintf('Completion marker: %s\n', doneMarkerFile);
fprintf('All required PNG files were verified before completion.\n');
fprintf('============================================================\n');

end


%% ========================================================================
%  Empty result -- MUST match Step2_PLIF_interface_2_0_chunk.m's
%  makeEmptyResultV2() field-for-field.
%% ========================================================================

function R = makeEmptyResultV2()

    R = struct();
    R.frameNo = NaN;
    R.frameName = '';
    R.status = 'not_processed';
    R.isValidFrame = false;

    R.backgroundPixelIdx = zeros(0,1,'uint32');
    R.backgroundRC = zeros(0,2,'uint32');
    R.nBackgroundPixels = 0;

    R.wakePixelIdx = zeros(0,1,'uint32');
    R.wakeRC = zeros(0,2,'uint32');
    R.nWakePixels = 0;
    R.nWakeDyePixels = 0;

    R.nWake1 = 0;
    R.wake1ID = zeros(0,1);
    R.wake1PixelIdx = {};
    R.wake1RC = {};
    R.wake1Area_px = zeros(0,1);

    R.nWake2 = 0;
    R.wake2ID = zeros(0,1);
    R.wake2PixelIdx = {};
    R.wake2RC = {};
    R.wake2Area_px = zeros(0,1);

    R.nHoles = 0;
    R.holeID = zeros(0,1);
    R.holePixelIdx = {};
    R.holeRC = {};
    R.holeArea_px = zeros(0,1);
    R.holeBoundaryRC = {};
    R.nSmallHolesFiltered = 0;

    R.nUnknown = 0;
    R.unknownID = zeros(0,1);
    R.unknownPixelIdx = {};
    R.unknownRC = {};
    R.unknownArea_px = zeros(0,1);
    R.unknownBoundaryRC = {};

    R.interfaceRC = {};
    R.nInterfaceSegments = 0;

    R.invalidPixelIdx = zeros(0,1,'uint32');
    R.invalidRC = zeros(0,2,'uint32');
    R.nInvalidPixels = 0;
end


%% ========================================================================
%  Verify all mandatory images (v2.0 sampling cadence + filenames)
%% ========================================================================

function verifyExpectedPngOutputsV2(frameNos, phiTag, diagnosticDir, ...
        highResolutionDir, diagnosticEveryNFrames, highResolutionEveryNFrames)

    fprintf('\nVerifying diagnostic/high-resolution PNG files (every %dth / %dth frame)...\n', ...
        diagnosticEveryNFrames, highResolutionEveryNFrames);

    nDiagChecked = 0;
    nHighResChecked = 0;

    for k = 1:numel(frameNos)
        frameTag = sprintf('%04d', frameNos(k));

        if mod(k - 1, diagnosticEveryNFrames) == 0
            diagnosticFile = fullfile(diagnosticDir, sprintf( ...
                'PLIF_method1_diagnostic_%s_even_%s_FINAL.png', ...
                frameTag, phiTag));
            validatePngHeader(diagnosticFile);
            nDiagChecked = nDiagChecked + 1;
        end

        if mod(k - 1, highResolutionEveryNFrames) == 0
            highResolutionFile = fullfile(highResolutionDir, sprintf( ...
                'PLIF_method1_panel_%s_even_%s_FINAL.png', ...
                frameTag, phiTag));
            validatePngHeader(highResolutionFile);
            nHighResChecked = nHighResChecked + 1;
        end
    end

    fprintf('Diagnostic PNGs verified: %d\n', nDiagChecked);
    fprintf('High-resolution PNGs verified: %d\n', nHighResChecked);
end


function validatePngHeader(filePath)

    if ~exist(filePath, 'file')
        error('Required PNG is missing:\n%s', filePath);
    end
    D = dir(filePath);
    if isempty(D) || D.bytes <= 0
        error('Required PNG is empty:\n%s', filePath);
    end
    try
        info = imfinfo(filePath);
    catch ME
        error('Required PNG is unreadable:\n%s\n%s', filePath, ME.message);
    end
    if isempty(info) || info(1).Width <= 0 || info(1).Height <= 0
        error('Required PNG has invalid dimensions:\n%s', filePath);
    end
end


%% ========================================================================
%  Per-frame check TXT (v2.0): lists invalid frames (no background found)
%  and a whole-case summary of hole / unknown / interface / invalid-pixel
%  counts. Replaces the old top/bottom interface-spanning check, which no
%  longer applies now that interface is an unordered pixel-pair set.
%% ========================================================================

function writeFrameCheckTextV2(ResultEven, outTxt, frameStartEven, frameEndEven)

    fid = fopen(outTxt, 'w');
    if fid < 0
        error('Cannot open frame check TXT:\n%s', outTxt);
    end

    fprintf(fid, 'Step2 v2.0 per-frame check (connected-component label-based)\n');
    fprintf(fid, '======================================\n\n');
    fprintf(fid, 'GOOD EVEN frames processed from %04d to %04d\n\n', ...
        frameStartEven, frameEndEven);
    fprintf(fid, ['A frame is INVALID when no 0-side connected component ' ...
        'touches the last image column (no background found). An invalid ' ...
        'frame carries no wake/hole/interface output and does not enter ' ...
        'any statistic below.\n\n']);

    statusList = string({ResultEven.status});
    invalidIdx = find(statusList == "invalid_no_background");

    fprintf(fid, 'Invalid frames (no background found): %d / %d\n', ...
        numel(invalidIdx), numel(ResultEven));
    fprintf(fid, '--------------------------------------\n');
    if isempty(invalidIdx)
        fprintf(fid, '(none)\n');
    else
        for k = invalidIdx(:).'
            R = ResultEven(k);
            fprintf(fid, 'Frame %04d | File: %s\n', R.frameNo, R.frameName);
        end
    end

    validIdx = find(statusList == "ok");
    totalHoles = 0;
    totalUnknown = 0;
    totalInterfaceSegments = 0;
    totalInvalidPixels = 0;
    totalHoleAreaPx = 0;
    totalUnknownAreaPx = 0;
    totalSmallHolesFiltered = 0;
    for k = validIdx(:).'
        R = ResultEven(k);
        totalHoles = totalHoles + R.nHoles;
        totalUnknown = totalUnknown + R.nUnknown;
        totalInterfaceSegments = totalInterfaceSegments + R.nInterfaceSegments;
        totalHoleAreaPx = totalHoleAreaPx + sum(R.holeArea_px);
        totalUnknownAreaPx = totalUnknownAreaPx + sum(R.unknownArea_px);
        totalSmallHolesFiltered = totalSmallHolesFiltered + R.nSmallHolesFiltered;
    end
    for k = 1:numel(ResultEven)
        totalInvalidPixels = totalInvalidPixels + ResultEven(k).nInvalidPixels;
    end

    fprintf(fid, '\nWhole-case summary (valid frames only, except invalid-pixel count)\n');
    fprintf(fid, '--------------------------------------\n');
    fprintf(fid, 'Valid frames: %d\n', numel(validIdx));
    fprintf(fid, 'Total formal holes across all valid frames: %d (total %d px)\n', ...
        totalHoles, totalHoleAreaPx);
    fprintf(fid, 'Total small holes filtered out (area < minHoleAreaPx) across all valid frames: %d\n', ...
        totalSmallHolesFiltered);
    fprintf(fid, 'Total unknown (FoV-excluded) regions across all valid frames: %d (total %d px)\n', ...
        totalUnknown, totalUnknownAreaPx);
    fprintf(fid, 'Total interface pixel-pair segments across all valid frames: %d\n', ...
        totalInterfaceSegments);
    fprintf(fid, 'Total invalid (non-finite phiStar) pixels across all %d frames: %d\n', ...
        numel(ResultEven), totalInvalidPixels);

    fclose(fid);
end


%% ========================================================================
%  Same-directory atomic replacement
%% ========================================================================

function replaceFileAtomically(sourceFile, destinationFile)

    if ~exist(sourceFile, 'file')
        error('Cannot publish missing source file:\n%s', sourceFile);
    end

    [okMove,msgMove] = movefile(sourceFile, destinationFile, 'f');
    if ~okMove
        error('Failed to replace destination:\n%s', msgMove);
    end
end


%% ========================================================================
%  Verify final MAT and release redundant chunk storage after success
%% ========================================================================

function verifyFinalMatFile(filePath)

    if ~exist(filePath, 'file')
        error('Final MAT is missing after publication:\n%s', filePath);
    end

    D = dir(filePath);
    if isempty(D) || D.bytes <= 0
        error('Final MAT is empty:\n%s', filePath);
    end

    try
        variables = whos('-file', filePath);
    catch ME
        error('Final MAT cannot be inspected:\n%s\n%s', ...
            filePath, ME.message);
    end

    variableNames = string({variables.name});
    if ~all(ismember(["ResultEven","Meta"], variableNames))
        error('Final MAT does not contain ResultEven and Meta:\n%s', ...
            filePath);
    end
end


function cleanupMergedChunkMatFiles(caseChunkDir)

    chunkFiles = dir(fullfile(caseChunkDir, 'chunk_*.mat'));

    for k = 1:numel(chunkFiles)
        thisFile = fullfile(chunkFiles(k).folder, chunkFiles(k).name);
        try
            delete(thisFile);
        catch ME
            warning('Could not remove merged chunk MAT %s: %s', ...
                thisFile, ME.message);
        end
    end
end
