#!/usr/bin/env python3
"""
Adds an optional `outputTag` parameter to the two LOCKED scientific files
(Step2_PLIF_interface_2_0_chunk.m, Step2_PLIF_interface_2_0_merge.m).

Every replacement below is a pure naming/structure change:
  - function signature gains a 3rd optional argument `outputTag`
  - default value is '0904' (byte-for-byte identical behaviour to today
    if outputTag is not supplied)
  - every hardcoded "0904" used only in output folder/file naming is
    replaced by the outputTag variable

NO line touching computation, thresholds, classification rules, flux
formulas, or plotting logic is touched. Every replacement is verified to
match EXACTLY ONCE in the live file before anything is written; if a
single match isn't found, the script aborts that file with a clear error
and writes nothing, so a drifted/different live file can never be
silently corrupted.
"""
import sys
import shutil
import datetime

def apply_patch(path, replacements):
    with open(path, encoding="utf-8") as f:
        text = f.read()

    for i, (old, new) in enumerate(replacements, start=1):
        n = text.count(old)
        if n != 1:
            print(f"ABORT: {path}")
            print(f"  replacement #{i} matched {n} time(s) (expected exactly 1).")
            print("  Nothing was written to this file. Paste this message back for review.")
            print("  ---- expected old text ----")
            print(old)
            return False

    backup = f"{path}.bak_pre_outputTag_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}"
    shutil.copy2(path, backup)

    for old, new in replacements:
        text = text.replace(old, new, 1)

    with open(path, "w", encoding="utf-8") as f:
        f.write(text)

    remaining = text.count("0904")
    print(f"OK: {path}")
    print(f"  backup saved to: {backup}")
    print(f"  applied {len(replacements)} replacement(s)")
    print(f"  remaining literal '0904' occurrences in file: {remaining} (this is expected: only the default-value string and doc comments still say 0904, harmless)")
    return True


CHUNK_REPLACEMENTS = [
    (
"function Step2_PLIF_interface_2_0_chunk(taskIndex, runId)",
"function Step2_PLIF_interface_2_0_chunk(taskIndex, runId, outputTag)",
    ),
    (
"""% SCIENTIFIC BASELINE (v5 label-based algorithm, run under the
% "Step2_PLIF_interface_2.0" package/version identity -- the package name
% and folder layout are unchanged from earlier 2.0 rounds; only the
% classification + line-drawing core described below was revised. Output
% folders/files from this round are tagged "_0904" to distinguish them
% from the earlier "_0902" round that ran the v4 rules):""",
"""% SCIENTIFIC BASELINE (v5 label-based algorithm, run under the
% "Step2_PLIF_interface_2.0" package/version identity -- the package name
% and folder layout are unchanged from earlier 2.0 rounds; only the
% classification + line-drawing core described below was revised. Output
% folders/files are tagged with the caller-supplied outputTag (an
% execution-layer naming choice, default "0904" if omitted); the earlier
% "_0902" round ran the v4 rules):""",
    ),
    (
"""if nargin < 1 || isempty(taskIndex)
    taskIndex = str2double(getenv('PBS_ARRAY_INDEX'));
end
if nargin < 2 || isempty(runId)
    runId = getenv('STEP2_RUN_ID');
end

if ~(isnumeric(taskIndex) && isscalar(taskIndex) && isfinite(taskIndex) && ...
        taskIndex == round(taskIndex) && taskIndex >= 1 && ...
        taskIndex <= nTotalChunkTasks)
    error('taskIndex must be an integer from 1 to %d.', nTotalChunkTasks);
end
if isempty(runId) || isempty(regexp(runId, '^[A-Za-z0-9_-]+$', 'once'))
    error('runId must contain only letters, numbers, underscore or hyphen.');
end""",
"""if nargin < 1 || isempty(taskIndex)
    taskIndex = str2double(getenv('PBS_ARRAY_INDEX'));
end
if nargin < 2 || isempty(runId)
    runId = getenv('STEP2_RUN_ID');
end
if nargin < 3 || isempty(outputTag)
    outputTag = '0904';
end

if ~(isnumeric(taskIndex) && isscalar(taskIndex) && isfinite(taskIndex) && ...
        taskIndex == round(taskIndex) && taskIndex >= 1 && ...
        taskIndex <= nTotalChunkTasks)
    error('taskIndex must be an integer from 1 to %d.', nTotalChunkTasks);
end
if isempty(runId) || isempty(regexp(runId, '^[A-Za-z0-9_-]+$', 'once'))
    error('runId must contain only letters, numbers, underscore or hyphen.');
end
if isempty(outputTag) || isempty(regexp(outputTag, '^[A-Za-z0-9_-]+$', 'once'))
    error('outputTag must contain only letters, numbers, underscore or hyphen.');
end""",
    ),
    (
"""%  Paths -- Step-1 inputs unchanged (reading Step-1's outputs is NOT
%  touched by this round's algorithm revision). v2.0 outputs live in their
%  own suffixed tree so nothing collides with earlier results; this
%  round's suffix is "_0904" (previous v4-algorithm round used "_0902",
%  and the original 1.x package used no suffix at all -- both are untouched
%  by this run).""",
"""%  Paths -- Step-1 inputs unchanged (reading Step-1's outputs is NOT
%  touched by this round's algorithm revision). v2.0 outputs live in their
%  own suffixed tree so nothing collides with earlier results; the suffix
%  is now supplied by the caller as outputTag (execution-layer naming
%  choice, default "0904"). The earlier v4-algorithm round used "_0902",
%  and the original 1.x package used no suffix at all -- both are untouched
%  by this run regardless of outputTag.""",
    ),
    (
"""outDir = fullfile(caseOutputRoot, ...
    sprintf('Y_interface_detection_method1_even_%s_final_0904', phiTag));
diagnosticDir = fullfile(outDir, 'Diagnostic_4panel_0904');
highResolutionDir = fullfile(outDir, 'High_resolution_panel_0904');""",
"""outDir = fullfile(caseOutputRoot, ...
    sprintf('Y_interface_detection_method1_even_%s_final_%s', phiTag, outputTag));
diagnosticDir = fullfile(outDir, sprintf('Diagnostic_4panel_%s', outputTag));
highResolutionDir = fullfile(outDir, sprintf('High_resolution_panel_%s', outputTag));""",
    ),
]

MERGE_REPLACEMENTS = [
    (
"function Step2_PLIF_interface_2_0_merge(caseIndex, runId)",
"function Step2_PLIF_interface_2_0_merge(caseIndex, runId, outputTag)",
    ),
    (
"""% SCIENTIFIC BASELINE: v5 connected-component label-based interface/hole
% detection (Step2_v5_final_algorithm_summary.md; run under the
% "Step2_PLIF_interface_2.0" package identity, output suffix "_0904" this
% round). See Step2_PLIF_interface_2_0_chunk.m header and the project""",
"""% SCIENTIFIC BASELINE: v5 connected-component label-based interface/hole
% detection (Step2_v5_final_algorithm_summary.md; run under the
% "Step2_PLIF_interface_2.0" package identity; output suffix is an
% execution-layer choice supplied by the caller as outputTag, default
% "0904" if omitted). See Step2_PLIF_interface_2_0_chunk.m header and the project""",
    ),
    (
"""if nargin < 1 || isempty(caseIndex)
    caseIndex = str2double(getenv('PBS_ARRAY_INDEX'));
end
if nargin < 2 || isempty(runId)
    runId = getenv('STEP2_RUN_ID');
end

if ~(isnumeric(caseIndex) && isscalar(caseIndex) && isfinite(caseIndex) && ...
        caseIndex == round(caseIndex) && caseIndex >= 1 && ...
        caseIndex <= nCases)
    error('caseIndex must be an integer from 1 to %d.', nCases);
end
if isempty(runId) || isempty(regexp(runId, '^[A-Za-z0-9_-]+$', 'once'))
    error('runId must contain only letters, numbers, underscore or hyphen.');
end""",
"""if nargin < 1 || isempty(caseIndex)
    caseIndex = str2double(getenv('PBS_ARRAY_INDEX'));
end
if nargin < 2 || isempty(runId)
    runId = getenv('STEP2_RUN_ID');
end
if nargin < 3 || isempty(outputTag)
    outputTag = '0904';
end

if ~(isnumeric(caseIndex) && isscalar(caseIndex) && isfinite(caseIndex) && ...
        caseIndex == round(caseIndex) && caseIndex >= 1 && ...
        caseIndex <= nCases)
    error('caseIndex must be an integer from 1 to %d.', nCases);
end
if isempty(runId) || isempty(regexp(runId, '^[A-Za-z0-9_-]+$', 'once'))
    error('runId must contain only letters, numbers, underscore or hyphen.');
end
if isempty(outputTag) || isempty(regexp(outputTag, '^[A-Za-z0-9_-]+$', 'once'))
    error('outputTag must contain only letters, numbers, underscore or hyphen.');
end""",
    ),
    (
"""outDir = fullfile(caseOutputRoot, ...
    sprintf('Y_interface_detection_method1_even_%s_final_0904', phiTag));
diagnosticDir = fullfile(outDir, 'Diagnostic_4panel_0904');
highResolutionDir = fullfile(outDir, 'High_resolution_panel_0904');

manifestRunRoot = fullfile(masterDir, '06_MANIFESTS', ...
    'Step2_PLIF_interface_2.0', runId);
caseChunkDir = fullfile(manifestRunRoot, sprintf('case_%02d', caseIndex));

% v2.0 uses its own completion-marker filename (2.0, not 1.0), since this is
% a new output tree (0904 suffix, this round) that never coexists with 1.x
% or the earlier 0902-suffixed v4-algorithm outputs.
doneMarkerFile = fullfile(outDir, 'Step2_PLIF_interface_2.0_DONE_0904.txt');""",
"""outDir = fullfile(caseOutputRoot, ...
    sprintf('Y_interface_detection_method1_even_%s_final_%s', phiTag, outputTag));
diagnosticDir = fullfile(outDir, sprintf('Diagnostic_4panel_%s', outputTag));
highResolutionDir = fullfile(outDir, sprintf('High_resolution_panel_%s', outputTag));

manifestRunRoot = fullfile(masterDir, '06_MANIFESTS', ...
    'Step2_PLIF_interface_2.0', runId);
caseChunkDir = fullfile(manifestRunRoot, sprintf('case_%02d', caseIndex));

% v2.0 uses its own completion-marker filename (2.0, not 1.0), since this is
% a new output tree (outputTag suffix, this round) that never coexists with
% 1.x or the earlier 0902-suffixed v4-algorithm outputs.
doneMarkerFile = fullfile(outDir, sprintf('Step2_PLIF_interface_2.0_DONE_%s.txt', outputTag));""",
    ),
    (
"""outFrameCheckTxt = fullfile(outDir, sprintf( ...
    'interface_check_%s_%s_%s_0904.txt', distanceName, caseName, phiTag));""",
"""outFrameCheckTxt = fullfile(outDir, sprintf( ...
    'interface_check_%s_%s_%s_%s.txt', distanceName, caseName, phiTag, outputTag));""",
    ),
    (
"""Meta.algorithmVersion = 'v5 (Step2_v5_final_algorithm_summary.md), run 2026-09, output suffix _0904';""",
"""Meta.algorithmVersion = sprintf('v5 (Step2_v5_final_algorithm_summary.md), run 2026-09, output suffix _%s', outputTag);""",
    ),
    (
"""outMat = fullfile(outDir, sprintf( ...
    'interface_holes_%s_%s_%s_0904.mat', distanceName, caseName, phiTag));""",
"""outMat = fullfile(outDir, sprintf( ...
    'interface_holes_%s_%s_%s_%s.mat', distanceName, caseName, phiTag, outputTag));""",
    ),
]


def main():
    if len(sys.argv) != 3:
        print("Usage: apply_outputTag_patch.py <chunk.m path> <merge.m path>")
        sys.exit(2)
    chunk_path, merge_path = sys.argv[1], sys.argv[2]

    ok1 = apply_patch(chunk_path, CHUNK_REPLACEMENTS)
    ok2 = apply_patch(merge_path, MERGE_REPLACEMENTS)

    if ok1 and ok2:
        print("\nDONE: both files patched successfully.")
        sys.exit(0)
    else:
        print("\nABORTED: at least one file was NOT modified. See messages above.")
        sys.exit(1)


if __name__ == "__main__":
    main()
